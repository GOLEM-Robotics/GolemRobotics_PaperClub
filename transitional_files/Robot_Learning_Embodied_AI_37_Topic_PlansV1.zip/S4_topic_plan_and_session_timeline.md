# S4 — Navigation and embodied agents: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** F. Specialization branches  
**Execution status:** **Optional**

## 1. Topic scope and target depth

### Covers

Visual navigation, mapping policies, vision-and-language navigation, embodied question answering, and hierarchical mobile manipulation.

### Excludes

It excludes autonomous driving and full SLAM engineering; the focus is embodied-agent learning and language-conditioned navigation.

### Target competence

Understand visual navigation, mapping policies, VLN, embodied QA, and hierarchical mobile manipulation; evaluate generalization and map/memory dependence.

### Place in the wider curriculum

Optional unless mobile embodied agents become active. Complements manipulation-centric work.

## 2. Execution status and completion boundary

- **Topic execution status:** Optional
- **Planned sessions:** 9
- **Classification:** 4 required core · 0 advanced continuation · 5 optional specialization · 0 frontier continuation
- **Completion boundary:** The topic is not part of the currently executable curriculum. If activated, its internal required core runs through Session 6; remaining sessions are optional specialization or frontier continuations.
- **Required core endpoint:** Session 6

## 3. Dependencies and required foundations

- **Master prerequisites:** F8, P1–P4, E1.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Navigation task definitions, egocentric observations, mapping/memory, exploration, language grounding, geodesic metrics, partial observability, and hierarchical control.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R008 — [Probabilistic Robotics](https://mitpress.mit.edu/9780262201629/probabilistic-robotics/)** (Textbook): Bayesian filtering, localization, mapping, and SLAM foundation.
- **R019 — [ManiSkill Documentation](https://maniskill.readthedocs.io/)** (Simulation/benchmark documentation): High-throughput manipulation experiments and standardized evaluation.
- **R032 — [Habitat Lab Documentation](https://aihabitat.org/docs/habitat-lab/)** (Embodied-agent framework documentation): Navigation/embodied-agent task definitions, vectorized environments, datasets, evaluation, and hierarchical-agent experiments.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: F8, P1–P4, E1.
        │
        ▼
S1 Topic-local foundations: Navigation task definitions, egocentric observations, mapping/memory, exploration, language grounding, geodesic metrics, partial observability, and hierarchical control.
        │
        ▼
Paper lineage: P177 → P178 → P179 → P180
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► mobile manipulation, E1–E3
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for navigation and embodied agents and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** F8, P1–P4, E1.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R008, R019, R032
- **Concepts covered:** Navigation task definitions, egocentric observations, mapping/memory, exploration, language grounding, geodesic metrics, partial observability, and hierarchical control.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Visual navigation, mapping policies, vision-and-language navigation, embodied question answering, and hierarchical mobile manipulation. Next, enter the ordered paper lineage.

### 2. P177 — Cognitive Mapping and Planning for Visual Navigation

- **Central question / objective:** Learns spatial maps and planning policies from visual observations.
- **Stage / role:** Paper lineage — Foundation; Bridge
- **Status:** Required core
- **Prerequisites:** Session 1; F8, P1–P4, E1.
- **Papers:** [P177 — Cognitive Mapping and Planning for Visual Navigation](https://arxiv.org/abs/1702.03920)
- **Supporting materials:** R008, R019
- **Concepts covered:** Learns spatial maps and planning policies from visual observations. Preparation profile: Foundation; Bridge · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in navigation and embodied agents.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P178). Master lineage note: Bridge from classical mapping to learned navigation.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Simulation/domain assumptions and supervised map structure.
- **Resumption context:** The durable takeaway is: Learns spatial maps and planning policies from visual observations. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P178 — Habitat: A Platform for Embodied AI Research

- **Central question / objective:** Introduces a high-throughput photorealistic simulation platform for embodied navigation.
- **Stage / role:** Paper lineage — Foundation
- **Status:** Required core
- **Prerequisites:** Session 2; F8, P1–P4, E1.
- **Papers:** [P178 — Habitat: A Platform for Embodied AI Research](https://arxiv.org/abs/1904.01201)
- **Supporting materials:** R008, R019
- **Concepts covered:** Introduces a high-throughput photorealistic simulation platform for embodied navigation. Preparation profile: Foundation · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in navigation and embodied agents.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P179). Master lineage note: Infrastructure foundation for modern navigation benchmarks.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Static scanned environments and simulator bias limit transfer.
- **Resumption context:** The durable takeaway is: Introduces a high-throughput photorealistic simulation platform for embodied navigation. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P179 — Vision-and-Language Navigation: Interpreting Visually-Grounded Navigation Instructions in Real Environments

- **Central question / objective:** Introduces the Room-to-Room benchmark for instruction-following navigation in scanned environments.
- **Stage / role:** Paper lineage — Seminal
- **Status:** Optional specialization
- **Prerequisites:** Session 3; F8, P1–P4, E1.
- **Papers:** [P179 — Vision-and-Language Navigation: Interpreting Visually-Grounded Navigation Instructions in Real Environments](https://arxiv.org/abs/1711.07280)
- **Supporting materials:** R008, R019
- **Concepts covered:** Introduces the Room-to-Room benchmark for instruction-following navigation in scanned environments. Preparation profile: Seminal · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in navigation and embodied agents.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P180). Master lineage note: Foundation for VLN and language-grounded embodied agents.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Discrete graph navigation, dataset biases, and limited physical interaction.
- **Resumption context:** The durable takeaway is: Introduces the Room-to-Room benchmark for instruction-following navigation in scanned environments. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P180 — Active Neural SLAM

- **Central question / objective:** Combines learned perception/exploration with explicit mapping and planning for navigation.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Optional specialization
- **Prerequisites:** Session 4; F8, P1–P4, E1.
- **Papers:** [P180 — Active Neural SLAM](https://arxiv.org/abs/2004.05155)
- **Supporting materials:** R008, R019
- **Concepts covered:** Combines learned perception/exploration with explicit mapping and planning for navigation. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in navigation and embodied agents.
- **Relationship in sequence:** Builds on paper session 4; leads to the topic reconstruction/comparison session. Master lineage note: Hybrid classical-learned architecture relevant to embodied agents.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Simulation-heavy and dependent on map/action abstractions.
- **Resumption context:** The durable takeaway is: Combines learned perception/exploration with explicit mapping and planning for navigation. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Compare PointNav/Habitat-style navigation, neural mapping, VLN, embodied QA, and mobile manipulation as increasing semantic and action complexity.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–5
- **Papers:** [P177 — Cognitive Mapping and Planning for Visual Navigation](https://arxiv.org/abs/1702.03920), [P178 — Habitat: A Platform for Embodied AI Research](https://arxiv.org/abs/1904.01201), [P179 — Vision-and-Language Navigation: Interpreting Visually-Grounded Navigation Instructions in Real Environments](https://arxiv.org/abs/1711.07280), [P180 — Active Neural SLAM](https://arxiv.org/abs/2004.05155)
- **Supporting materials:** R008, R019, R032
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 7. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Train/evaluate a navigation or VLN baseline in Habitat; test map/memory ablations, environment shift, language variation, and failure recovery.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Optional specialization
- **Prerequisites:** Sessions 1–6; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R008, R019, R032
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Train/evaluate a navigation or VLN baseline in Habitat; test map/memory ablations, environment shift, language variation, and failure recovery.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 8. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Optional specialization
- **Prerequisites:** Sessions 1–7; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R008, R019, R032
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 9. Topic synthesis and original research directions

- **Central question / objective:** What internal spatial representation and memory are necessary for long-horizon embodied navigation?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Optional specialization
- **Prerequisites:** Sessions 1–8
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R008, R019, R032
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: mobile manipulation, E1–E3.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | F8, P1–P4, E1. |
| Closely related / cross-area | Complements manipulation-centric work. |
| Outgoing capability | mobile manipulation, E1–E3 |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P177, P178, P179, P180 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**What internal spatial representation and memory are necessary for long-horizon embodied navigation?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to mobile manipulation, E1–E3 is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 4 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** Propose adding the following supporting resources to the master supporting-material index: R032. They fill implementation/reconstruction gaps without changing the paper sequence.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
