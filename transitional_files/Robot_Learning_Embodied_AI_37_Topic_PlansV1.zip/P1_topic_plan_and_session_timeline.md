# P1 — Visual and multimodal representation learning: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** B. Perception, spatial intelligence, and world models  
**Execution status:** **Shared Core**

## 1. Topic scope and target depth

### Covers

Transferable image and image–text representations, dense features, frozen encoders, and multimodal pretraining.

### Excludes

It excludes downstream detector/segmenter design and 3D/video-specific methods covered in P2–P4.

### Target competence

Select and evaluate frozen or adapted visual/multimodal encoders for robotics, understanding contrastive and self-distillation objectives, dense-feature quality, and transfer limits.

### Place in the wider curriculum

Durable visual foundation. Prerequisite for P2–P4, E1–E2, and L6.

## 2. Execution status and completion boundary

- **Topic execution status:** Shared Core
- **Planned sessions:** 10
- **Classification:** 10 required core · 0 advanced continuation · 0 optional specialization · 0 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 10, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 10

## 3. Dependencies and required foundations

- **Master prerequisites:** F3–F5.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Global versus dense representations, contrastive alignment, self-distillation, pretraining data, frozen probes, fine-tuning, and representation diagnostics.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R012 — [Dive into Deep Learning](https://d2l.ai/)** (Interactive open textbook): Implementation-oriented prerequisite repair for uneven member backgrounds.
- **R013 — [Stanford CS231n](https://cs231n.github.io/)** (Lecture notes): Targeted computer-vision and optimization foundation.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: F3–F5.
        │
        ▼
S1 Topic-local foundations: Global versus dense representations, contrastive alignment, self-distillation, pretraining data, frozen probes, fine-tuning, and representation diagnostics.
        │
        ▼
Paper lineage: P043 → P044 → P045 → P046 → P047
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► P2–P4, L6, E1–E2
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for visual and multimodal representation learning and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** F3–F5.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R012, R013
- **Concepts covered:** Global versus dense representations, contrastive alignment, self-distillation, pretraining data, frozen probes, fine-tuning, and representation diagnostics.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Transferable image and image–text representations, dense features, frozen encoders, and multimodal pretraining. Next, enter the ordered paper lineage.

### 2. P043 — Learning Transferable Visual Models From Natural Language Supervision

- **Central question / objective:** Introduces CLIP-style contrastive image–text pretraining and zero-shot classification.
- **Stage / role:** Paper lineage — Seminal; Bridge
- **Status:** Required core
- **Prerequisites:** Session 1; F3–F5.
- **Papers:** [P043 — Learning Transferable Visual Models From Natural Language Supervision](https://proceedings.mlr.press/v139/radford21a.html)
- **Supporting materials:** R012, R013
- **Concepts covered:** Introduces CLIP-style contrastive image–text pretraining and zero-shot classification. Preparation profile: Seminal; Bridge · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in visual and multimodal representation learning.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P044). Master lineage note: Builds on contrastive learning; foundational for open-vocabulary perception and VLA backbones.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Global image–text alignment is weak for precise geometry and temporal dynamics.
- **Resumption context:** The durable takeaway is: Introduces CLIP-style contrastive image–text pretraining and zero-shot classification. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P044 — Emerging Properties in Self-Supervised Vision Transformers

- **Central question / objective:** Shows DINO self-distillation yields strong semantic and dense structure without labels.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 2; F3–F5.
- **Papers:** [P044 — Emerging Properties in Self-Supervised Vision Transformers](https://openaccess.thecvf.com/content/ICCV2021/html/Caron_Emerging_Properties_in_Self-Supervised_Vision_Transformers_ICCV_2021_paper.html)
- **Supporting materials:** R012, R013
- **Concepts covered:** Shows DINO self-distillation yields strong semantic and dense structure without labels. Preparation profile: Modern Core · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in visual and multimodal representation learning.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P045). Master lineage note: Alternative to contrastive/reconstruction objectives; precedes DINOv2.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Training recipe sensitivity and compute requirements are substantial.
- **Resumption context:** The durable takeaway is: Shows DINO self-distillation yields strong semantic and dense structure without labels. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P045 — DINOv2: Learning Robust Visual Features without Supervision

- **Central question / objective:** Scales curated self-supervised visual pretraining to robust transferable image features.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 3; F3–F5.
- **Papers:** [P045 — DINOv2: Learning Robust Visual Features without Supervision](https://arxiv.org/abs/2304.07193)
- **Supporting materials:** R012, R013
- **Concepts covered:** Scales curated self-supervised visual pretraining to robust transferable image features. Preparation profile: Modern Core · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in visual and multimodal representation learning.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P046). Master lineage note: Builds on DINO; common frozen visual backbone in robotics.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Image-only pretraining lacks explicit action/temporal grounding; data curation is expensive.
- **Resumption context:** The durable takeaway is: Scales curated self-supervised visual pretraining to robust transferable image features. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P046 — Sigmoid Loss for Language Image Pre-Training

- **Central question / objective:** Replaces global softmax contrastive loss with pairwise sigmoid loss for scalable image–text pretraining.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 4; F3–F5.
- **Papers:** [P046 — Sigmoid Loss for Language Image Pre-Training](https://openaccess.thecvf.com/content/ICCV2023/html/Zhai_Sigmoid_Loss_for_Language_Image_Pre-Training_ICCV_2023_paper.html)
- **Supporting materials:** R012, R013
- **Concepts covered:** Replaces global softmax contrastive loss with pairwise sigmoid loss for scalable image–text pretraining. Preparation profile: Modern Core · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in visual and multimodal representation learning.
- **Relationship in sequence:** Builds on paper session 4; leads to the next paper in the master sequence (P047). Master lineage note: Alternative to CLIP used in several efficient VLM/VLA stacks.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Large-scale results rely on substantial proprietary data/compute.
- **Resumption context:** The durable takeaway is: Replaces global softmax contrastive loss with pairwise sigmoid loss for scalable image–text pretraining. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. P047 — What Makes for Good Visual Representations for Robot Manipulation?

- **Central question / objective:** Systematically compares visual pretraining choices for downstream manipulation.
- **Stage / role:** Paper lineage — Critical; Bridge
- **Status:** Required core
- **Prerequisites:** Session 5; F3–F5.
- **Papers:** [P047 — What Makes for Good Visual Representations for Robot Manipulation?](https://arxiv.org/abs/2107.12344)
- **Supporting materials:** R012, R013
- **Concepts covered:** Systematically compares visual pretraining choices for downstream manipulation. Preparation profile: Critical; Bridge · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in visual and multimodal representation learning.
- **Relationship in sequence:** Builds on paper session 5; leads to the topic reconstruction/comparison session. Master lineage note: Connects generic representation papers to closed-loop robot control.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Results depend on task suite and policy architecture; predates newer foundation encoders.
- **Resumption context:** The durable takeaway is: Systematically compares visual pretraining choices for downstream manipulation. Continue by comparing its assumptions and evidence with the next lineage stage.

### 7. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Compare CLIP, DINO/DINOv2, SigLIP, and robot-specific representation evaluation at objective, data, feature, and transfer levels.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–6
- **Papers:** [P043 — Learning Transferable Visual Models From Natural Language Supervision](https://proceedings.mlr.press/v139/radford21a.html), [P044 — Emerging Properties in Self-Supervised Vision Transformers](https://openaccess.thecvf.com/content/ICCV2021/html/Caron_Emerging_Properties_in_Self-Supervised_Vision_Transformers_ICCV_2021_paper.html), [P045 — DINOv2: Learning Robust Visual Features without Supervision](https://arxiv.org/abs/2304.07193), [P046 — Sigmoid Loss for Language Image Pre-Training](https://openaccess.thecvf.com/content/ICCV2023/html/Zhai_Sigmoid_Loss_for_Language_Image_Pre-Training_ICCV_2023_paper.html), [P047 — What Makes for Good Visual Representations for Robot Manipulation?](https://arxiv.org/abs/2107.12344)
- **Supporting materials:** R012, R013
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 8. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Benchmark frozen features and limited fine-tuning on a small robot perception/manipulation dataset with linear probes and spatial diagnostics.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–7; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R012, R013
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Benchmark frozen features and limited fine-tuning on a small robot perception/manipulation dataset with linear probes and spatial diagnostics.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 9. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–8; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R012, R013
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 10. Topic synthesis and original research directions

- **Central question / objective:** What makes a representation useful for physical interaction rather than only image-level recognition?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–9
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R012, R013
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: P2–P4, L6, E1–E2.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | F3–F5. |
| Closely related / cross-area | Prerequisite for P2–P4, E1–E2, and L6. |
| Outgoing capability | P2–P4, L6, E1–E2 |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P043, P044, P045, P046, P047 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**What makes a representation useful for physical interaction rather than only image-level recognition?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to P2–P4, L6, E1–E2 is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 5 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** No change to topic boundary or primary-paper inventory is proposed.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
