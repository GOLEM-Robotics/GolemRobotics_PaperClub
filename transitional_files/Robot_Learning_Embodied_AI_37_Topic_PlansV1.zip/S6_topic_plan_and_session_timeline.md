# S6 — Multi-agent reinforcement learning: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** F. Specialization branches  
**Execution status:** **Deferred**

## 1. Topic scope and target depth

### Covers

Centralized training/decentralized execution, credit assignment, communication, non-stationarity, and cooperative control.

### Excludes

It excludes game-theoretic breadth and remains deferred until a concrete multi-robot/cooperative task exists.

### Target competence

Understand CTDE, non-stationarity, credit assignment, value factorization, communication, and evaluation sufficiently to launch a justified multi-agent project.

### Place in the wider curriculum

Deferred until a concrete multi-robot problem exists. Independent branch with limited immediate overlap.

## 2. Execution status and completion boundary

- **Topic execution status:** Deferred
- **Planned sessions:** 8
- **Classification:** 0 required core · 0 advanced continuation · 8 optional specialization · 0 frontier continuation
- **Completion boundary:** The topic is not part of the currently executable curriculum. If activated, its internal required core runs through Session 0; remaining sessions are optional specialization or frontier continuations.
- **Required core endpoint:** Session N/A

## 3. Dependencies and required foundations

- **Master prerequisites:** L1–L2.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Markov games, joint policies, decentralized observations, CTDE, centralized critics, credit assignment, value decomposition, communication, and exploitability/generalization.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R001 — [Reinforcement Learning: An Introduction, 2nd ed.](http://incompleteideas.net/book/the-book-2nd.html)** (Textbook): Primary mathematical entry point; use selected chapters before original TD/Q/policy-gradient papers.
- **R004 — [CS285: Deep Reinforcement Learning](https://rail.eecs.berkeley.edu/deeprlcourse/)** (Lecture notes and videos): Modern bridge from theory to model-free, model-based, imitation, and offline RL.
- **R037 — [PettingZoo Documentation](https://pettingzoo.farama.org/)** (Multi-agent environment API and reference environments): Correct multi-agent environment semantics, reproducible interfaces, and controlled CTDE/non-stationarity experiments.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: L1–L2.
        │
        ▼
S1 Topic-local foundations: Markov games, joint policies, decentralized observations, CTDE, centralized critics, credit assignment, value decomposition, communication, and exploitability/generalization.
        │
        ▼
Paper lineage: P185 → P186 → P187
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► future multi-robot systems
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for multi-agent reinforcement learning and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Optional specialization
- **Prerequisites:** L1–L2.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R001, R004, R037
- **Concepts covered:** Markov games, joint policies, decentralized observations, CTDE, centralized critics, credit assignment, value decomposition, communication, and exploitability/generalization.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Centralized training/decentralized execution, credit assignment, communication, non-stationarity, and cooperative control. Next, enter the ordered paper lineage.

### 2. P185 — Multi-Agent Actor-Critic for Mixed Cooperative-Competitive Environments

- **Central question / objective:** Introduces MADDPG with centralized critics and decentralized actors.
- **Stage / role:** Paper lineage — Foundation
- **Status:** Optional specialization
- **Prerequisites:** Session 1; L1–L2.
- **Papers:** [P185 — Multi-Agent Actor-Critic for Mixed Cooperative-Competitive Environments](https://arxiv.org/abs/1706.02275)
- **Supporting materials:** R001, R004
- **Concepts covered:** Introduces MADDPG with centralized critics and decentralized actors. Preparation profile: Foundation · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in multi-agent reinforcement learning.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P186). Master lineage note: Canonical centralized-training/decentralized-execution baseline.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Known instability and limited scalability; simple benchmarks.
- **Resumption context:** The durable takeaway is: Introduces MADDPG with centralized critics and decentralized actors. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P186 — QMIX: Monotonic Value Function Factorisation for Deep Multi-Agent Reinforcement Learning

- **Central question / objective:** Factorizes joint action values under a monotonicity constraint for cooperative agents.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Optional specialization
- **Prerequisites:** Session 2; L1–L2.
- **Papers:** [P186 — QMIX: Monotonic Value Function Factorisation for Deep Multi-Agent Reinforcement Learning](https://proceedings.mlr.press/v80/rashid18a.html)
- **Supporting materials:** R001, R004
- **Concepts covered:** Factorizes joint action values under a monotonicity constraint for cooperative agents. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in multi-agent reinforcement learning.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P187). Master lineage note: Major value-decomposition lineage after independent Q-learning.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Monotonicity limits representable coordination; benchmark concentration.
- **Resumption context:** The durable takeaway is: Factorizes joint action values under a monotonicity constraint for cooperative agents. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P187 — The Surprising Effectiveness of PPO in Cooperative Multi-Agent Games

- **Central question / objective:** Shows a carefully implemented multi-agent PPO baseline can outperform specialized methods.
- **Stage / role:** Paper lineage — Modern Core; Critical
- **Status:** Optional specialization
- **Prerequisites:** Session 3; L1–L2.
- **Papers:** [P187 — The Surprising Effectiveness of PPO in Cooperative Multi-Agent Games](https://arxiv.org/abs/2103.01955)
- **Supporting materials:** R001, R004
- **Concepts covered:** Shows a carefully implemented multi-agent PPO baseline can outperform specialized methods. Preparation profile: Modern Core; Critical · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in multi-agent reinforcement learning.
- **Relationship in sequence:** Builds on paper session 3; leads to the topic reconstruction/comparison session. Master lineage note: Corrective empirical study emphasizing implementation and evaluation.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Benchmark suite remains game/simulation centric.
- **Resumption context:** The durable takeaway is: Shows a carefully implemented multi-agent PPO baseline can outperform specialized methods. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Compare MADDPG, QMIX, and MAPPO as centralized-critic, value-factorization, and policy-gradient approaches.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Optional specialization
- **Prerequisites:** Sessions 1–4
- **Papers:** [P185 — Multi-Agent Actor-Critic for Mixed Cooperative-Competitive Environments](https://arxiv.org/abs/1706.02275), [P186 — QMIX: Monotonic Value Function Factorisation for Deep Multi-Agent Reinforcement Learning](https://proceedings.mlr.press/v80/rashid18a.html), [P187 — The Surprising Effectiveness of PPO in Cooperative Multi-Agent Games](https://arxiv.org/abs/2103.01955)
- **Supporting materials:** R001, R004, R037
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 6. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** When activated, implement matched PettingZoo/TorchRL experiments and audit sensitivity to agent ordering, parameter sharing, observability, and team size.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Optional specialization
- **Prerequisites:** Sessions 1–5; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R001, R004, R037
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** When activated, implement matched PettingZoo/TorchRL experiments and audit sensitivity to agent ordering, parameter sharing, observability, and team size.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 7. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Optional specialization
- **Prerequisites:** Sessions 1–6; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R001, R004, R037
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 8. Topic synthesis and original research directions

- **Central question / objective:** When does multi-agent structure require dedicated algorithms rather than independent single-agent learning?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Optional specialization
- **Prerequisites:** Sessions 1–7
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R001, R004, R037
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: future multi-robot systems.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | L1–L2. |
| Closely related / cross-area | Independent branch with limited immediate overlap. |
| Outgoing capability | future multi-robot systems |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P185, P186, P187 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**When does multi-agent structure require dedicated algorithms rather than independent single-agent learning?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to future multi-robot systems is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 3 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** Propose adding the following supporting resources to the master supporting-material index: R037. They fill implementation/reconstruction gaps without changing the paper sequence.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
