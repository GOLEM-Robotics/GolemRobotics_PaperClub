# D1 — Robot-data collection, teleoperation, and dataset construction: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** D. Data, evaluation, and research systems  
**Execution status:** **Active Research Track**

## 1. Topic scope and target depth

### Covers

Teleoperation interfaces, synchronization, action-space normalization, multi-embodiment schemas, quality control, human video, and data scaling.

### Excludes

It excludes policy architecture details except where they impose data-schema requirements.

### Target competence

Design synchronized, versioned, auditable robot datasets and teleoperation systems; reason about operator/task/environment/embodiment diversity and scaling.

### Place in the wider curriculum

Data-engineering and collection track. Feeds L4, L6, E2, S1–S3, and D5.

## 2. Execution status and completion boundary

- **Topic execution status:** Active Research Track
- **Planned sessions:** 11
- **Classification:** 10 required core · 1 advanced continuation · 0 optional specialization · 0 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 11, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 11

## 3. Dependencies and required foundations

- **Master prerequisites:** L3, F8.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Observation/action schemas, clocks and synchronization, calibration, teleoperation mappings, episode segmentation, quality flags, provenance, normalization, splits, and privacy/safety.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R017 — [LeRobot Documentation](https://huggingface.co/docs/lerobot/)** (Documentation and open framework): Dataset schema, teleoperation, policy training, evaluation, and low-cost hardware integration.
- **R018 — [robomimic Documentation](https://robomimic.github.io/)** (Documentation and benchmark recipes): Reference implementation for demonstration learning and benchmark audits.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: L3, F8.
        │
        ▼
S1 Topic-local foundations: Observation/action schemas, clocks and synchronization, calibration, teleoperation mappings, episode segmentation, quality flags, provenance, normalization, splits, and privacy/safety.
        │
        ▼
Paper lineage: P117 → P118 → P119 → P120 → P121 → P122
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► L4, L6, D5, E2, S1–S3
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for robot-data collection, teleoperation, and dataset construction and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** L3, F8.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R017, R018
- **Concepts covered:** Observation/action schemas, clocks and synchronization, calibration, teleoperation mappings, episode segmentation, quality flags, provenance, normalization, splits, and privacy/safety.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Teleoperation interfaces, synchronization, action-space normalization, multi-embodiment schemas, quality control, human video, and data scaling. Next, enter the ordered paper lineage.

### 2. P117 — RoboNet: Large-Scale Multi-Robot Learning

- **Central question / objective:** Introduces a multi-institution, multi-robot dataset and cross-platform predictive learning.
- **Stage / role:** Paper lineage — Foundation
- **Status:** Required core
- **Prerequisites:** Session 1; L3, F8.
- **Papers:** [P117 — RoboNet: Large-Scale Multi-Robot Learning](https://arxiv.org/abs/1910.11215)
- **Supporting materials:** R017, R018
- **Concepts covered:** Introduces a multi-institution, multi-robot dataset and cross-platform predictive learning. Preparation profile: Foundation · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in robot-data collection, teleoperation, and dataset construction.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P118). Master lineage note: Early open data-scaling and embodiment-diversity effort.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Heterogeneous quality and limited action semantics compared with newer datasets.
- **Resumption context:** The durable takeaway is: Introduces a multi-institution, multi-robot dataset and cross-platform predictive learning. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P118 — BridgeData V2: A Dataset for Robot Learning at Scale

- **Central question / objective:** Provides a large, diverse, language-labeled manipulation dataset collected across environments.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 2; L3, F8.
- **Papers:** [P118 — BridgeData V2: A Dataset for Robot Learning at Scale](https://arxiv.org/abs/2308.12952)
- **Supporting materials:** R017, R018
- **Concepts covered:** Provides a large, diverse, language-labeled manipulation dataset collected across environments. Preparation profile: Modern Core · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in robot-data collection, teleoperation, and dataset construction.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P119). Master lineage note: Major precursor and component of Open X-Embodiment.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Concentrated embodiment and data-collection protocol; quality variation remains.
- **Resumption context:** The durable takeaway is: Provides a large, diverse, language-labeled manipulation dataset collected across environments. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P119 — Open X-Embodiment: Robotic Learning Datasets and RT-X Models

- **Central question / objective:** Standardizes and mixes many robot datasets across embodiments and trains RT-X policies.
- **Stage / role:** Paper lineage — Seminal; Modern Core
- **Status:** Required core
- **Prerequisites:** Session 3; L3, F8.
- **Papers:** [P119 — Open X-Embodiment: Robotic Learning Datasets and RT-X Models](https://arxiv.org/abs/2310.08864)
- **Supporting materials:** R017, R018
- **Concepts covered:** Standardizes and mixes many robot datasets across embodiments and trains RT-X policies. Preparation profile: Seminal; Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in robot-data collection, teleoperation, and dataset construction.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P120). Master lineage note: Central data foundation for modern cross-embodiment policy research.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Action/observation heterogeneity, inconsistent labels, and benchmark leakage complicate conclusions.
- **Resumption context:** The durable takeaway is: Standardizes and mixes many robot datasets across embodiments and trains RT-X policies. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P120 — DROID: A Large-Scale In-the-Wild Robot Manipulation Dataset

- **Central question / objective:** Collects diverse real-world manipulation data across many institutions, scenes, operators, and tasks.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 4; L3, F8.
- **Papers:** [P120 — DROID: A Large-Scale In-the-Wild Robot Manipulation Dataset](https://arxiv.org/abs/2403.12945)
- **Supporting materials:** R017, R018
- **Concepts covered:** Collects diverse real-world manipulation data across many institutions, scenes, operators, and tasks. Preparation profile: Modern Core · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in robot-data collection, teleoperation, and dataset construction.
- **Relationship in sequence:** Builds on paper session 4; leads to the next paper in the master sequence (P121). Master lineage note: Extends Bridge/OXE toward decentralized in-the-wild collection.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Single primary robot setup and teleoperation style; language/action quality vary.
- **Resumption context:** The durable takeaway is: Collects diverse real-world manipulation data across many institutions, scenes, operators, and tasks. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. P121 — Mobile ALOHA: Learning Bimanual Mobile Manipulation with Low-Cost Whole-Body Teleoperation

- **Central question / objective:** Extends low-cost ALOHA teleoperation and ACT to mobile bimanual whole-body tasks.
- **Stage / role:** Paper lineage — Modern Core; Bridge
- **Status:** Required core
- **Prerequisites:** Session 5; L3, F8.
- **Papers:** [P121 — Mobile ALOHA: Learning Bimanual Mobile Manipulation with Low-Cost Whole-Body Teleoperation](https://arxiv.org/abs/2401.02117)
- **Supporting materials:** R017, R018
- **Concepts covered:** Extends low-cost ALOHA teleoperation and ACT to mobile bimanual whole-body tasks. Preparation profile: Modern Core; Bridge · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in robot-data collection, teleoperation, and dataset construction.
- **Relationship in sequence:** Builds on paper session 5; leads to the next paper in the master sequence (P122). Master lineage note: Connects hardware, data collection, and long-horizon imitation.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Platform-specific and demonstration-intensive.
- **Resumption context:** The durable takeaway is: Extends low-cost ALOHA teleoperation and ACT to mobile bimanual whole-body tasks. Continue by comparing its assumptions and evidence with the next lineage stage.

### 7. P122 — Data Scaling Laws in Imitation Learning for Robotic Manipulation

- **Central question / objective:** Measures how environments, objects, and demonstrations affect real-world generalization at substantial scale.
- **Stage / role:** Paper lineage — Modern Core; Critical
- **Status:** Advanced continuation
- **Prerequisites:** Session 6; L3, F8.
- **Papers:** [P122 — Data Scaling Laws in Imitation Learning for Robotic Manipulation](https://proceedings.iclr.cc/paper_files/paper/2025/hash/88b7b2c896506daabc8d3fd587055167-Abstract-Conference.html)
- **Supporting materials:** R017, R018
- **Concepts covered:** Measures how environments, objects, and demonstrations affect real-world generalization at substantial scale. Preparation profile: Modern Core; Critical · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in robot-data collection, teleoperation, and dataset construction.
- **Relationship in sequence:** Builds on paper session 6; leads to the topic reconstruction/comparison session. Master lineage note: Empirical bridge from language-model scaling ideas to robot data design.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Task and platform scope limit universal extrapolation.
- **Resumption context:** The durable takeaway is: Measures how environments, objects, and demonstrations affect real-world generalization at substantial scale. Continue by comparing its assumptions and evidence with the next lineage stage.

### 8. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Compare RoboNet, BridgeData V2, Open X-Embodiment, DROID, Mobile ALOHA, and data-scaling evidence as data-system designs.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–7
- **Papers:** [P117 — RoboNet: Large-Scale Multi-Robot Learning](https://arxiv.org/abs/1910.11215), [P118 — BridgeData V2: A Dataset for Robot Learning at Scale](https://arxiv.org/abs/2308.12952), [P119 — Open X-Embodiment: Robotic Learning Datasets and RT-X Models](https://arxiv.org/abs/2310.08864), [P120 — DROID: A Large-Scale In-the-Wild Robot Manipulation Dataset](https://arxiv.org/abs/2403.12945), [P121 — Mobile ALOHA: Learning Bimanual Mobile Manipulation with Low-Cost Whole-Body Teleoperation](https://arxiv.org/abs/2401.02117), [P122 — Data Scaling Laws in Imitation Learning for Robotic Manipulation](https://proceedings.iclr.cc/paper_files/paper/2025/hash/88b7b2c896506daabc8d3fd587055167-Abstract-Conference.html)
- **Supporting materials:** R017, R018
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 9. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Specify and implement a small dataset pipeline with capture, synchronization, validation, versioning, conversion, and quality dashboards.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–8; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R017, R018
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Specify and implement a small dataset pipeline with capture, synchronization, validation, versioning, conversion, and quality dashboards.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 10. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–9; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R017, R018
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 11. Topic synthesis and original research directions

- **Central question / objective:** Which data diversity and quality dimensions produce reusable policy capability rather than more redundant trajectories?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–10
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R017, R018
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: L4, L6, D5, E2, S1–S3.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | L3, F8. |
| Closely related / cross-area | Feeds L4, L6, E2, S1–S3, and D5. |
| Outgoing capability | L4, L6, D5, E2, S1–S3 |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P117, P118, P119, P120, P121, P122 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**Which data diversity and quality dimensions produce reusable policy capability rather than more redundant trajectories?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to L4, L6, D5, E2, S1–S3 is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 6 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** No change to topic boundary or primary-paper inventory is proposed.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
