# F2 — Optimization and deep-learning mechanics: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** A. Shared foundations  
**Execution status:** **Shared Core**

## 1. Topic scope and target depth

### Covers

Stochastic optimization, initialization, normalization, regularization, generalization, and failure modes of deep optimization.

### Excludes

It is not a broad introductory machine-learning course and excludes architecture-specific details covered in F3.

### Target competence

Derive and diagnose stochastic optimization behavior, select normalization/regularization choices, and identify optimization-induced confounds in downstream research.

### Place in the wider curriculum

Targeted foundation, not a general ML survey. Prerequisite for F3–F5 and all learned-policy topics.

## 2. Execution status and completion boundary

- **Topic execution status:** Shared Core
- **Planned sessions:** 9
- **Classification:** 9 required core · 0 advanced continuation · 0 optional specialization · 0 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 9, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 9

## 3. Dependencies and required foundations

- **Master prerequisites:** Calculus, linear algebra, probability, basic neural networks.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Gradients, stochastic estimators, conditioning, curvature intuition, learning-rate schedules, initialization, regularization, and train/validation behavior.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R011 — [Deep Learning](https://www.deeplearningbook.org/)** (Open textbook): Targeted chapters for optimization, regularization, sequence models, and generative modeling.
- **R012 — [Dive into Deep Learning](https://d2l.ai/)** (Interactive open textbook): Implementation-oriented prerequisite repair for uneven member backgrounds.
- **R013 — [Stanford CS231n](https://cs231n.github.io/)** (Lecture notes): Targeted computer-vision and optimization foundation.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: Calculus, linear algebra, probability, basic neural networks.
        │
        ▼
S1 Topic-local foundations: Gradients, stochastic estimators, conditioning, curvature intuition, learning-rate schedules, initialization, regularization, and train/validation behavior.
        │
        ▼
Paper lineage: P005 → P006 → P007 → P008
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► F3–F5, P1, L1–L8, D3–D4
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for optimization and deep-learning mechanics and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** Calculus, linear algebra, probability, basic neural networks.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R011, R012, R013
- **Concepts covered:** Gradients, stochastic estimators, conditioning, curvature intuition, learning-rate schedules, initialization, regularization, and train/validation behavior.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Stochastic optimization, initialization, normalization, regularization, generalization, and failure modes of deep optimization. Next, enter the ordered paper lineage.

### 2. P005 — A Stochastic Approximation Method

- **Central question / objective:** Establishes stochastic approximation, the conceptual ancestor of stochastic gradient methods.
- **Stage / role:** Paper lineage — Foundation
- **Status:** Required core
- **Prerequisites:** Session 1; Calculus, linear algebra, probability, basic neural networks.
- **Papers:** [P005 — A Stochastic Approximation Method](https://doi.org/10.1214/aoms/1177729586)
- **Supporting materials:** R011, R012
- **Concepts covered:** Establishes stochastic approximation, the conceptual ancestor of stochastic gradient methods. Preparation profile: Foundation · Advanced · High; derivation-heavy
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in optimization and deep-learning mechanics.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P006). Master lineage note: Foundation for all optimization and RL updates.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Historical notation and assumptions; not a practical deep-learning recipe.
- **Resumption context:** The durable takeaway is: Establishes stochastic approximation, the conceptual ancestor of stochastic gradient methods. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P006 — Adam: A Method for Stochastic Optimization

- **Central question / objective:** Introduces adaptive first- and second-moment optimization used throughout modern deep learning.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 2; Calculus, linear algebra, probability, basic neural networks.
- **Papers:** [P006 — Adam: A Method for Stochastic Optimization](https://arxiv.org/abs/1412.6980)
- **Supporting materials:** R011, R012
- **Concepts covered:** Introduces adaptive first- and second-moment optimization used throughout modern deep learning. Preparation profile: Modern Core · Intermediate · Low–Medium; focus algorithm and bias correction
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in optimization and deep-learning mechanics.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P007). Master lineage note: Follows stochastic approximation; precedes AdamW.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Known convergence/pathology caveats and strong dependence on schedules.
- **Resumption context:** The durable takeaway is: Introduces adaptive first- and second-moment optimization used throughout modern deep learning. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P007 — Decoupled Weight Decay Regularization

- **Central question / objective:** Separates weight decay from gradient-based L2 regularization in adaptive optimizers.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 3; Calculus, linear algebra, probability, basic neural networks.
- **Papers:** [P007 — Decoupled Weight Decay Regularization](https://arxiv.org/abs/1711.05101)
- **Supporting materials:** R011, R012
- **Concepts covered:** Separates weight decay from gradient-based L2 regularization in adaptive optimizers. Preparation profile: Modern Core · Intermediate · Low
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in optimization and deep-learning mechanics.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P008). Master lineage note: Corrects a common Adam regularization mistake; relevant to F5/D3.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Does not determine optimal schedules or regularization strengths.
- **Resumption context:** The durable takeaway is: Separates weight decay from gradient-based L2 regularization in adaptive optimizers. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P008 — Batch Normalization: Accelerating Deep Network Training by Reducing Internal Covariate Shift

- **Central question / objective:** Introduces batch normalization and exposes the interaction between normalization, optimization, and train/eval behavior.
- **Stage / role:** Paper lineage — Foundation
- **Status:** Required core
- **Prerequisites:** Session 4; Calculus, linear algebra, probability, basic neural networks.
- **Papers:** [P008 — Batch Normalization: Accelerating Deep Network Training by Reducing Internal Covariate Shift](https://proceedings.mlr.press/v37/ioffe15.html)
- **Supporting materials:** R011, R012
- **Concepts covered:** Introduces batch normalization and exposes the interaction between normalization, optimization, and train/eval behavior. Preparation profile: Foundation · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in optimization and deep-learning mechanics.
- **Relationship in sequence:** Builds on paper session 4; leads to the topic reconstruction/comparison session. Master lineage note: Precedes later LayerNorm/normalization choices in Transformers and policies.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Original explanatory mechanism is debated; small-batch and non-i.i.d. issues matter in robotics.
- **Resumption context:** The durable takeaway is: Introduces batch normalization and exposes the interaction between normalization, optimization, and train/eval behavior. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Derive SGD/Adam/AdamW update rules and analyze where normalization changes the optimization problem.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–5
- **Papers:** [P005 — A Stochastic Approximation Method](https://doi.org/10.1214/aoms/1177729586), [P006 — Adam: A Method for Stochastic Optimization](https://arxiv.org/abs/1412.6980), [P007 — Decoupled Weight Decay Regularization](https://arxiv.org/abs/1711.05101), [P008 — Batch Normalization: Accelerating Deep Network Training by Reducing Internal Covariate Shift](https://proceedings.mlr.press/v37/ioffe15.html)
- **Supporting materials:** R011, R012, R013
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 7. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Implement a small controlled optimizer study with matched compute, seeds, logging, and failure diagnostics.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–6; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R011, R012, R013
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Implement a small controlled optimizer study with matched compute, seeds, logging, and failure diagnostics.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 8. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–7; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R011, R012, R013
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 9. Topic synthesis and original research directions

- **Central question / objective:** Which optimization decisions are scientific variables rather than harmless implementation details?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–8
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R011, R012, R013
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: F3–F5, P1, L1–L8, D3–D4.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | Calculus, linear algebra, probability, basic neural networks. |
| Closely related / cross-area | Prerequisite for F3–F5 and all learned-policy topics. |
| Outgoing capability | F3–F5, P1, L1–L8, D3–D4 |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P005, P006, P007, P008 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**Which optimization decisions are scientific variables rather than harmless implementation details?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to F3–F5, P1, L1–L8, D3–D4 is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 4 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** No change to topic boundary or primary-paper inventory is proposed.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
