# E3 — Embodied memory, agentic control, self-improvement, and world-action models: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** E. Language, multimodality, and embodied reasoning  
**Execution status:** **Frontier Watchlist**

## 1. Topic scope and target depth

### Covers

Long/short-term memory, test-time adaptation, skill discovery, autonomous data loops, reward models, planners above VLAs, and predictive action-conditioned models.

### Excludes

It does not promote fast-moving proprietary systems into the durable core without independent evidence, code, and stable metadata.

### Target competence

Maintain a technically informed watchlist and experimental hypotheses for memory, test-time adaptation, autonomous data/reward loops, self-improvement, and world-action models.

### Place in the wider curriculum

Fast-moving integration frontier. Monitored frontier; promote only after independent evidence and reproducibility mature.

## 2. Execution status and completion boundary

- **Topic execution status:** Frontier Watchlist
- **Planned sessions:** 10
- **Classification:** 0 required core · 0 advanced continuation · 0 optional specialization · 10 frontier continuation
- **Completion boundary:** This topic has no durable required-core completion claim. Completion means maintaining the watchlist, reconstruction, falsification tests, and promotion criteria through the final synthesis session.
- **Required core endpoint:** Session N/A

## 3. Dependencies and required foundations

- **Master prerequisites:** E1–E2, P4–P5, L4–L5, D5.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Persistent and episodic memory, context scaling, test-time training, skill/reward discovery, autonomous data collection, planner-policy interfaces, and promotion criteria.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R014 — [Stanford CS224n](https://web.stanford.edu/class/cs224n/)** (Lecture notes): Transformer, language-model, and alignment prerequisites.
- **R017 — [LeRobot Documentation](https://huggingface.co/docs/lerobot/)** (Documentation and open framework): Dataset schema, teleoperation, policy training, evaluation, and low-cost hardware integration.
- **R023 — [A Survey of Vision-Language-Action Models for Robotics: Towards Real-World Applications](https://arxiv.org/abs/2510.07077)** (Survey): Current full-stack map of VLA architectures, data, hardware, and evaluation; use for navigation, not as a replacement for primary papers.
- **R026 — [A Survey on Model-Based Reinforcement Learning](https://arxiv.org/abs/2006.16712)** (Survey): Taxonomy of learned models, planning, uncertainty, and policy learning.
- **R032 — [Habitat Lab Documentation](https://aihabitat.org/docs/habitat-lab/)** (Embodied-agent framework documentation): Navigation/embodied-agent task definitions, vectorized environments, datasets, evaluation, and hierarchical-agent experiments.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: E1–E2, P4–P5, L4–L5, D5.
        │
        ▼
S1 Topic-local foundations: Persistent and episodic memory, context scaling, test-time training, skill/reward discovery, autonomous data collection, planner-policy interfaces, and promotion criteria.
        │
        ▼
Paper lineage: P158 → P159 → P160 → P161 → P162
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► future revisions to P5, L4–L5, D5, and E2
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for embodied memory, agentic control, self-improvement, and world-action models and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Frontier continuation
- **Prerequisites:** E1–E2, P4–P5, L4–L5, D5.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R014, R017, R023, R026, R032
- **Concepts covered:** Persistent and episodic memory, context scaling, test-time training, skill/reward discovery, autonomous data collection, planner-policy interfaces, and promotion criteria.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Long/short-term memory, test-time adaptation, skill discovery, autonomous data loops, reward models, planners above VLAs, and predictive action-conditioned models. Next, enter the ordered paper lineage.

### 2. P158 — VLAs with Long and Short-Term Memory

- **Central question / objective:** Introduces Multi-scale Embodied Memory with compressed video history and textual long-term memory for tasks lasting many minutes.
- **Stage / role:** Paper lineage — Frontier
- **Status:** Frontier continuation
- **Prerequisites:** Session 1; E1–E2, P4–P5, L4–L5, D5.
- **Papers:** [P158 — VLAs with Long and Short-Term Memory](https://www.pi.website/research/memory)
- **Supporting materials:** R014, R017
- **Concepts covered:** Introduces Multi-scale Embodied Memory with compressed video history and textual long-term memory for tasks lasting many minutes. Preparation profile: Frontier · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in embodied memory, agentic control, self-improvement, and world-action models.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P159). Master lineage note: Extends π0.6/π0.5 toward partial observability, adaptation, and long-horizon execution.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Private data/model and very recent evidence; memory summaries can introduce causal confusion.
- **Resumption context:** The durable takeaway is: Introduces Multi-scale Embodied Memory with compressed video history and textual long-term memory for tasks lasting many minutes. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P159 — π0.7: a Steerable Model with Emergent Capabilities

- **Central question / objective:** Combines heterogeneous robot, human, and autonomous data with multimodal conditioning and visual subgoals to improve steerability and compositional generalization.
- **Stage / role:** Paper lineage — Frontier
- **Status:** Frontier continuation
- **Prerequisites:** Session 2; E1–E2, P4–P5, L4–L5, D5.
- **Papers:** [P159 — π0.7: a Steerable Model with Emergent Capabilities](https://www.pi.website/blog/pi07)
- **Supporting materials:** R014, R017
- **Concepts covered:** Combines heterogeneous robot, human, and autonomous data with multimodal conditioning and visual subgoals to improve steerability and compositional generalization. Preparation profile: Frontier · Expert · High; inspect paper, data/conditioning design, evaluation protocol, and omitted details
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in embodied memory, agentic control, self-improvement, and world-action models.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P160). Master lineage note: Builds on π0/π0.5, memory, and RL-specialist distillation.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Company-authored technical report; model, training data, and full independent reproduction are unavailable.
- **Resumption context:** The durable takeaway is: Combines heterogeneous robot, human, and autonomous data with multimodal conditioning and visual subgoals to improve steerability and compositional generalization. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P160 — Vesta: A Generalist Embodied Reasoning Model

- **Central question / objective:** Combines explicit observation–progress–reasoning–action memory with a low-level robot actor.
- **Stage / role:** Paper lineage — Frontier
- **Status:** Frontier continuation
- **Prerequisites:** Session 3; E1–E2, P4–P5, L4–L5, D5.
- **Papers:** [P160 — Vesta: A Generalist Embodied Reasoning Model](https://research.nvidia.com/labs/gear/vesta/)
- **Supporting materials:** R014, R017
- **Concepts covered:** Combines explicit observation–progress–reasoning–action memory with a low-level robot actor. Preparation profile: Frontier · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in embodied memory, agentic control, self-improvement, and world-action models.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P161). Master lineage note: Planner-above-VLA alternative to end-to-end memory models.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Very recent, organization-specific stack and limited task/platform evaluation.
- **Resumption context:** The durable takeaway is: Combines explicit observation–progress–reasoning–action memory with a low-level robot actor. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P161 — RoboTTT: Context Scaling for Robot Policies

- **Central question / objective:** Studies very long policy context and in-context adaptation learned from intervention histories.
- **Stage / role:** Paper lineage — Frontier
- **Status:** Frontier continuation
- **Prerequisites:** Session 4; E1–E2, P4–P5, L4–L5, D5.
- **Papers:** [P161 — RoboTTT: Context Scaling for Robot Policies](https://research.nvidia.com/labs/gear/robottt/)
- **Supporting materials:** R014, R017
- **Concepts covered:** Studies very long policy context and in-context adaptation learned from intervention histories. Preparation profile: Frontier · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in embodied memory, agentic control, self-improvement, and world-action models.
- **Relationship in sequence:** Builds on paper session 4; leads to the next paper in the master sequence (P162). Master lineage note: Connects algorithm distillation, memory, and test-time policy improvement.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: New and not independently reproduced; context cost and failure modes need analysis.
- **Resumption context:** The durable takeaway is: Studies very long policy context and in-context adaptation learned from intervention histories. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. P162 — ENPIRE: Agentic Robot Policy Self-Improvement in the Real World

- **Central question / objective:** Builds an agentic loop for autonomous policy improvement and real-world data acquisition.
- **Stage / role:** Paper lineage — Frontier
- **Status:** Frontier continuation
- **Prerequisites:** Session 5; E1–E2, P4–P5, L4–L5, D5.
- **Papers:** [P162 — ENPIRE: Agentic Robot Policy Self-Improvement in the Real World](https://arxiv.org/abs/2606.19980)
- **Supporting materials:** R014, R017
- **Concepts covered:** Builds an agentic loop for autonomous policy improvement and real-world data acquisition. Preparation profile: Frontier · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in embodied memory, agentic control, self-improvement, and world-action models.
- **Relationship in sequence:** Builds on paper session 5; leads to the topic reconstruction/comparison session. Master lineage note: Links offline-to-online RL, reward/success models, and E2 policies.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Very recent; safety, human oversight, and reproducibility are unresolved.
- **Resumption context:** The durable takeaway is: Builds an agentic loop for autonomous policy improvement and real-world data acquisition. Continue by comparing its assumptions and evidence with the next lineage stage.

### 7. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Compare current memory, steerability, reasoning, context-scaling, and self-improvement claims without treating demonstrations as established evidence.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Frontier continuation
- **Prerequisites:** Sessions 1–6
- **Papers:** [P158 — VLAs with Long and Short-Term Memory](https://www.pi.website/research/memory), [P159 — π0.7: a Steerable Model with Emergent Capabilities](https://www.pi.website/blog/pi07), [P160 — Vesta: A Generalist Embodied Reasoning Model](https://research.nvidia.com/labs/gear/vesta/), [P161 — RoboTTT: Context Scaling for Robot Policies](https://research.nvidia.com/labs/gear/robottt/), [P162 — ENPIRE: Agentic Robot Policy Self-Improvement in the Real World](https://arxiv.org/abs/2606.19980)
- **Supporting materials:** R014, R017, R023, R026, R032
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 8. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Design lightweight falsification tests or interface prototypes for one frontier claim; prioritize benchmarkable hypotheses over full reproduction.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Frontier continuation
- **Prerequisites:** Sessions 1–7; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R014, R017, R023, R026, R032
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Design lightweight falsification tests or interface prototypes for one frontier claim; prioritize benchmarkable hypotheses over full reproduction.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 9. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Frontier continuation
- **Prerequisites:** Sessions 1–8; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R014, R017, R023, R026, R032
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 10. Topic synthesis and original research directions

- **Central question / objective:** Which frontier mechanisms materially change the durable embodied-intelligence lineage, and what evidence would justify promotion?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Frontier continuation
- **Prerequisites:** Sessions 1–9
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R014, R017, R023, R026, R032
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: future revisions to P5, L4–L5, D5, and E2.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | E1–E2, P4–P5, L4–L5, D5. |
| Closely related / cross-area | Monitored frontier; promote only after independent evidence and reproducibility mature. |
| Outgoing capability | future revisions to P5, L4–L5, D5, and E2 |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P158, P159, P160, P161, P162 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**Which frontier mechanisms materially change the durable embodied-intelligence lineage, and what evidence would justify promotion?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to future revisions to P5, L4–L5, D5, and E2 is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 5 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** Propose adding the following supporting resources to the master supporting-material index: R032. They fill implementation/reconstruction gaps without changing the paper sequence.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
