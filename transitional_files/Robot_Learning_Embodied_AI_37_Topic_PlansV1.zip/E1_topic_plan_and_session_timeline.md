# E1 — Language-conditioned robotics, grounding, and task planning: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** E. Language, multimodality, and embodied reasoning  
**Execution status:** **Active Research Track**

## 1. Topic scope and target depth

### Covers

Affordance grounding, code/program generation, multimodal prompts, object-centric planning, high-level/low-level decomposition, and embodied VLMs.

### Excludes

It excludes end-to-end continuous VLA training, which belongs to E2, and purely linguistic planning without physical grounding.

### Target competence

Design and critique language-conditioned robot systems that connect semantic intent to affordances, programs, object-centric states, motion plans, and feedback.

### Place in the wider curriculum

Embodied reasoning lineage before end-to-end VLAs. Bridge from semantic models to E2 and E3.

## 2. Execution status and completion boundary

- **Topic execution status:** Active Research Track
- **Planned sessions:** 11
- **Classification:** 10 required core · 1 advanced continuation · 0 optional specialization · 0 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 11, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 11

## 3. Dependencies and required foundations

- **Master prerequisites:** F3–F5, P1–P3, F7.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Grounding, affordance/value functions, prompt/state representations, code generation, tool APIs, planning hierarchies, object-centric scenes, and execution monitoring.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R014 — [Stanford CS224n](https://web.stanford.edu/class/cs224n/)** (Lecture notes): Transformer, language-model, and alignment prerequisites.
- **R023 — [A Survey of Vision-Language-Action Models for Robotics: Towards Real-World Applications](https://arxiv.org/abs/2510.07077)** (Survey): Current full-stack map of VLA architectures, data, hardware, and evaluation; use for navigation, not as a replacement for primary papers.
- **R028 — [MIT Robotic Manipulation: Perception, Planning, and Control](https://manipulation.csail.mit.edu/)** (Open course notes and exercises): Integrated manipulation stack connecting geometry, perception, planning, contact, control, and learning.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: F3–F5, P1–P3, F7.
        │
        ▼
S1 Topic-local foundations: Grounding, affordance/value functions, prompt/state representations, code generation, tool APIs, planning hierarchies, object-centric scenes, and execution monitoring.
        │
        ▼
Paper lineage: P144 → P145 → P146 → P147 → P148 → P149
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► E2–E3, S1, S4, S8
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for language-conditioned robotics, grounding, and task planning and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** F3–F5, P1–P3, F7.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R014, R023, R028
- **Concepts covered:** Grounding, affordance/value functions, prompt/state representations, code generation, tool APIs, planning hierarchies, object-centric scenes, and execution monitoring.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Affordance grounding, code/program generation, multimodal prompts, object-centric planning, high-level/low-level decomposition, and embodied VLMs. Next, enter the ordered paper lineage.

### 2. P144 — Do As I Can, Not As I Say: Grounding Language in Robotic Affordances

- **Central question / objective:** Introduces SayCan: combines language-model skill likelihood with learned affordance/value estimates.
- **Stage / role:** Paper lineage — Seminal; Bridge
- **Status:** Required core
- **Prerequisites:** Session 1; F3–F5, P1–P3, F7.
- **Papers:** [P144 — Do As I Can, Not As I Say: Grounding Language in Robotic Affordances](https://arxiv.org/abs/2204.01691)
- **Supporting materials:** R014, R023
- **Concepts covered:** Introduces SayCan: combines language-model skill likelihood with learned affordance/value estimates. Preparation profile: Seminal; Bridge · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in language-conditioned robotics, grounding, and task planning.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P145). Master lineage note: Canonical high-level semantic planner plus low-level skills architecture.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Requires a predefined skill library and value functions; language model is not grounded by itself.
- **Resumption context:** The durable takeaway is: Introduces SayCan: combines language-model skill likelihood with learned affordance/value estimates. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P145 — Code as Policies: Language Model Programs for Embodied Control

- **Central question / objective:** Uses code-generating language models to compose perception and control APIs.
- **Stage / role:** Paper lineage — Bridge
- **Status:** Required core
- **Prerequisites:** Session 2; F3–F5, P1–P3, F7.
- **Papers:** [P145 — Code as Policies: Language Model Programs for Embodied Control](https://arxiv.org/abs/2209.07753)
- **Supporting materials:** R014, R023
- **Concepts covered:** Uses code-generating language models to compose perception and control APIs. Preparation profile: Bridge · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in language-conditioned robotics, grounding, and task planning.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P146). Master lineage note: Alternative to end-to-end policies; enables explicit structure and tool use.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Execution safety, API coverage, and hallucinated code are major risks.
- **Resumption context:** The durable takeaway is: Uses code-generating language models to compose perception and control APIs. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P146 — Inner Monologue: Embodied Reasoning through Planning with Language Models

- **Central question / objective:** Feeds success, scene, and human feedback back into language-model planning loops.
- **Stage / role:** Paper lineage — Bridge
- **Status:** Required core
- **Prerequisites:** Session 3; F3–F5, P1–P3, F7.
- **Papers:** [P146 — Inner Monologue: Embodied Reasoning through Planning with Language Models](https://arxiv.org/abs/2207.05608)
- **Supporting materials:** R014, R023
- **Concepts covered:** Feeds success, scene, and human feedback back into language-model planning loops. Preparation profile: Bridge · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in language-conditioned robotics, grounding, and task planning.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P147). Master lineage note: Precursor to memory/tool-using embodied agents.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Relies on external modules and brittle textual state summaries.
- **Resumption context:** The durable takeaway is: Feeds success, scene, and human feedback back into language-model planning loops. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P147 — PaLM-E: An Embodied Multimodal Language Model

- **Central question / objective:** Injects continuous sensor and visual embeddings into a language model for embodied reasoning and transfer.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 4; F3–F5, P1–P3, F7.
- **Papers:** [P147 — PaLM-E: An Embodied Multimodal Language Model](https://arxiv.org/abs/2303.03378)
- **Supporting materials:** R014, R023
- **Concepts covered:** Injects continuous sensor and visual embeddings into a language model for embodied reasoning and transfer. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in language-conditioned robotics, grounding, and task planning.
- **Relationship in sequence:** Builds on paper session 4; leads to the next paper in the master sequence (P148). Master lineage note: Bridge from VLMs to multimodal embodied models; precedes Gemini Robotics.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Large proprietary model/data/compute and mainly high-level outputs.
- **Resumption context:** The durable takeaway is: Injects continuous sensor and visual embeddings into a language model for embodied reasoning and transfer. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. P148 — VoxPoser: Composable 3D Value Maps for Robotic Manipulation with Language Models

- **Central question / objective:** Uses language models and open-vocabulary perception to compose 3D value maps for motion planning.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 5; F3–F5, P1–P3, F7.
- **Papers:** [P148 — VoxPoser: Composable 3D Value Maps for Robotic Manipulation with Language Models](https://arxiv.org/abs/2307.05973)
- **Supporting materials:** R014, R023
- **Concepts covered:** Uses language models and open-vocabulary perception to compose 3D value maps for motion planning. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in language-conditioned robotics, grounding, and task planning.
- **Relationship in sequence:** Builds on paper session 5; leads to the next paper in the master sequence (P149). Master lineage note: Combines E1 semantic reasoning with P3 geometry and F7 planning.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Depends on reliable perception, generated code, and hand-designed value-map interfaces.
- **Resumption context:** The durable takeaway is: Uses language models and open-vocabulary perception to compose 3D value maps for motion planning. Continue by comparing its assumptions and evidence with the next lineage stage.

### 7. P149 — VIMA: General Robot Manipulation with Multimodal Prompts

- **Central question / objective:** Conditions a Transformer policy on interleaved text and image prompts across diverse manipulation tasks.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Advanced continuation
- **Prerequisites:** Session 6; F3–F5, P1–P3, F7.
- **Papers:** [P149 — VIMA: General Robot Manipulation with Multimodal Prompts](https://arxiv.org/abs/2210.03094)
- **Supporting materials:** R014, R023
- **Concepts covered:** Conditions a Transformer policy on interleaved text and image prompts across diverse manipulation tasks. Preparation profile: Modern Core · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in language-conditioned robotics, grounding, and task planning.
- **Relationship in sequence:** Builds on paper session 6; leads to the topic reconstruction/comparison session. Master lineage note: Bridge from language-conditioned policy learning to multimodal prompting and steerability.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Simulation benchmark and discrete task structure limit real-world conclusions.
- **Resumption context:** The durable takeaway is: Conditions a Transformer policy on interleaved text and image prompts across diverse manipulation tasks. Continue by comparing its assumptions and evidence with the next lineage stage.

### 8. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Trace SayCan, Code as Policies, PaLM-E, VoxPoser, Inner Monologue, and RT-H as alternative semantic-to-action interfaces.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–7
- **Papers:** [P144 — Do As I Can, Not As I Say: Grounding Language in Robotic Affordances](https://arxiv.org/abs/2204.01691), [P145 — Code as Policies: Language Model Programs for Embodied Control](https://arxiv.org/abs/2209.07753), [P146 — Inner Monologue: Embodied Reasoning through Planning with Language Models](https://arxiv.org/abs/2207.05608), [P147 — PaLM-E: An Embodied Multimodal Language Model](https://arxiv.org/abs/2303.03378), [P148 — VoxPoser: Composable 3D Value Maps for Robotic Manipulation with Language Models](https://arxiv.org/abs/2307.05973), [P149 — VIMA: General Robot Manipulation with Multimodal Prompts](https://arxiv.org/abs/2210.03094)
- **Supporting materials:** R014, R023, R028
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 9. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Build a small language-conditioned planner or code/constraint generator connected to a simulator; evaluate grounding errors, feasibility, recovery, and prompt sensitivity.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–8; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R014, R023, R028
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Build a small language-conditioned planner or code/constraint generator connected to a simulator; evaluate grounding errors, feasibility, recovery, and prompt sensitivity.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 10. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–9; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R014, R023, R028
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 11. Topic synthesis and original research directions

- **Central question / objective:** Where should language-model reasoning stop and structured perception, planning, control, and verification begin?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–10
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R014, R023, R028
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: E2–E3, S1, S4, S8.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | F3–F5, P1–P3, F7. |
| Closely related / cross-area | Bridge from semantic models to E2 and E3. |
| Outgoing capability | E2–E3, S1, S4, S8 |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P144, P145, P146, P147, P148, P149 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**Where should language-model reasoning stop and structured perception, planning, control, and verification begin?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to E2–E3, S1, S4, S8 is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 6 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** Propose adding the following supporting resources to the master supporting-material index: R028. They fill implementation/reconstruction gaps without changing the paper sequence.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
