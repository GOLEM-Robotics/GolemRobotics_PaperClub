# S2 — Tactile sensing and dexterous manipulation: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** F. Specialization branches  
**Execution status:** **Specialization**

## 1. Topic scope and target depth

### Covers

Optical tactile sensing, visuotactile representation, contact-state estimation, dexterous hands, and tactile-reactive policies.

### Excludes

It excludes general haptics and hardware design not tied to perception/control learning.

### Target competence

Understand tactile sensor physics and representations, fuse tactile/vision signals, estimate contact state, and evaluate tactile-reactive policies for dexterous tasks.

### Place in the wider curriculum

Hardware-dependent specialization. Crosses perception, contact control, and imitation/RL.

## 2. Execution status and completion boundary

- **Topic execution status:** Specialization
- **Planned sessions:** 9
- **Classification:** 7 required core · 1 advanced continuation · 0 optional specialization · 1 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 9, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 9

## 3. Dependencies and required foundations

- **Master prerequisites:** S1, P1, F6.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Optical tactile sensing, deformation/contact images, calibration, slip/contact states, visuotactile alignment, tactile latency, hand kinematics, and dexterity metrics.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R005 — [Modern Robotics: Mechanics, Planning, and Control](https://modernrobotics.northwestern.edu/)** (Open textbook/course): Kinematics, dynamics, Jacobians, control, and planning prerequisites.
- **R018 — [robomimic Documentation](https://robomimic.github.io/)** (Documentation and benchmark recipes): Reference implementation for demonstration learning and benchmark audits.
- **R019 — [ManiSkill Documentation](https://maniskill.readthedocs.io/)** (Simulation/benchmark documentation): High-throughput manipulation experiments and standardized evaluation.
- **R028 — [MIT Robotic Manipulation: Perception, Planning, and Control](https://manipulation.csail.mit.edu/)** (Open course notes and exercises): Integrated manipulation stack connecting geometry, perception, planning, contact, control, and learning.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: S1, P1, F6.
        │
        ▼
S1 Topic-local foundations: Optical tactile sensing, deformation/contact images, calibration, slip/contact states, visuotactile alignment, tactile latency, hand kinematics, and dexterity metrics.
        │
        ▼
Paper lineage: P168 → P169 → P170 → P171
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► dexterous manipulation and contact-rich E2 work
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for tactile sensing and dexterous manipulation and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** S1, P1, F6.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R005, R018, R019, R028
- **Concepts covered:** Optical tactile sensing, deformation/contact images, calibration, slip/contact states, visuotactile alignment, tactile latency, hand kinematics, and dexterity metrics.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Optical tactile sensing, visuotactile representation, contact-state estimation, dexterous hands, and tactile-reactive policies. Next, enter the ordered paper lineage.

### 2. P168 — GelSight: High-Resolution Robot Tactile Sensors for Estimating Geometry and Force

- **Central question / objective:** Describes optical tactile sensing that captures detailed contact geometry and force cues.
- **Stage / role:** Paper lineage — Foundation
- **Status:** Required core
- **Prerequisites:** Session 1; S1, P1, F6.
- **Papers:** [P168 — GelSight: High-Resolution Robot Tactile Sensors for Estimating Geometry and Force](https://doi.org/10.3390/s17020276)
- **Supporting materials:** R005, R018
- **Concepts covered:** Describes optical tactile sensing that captures detailed contact geometry and force cues. Preparation profile: Foundation · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in tactile sensing and dexterous manipulation.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P169). Master lineage note: Hardware foundation for modern visuotactile learning.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Sensor fabrication, calibration, wear, and contact mechanics are significant.
- **Resumption context:** The durable takeaway is: Describes optical tactile sensing that captures detailed contact geometry and force cues. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P169 — DIGIT: A Novel Design for a Low-Cost Compact High-Resolution Tactile Sensor with Application to In-Hand Manipulation

- **Central question / objective:** Presents a compact manufacturable optical tactile sensor and manipulation demonstrations.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 2; S1, P1, F6.
- **Papers:** [P169 — DIGIT: A Novel Design for a Low-Cost Compact High-Resolution Tactile Sensor with Application to In-Hand Manipulation](https://arxiv.org/abs/2005.14679)
- **Supporting materials:** R005, R018
- **Concepts covered:** Presents a compact manufacturable optical tactile sensor and manipulation demonstrations. Preparation profile: Modern Core · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in tactile sensing and dexterous manipulation.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P170). Master lineage note: Accessible successor/complement to GelSight.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Optical artifacts, durability, and sensor-to-sensor variation matter.
- **Resumption context:** The durable takeaway is: Presents a compact manufacturable optical tactile sensor and manipulation demonstrations. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P170 — Learning Dexterous In-Hand Manipulation

- **Central question / objective:** Uses large-scale simulation, domain randomization, and recurrent policies for dexterous hand manipulation.
- **Stage / role:** Paper lineage — Seminal; Bridge
- **Status:** Advanced continuation
- **Prerequisites:** Session 3; S1, P1, F6.
- **Papers:** [P170 — Learning Dexterous In-Hand Manipulation](https://arxiv.org/abs/1808.00177)
- **Supporting materials:** R005, R018
- **Concepts covered:** Uses large-scale simulation, domain randomization, and recurrent policies for dexterous hand manipulation. Preparation profile: Seminal; Bridge · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in tactile sensing and dexterous manipulation.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P171). Master lineage note: Links L7 sim-to-real to dexterous control.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Exceptional compute, custom hardware, and sparse reproducibility.
- **Resumption context:** The durable takeaway is: Uses large-scale simulation, domain randomization, and recurrent policies for dexterous hand manipulation. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P171 — T-Rex: Tactile-Reactive Dexterous Manipulation

- **Central question / objective:** Uses tactile feedback for reactive dexterous manipulation under contact and perturbation.
- **Stage / role:** Paper lineage — Frontier
- **Status:** Frontier continuation
- **Prerequisites:** Session 4; S1, P1, F6.
- **Papers:** [P171 — T-Rex: Tactile-Reactive Dexterous Manipulation](https://arxiv.org/abs/2606.17055)
- **Supporting materials:** R005, R018
- **Concepts covered:** Uses tactile feedback for reactive dexterous manipulation under contact and perturbation. Preparation profile: Frontier · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in tactile sensing and dexterous manipulation.
- **Relationship in sequence:** Builds on paper session 4; leads to the topic reconstruction/comparison session. Master lineage note: Modern frontier connecting optical tactile sensing to generalist dexterity.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Very recent and specialized hardware/data; independent evidence pending.
- **Resumption context:** The durable takeaway is: Uses tactile feedback for reactive dexterous manipulation under contact and perturbation. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Trace GelSight/DIGIT sensor design into visuotactile learning and tactile-based dexterous control.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–5
- **Papers:** [P168 — GelSight: High-Resolution Robot Tactile Sensors for Estimating Geometry and Force](https://doi.org/10.3390/s17020276), [P169 — DIGIT: A Novel Design for a Low-Cost Compact High-Resolution Tactile Sensor with Application to In-Hand Manipulation](https://arxiv.org/abs/2005.14679), [P170 — Learning Dexterous In-Hand Manipulation](https://arxiv.org/abs/1808.00177), [P171 — T-Rex: Tactile-Reactive Dexterous Manipulation](https://arxiv.org/abs/2606.17055)
- **Supporting materials:** R005, R018, R019, R028
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 7. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Calibrate or simulate a tactile sensor, train a contact/slip representation or policy component, and compare visual-only versus visuotactile performance.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–6; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R005, R018, R019, R028
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Calibrate or simulate a tactile sensor, train a contact/slip representation or policy component, and compare visual-only versus visuotactile performance.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 8. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–7; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R005, R018, R019, R028
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 9. Topic synthesis and original research directions

- **Central question / objective:** Which manipulation failures are observable and correctable only through touch?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–8
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R005, R018, R019, R028
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: dexterous manipulation and contact-rich E2 work.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | S1, P1, F6. |
| Closely related / cross-area | Crosses perception, contact control, and imitation/RL. |
| Outgoing capability | dexterous manipulation and contact-rich E2 work |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P168, P169, P170, P171 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**Which manipulation failures are observable and correctable only through touch?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to dexterous manipulation and contact-rich E2 work is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 4 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** Propose adding the following supporting resources to the master supporting-material index: R028. They fill implementation/reconstruction gaps without changing the paper sequence.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
