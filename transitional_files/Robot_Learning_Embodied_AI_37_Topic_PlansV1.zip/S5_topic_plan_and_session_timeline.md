# S5 — Deformable objects, learned physics, and graph models: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** F. Specialization branches  
**Execution status:** **Optional**

## 1. Topic scope and target depth

### Covers

Object-centric relational models, graph-network simulators, cloth/rope manipulation, differentiable simulation, and material uncertainty.

### Excludes

It excludes rigid-body manipulation and generic graph learning not grounded in physical interaction.

### Target competence

Represent and predict relational/deformable dynamics, manipulate cloth/rope/materials, and reason about model uncertainty and differentiable/learned simulation.

### Place in the wider curriculum

Optional advanced branch. Links learned physics to difficult manipulation.

## 2. Execution status and completion boundary

- **Topic execution status:** Optional
- **Planned sessions:** 9
- **Classification:** 4 required core · 0 advanced continuation · 5 optional specialization · 0 frontier continuation
- **Completion boundary:** The topic is not part of the currently executable curriculum. If activated, its internal required core runs through Session 6; remaining sessions are optional specialization or frontier continuations.
- **Required core endpoint:** Session 6

## 3. Dependencies and required foundations

- **Master prerequisites:** F3–F4, F6, P3–P5.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Graphs and message passing, particle/mesh representations, material parameters, contact/topology, partial observability, learned simulators, and deformable-task metrics.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R006 — [Underactuated Robotics](https://underactuated.csail.mit.edu/)** (Open textbook/lecture notes): Nonlinear dynamics, optimal control, planning, and learning for physical systems.
- **R019 — [ManiSkill Documentation](https://maniskill.readthedocs.io/)** (Simulation/benchmark documentation): High-throughput manipulation experiments and standardized evaluation.
- **R021 — [Isaac Lab Documentation](https://isaac-sim.github.io/IsaacLab/)** (Simulation and robot-learning documentation): GPU-parallel robot-learning workflows, domain randomization, and deployment interfaces.
- **R026 — [A Survey on Model-Based Reinforcement Learning](https://arxiv.org/abs/2006.16712)** (Survey): Taxonomy of learned models, planning, uncertainty, and policy learning.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: F3–F4, F6, P3–P5.
        │
        ▼
S1 Topic-local foundations: Graphs and message passing, particle/mesh representations, material parameters, contact/topology, partial observability, learned simulators, and deformable-task metrics.
        │
        ▼
Paper lineage: P181 → P182 → P183 → P184
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► P5, D5, S1
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for deformable objects, learned physics, and graph models and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** F3–F4, F6, P3–P5.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R006, R019, R021, R026
- **Concepts covered:** Graphs and message passing, particle/mesh representations, material parameters, contact/topology, partial observability, learned simulators, and deformable-task metrics.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Object-centric relational models, graph-network simulators, cloth/rope manipulation, differentiable simulation, and material uncertainty. Next, enter the ordered paper lineage.

### 2. P181 — Interaction Networks for Learning about Objects, Relations and Physics

- **Central question / objective:** Introduces object–relation message passing for learned physical reasoning.
- **Stage / role:** Paper lineage — Foundation; Seminal
- **Status:** Required core
- **Prerequisites:** Session 1; F3–F4, F6, P3–P5.
- **Papers:** [P181 — Interaction Networks for Learning about Objects, Relations and Physics](https://arxiv.org/abs/1612.00222)
- **Supporting materials:** R006, R019
- **Concepts covered:** Introduces object–relation message passing for learned physical reasoning. Preparation profile: Foundation; Seminal · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in deformable objects, learned physics, and graph models.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P182). Master lineage note: Foundation for graph-network simulators and object-centric world models.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Requires object decomposition and struggles with perception from raw observations.
- **Resumption context:** The durable takeaway is: Introduces object–relation message passing for learned physical reasoning. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P182 — Learning to Simulate Complex Physics with Graph Networks

- **Central question / objective:** Learns particle-based simulators with message-passing graph networks across complex materials.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 2; F3–F4, F6, P3–P5.
- **Papers:** [P182 — Learning to Simulate Complex Physics with Graph Networks](https://proceedings.mlr.press/v119/sanchez-gonzalez20a.html)
- **Supporting materials:** R006, R019
- **Concepts covered:** Learns particle-based simulators with message-passing graph networks across complex materials. Preparation profile: Modern Core · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in deformable objects, learned physics, and graph models.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P183). Master lineage note: Develops Interaction Networks into scalable learned simulation.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Long-rollout error accumulation and particle representation costs remain.
- **Resumption context:** The durable takeaway is: Learns particle-based simulators with message-passing graph networks across complex materials. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P183 — SoftGym: Benchmarking Deep Reinforcement Learning for Deformable Object Manipulation

- **Central question / objective:** Provides simulation tasks and benchmarks for cloth, rope, and fluid manipulation.
- **Stage / role:** Paper lineage — Bridge
- **Status:** Optional specialization
- **Prerequisites:** Session 3; F3–F4, F6, P3–P5.
- **Papers:** [P183 — SoftGym: Benchmarking Deep Reinforcement Learning for Deformable Object Manipulation](https://arxiv.org/abs/2011.07215)
- **Supporting materials:** R006, R019
- **Concepts covered:** Provides simulation tasks and benchmarks for cloth, rope, and fluid manipulation. Preparation profile: Bridge · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in deformable objects, learned physics, and graph models.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P184). Master lineage note: Connects deformable physics to RL/IL evaluation.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Simulation fidelity and benchmark task design limit real transfer.
- **Resumption context:** The durable takeaway is: Provides simulation tasks and benchmarks for cloth, rope, and fluid manipulation. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P184 — DiffTaichi: Differentiable Programming for Physical Simulation

- **Central question / objective:** Presents differentiable high-performance physical simulation for gradient-based control and design.
- **Stage / role:** Paper lineage — Bridge to S7
- **Status:** Optional specialization
- **Prerequisites:** Session 4; F3–F4, F6, P3–P5.
- **Papers:** [P184 — DiffTaichi: Differentiable Programming for Physical Simulation](https://arxiv.org/abs/1910.00935)
- **Supporting materials:** R006, R019
- **Concepts covered:** Presents differentiable high-performance physical simulation for gradient-based control and design. Preparation profile: Bridge to S7 · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in deformable objects, learned physics, and graph models.
- **Relationship in sequence:** Builds on paper session 4; leads to the topic reconstruction/comparison session. Master lineage note: Connects learned physics, system identification, and co-design.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Differentiability and numerical stability do not eliminate model mismatch; specialized implementation.
- **Resumption context:** The durable takeaway is: Presents differentiable high-performance physical simulation for gradient-based control and design. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Connect interaction networks/graph simulators to deformable-object planning and learning without demonstrations.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–5
- **Papers:** [P181 — Interaction Networks for Learning about Objects, Relations and Physics](https://arxiv.org/abs/1612.00222), [P182 — Learning to Simulate Complex Physics with Graph Networks](https://proceedings.mlr.press/v119/sanchez-gonzalez20a.html), [P183 — SoftGym: Benchmarking Deep Reinforcement Learning for Deformable Object Manipulation](https://arxiv.org/abs/2011.07215), [P184 — DiffTaichi: Differentiable Programming for Physical Simulation](https://arxiv.org/abs/1910.00935)
- **Supporting materials:** R006, R019, R021, R026
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 7. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Train a graph dynamics model or reproduce a simple deformable manipulation task; test rollout horizon, topology/material shift, and planning utility.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Optional specialization
- **Prerequisites:** Sessions 1–6; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R006, R019, R021, R026
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Train a graph dynamics model or reproduce a simple deformable manipulation task; test rollout horizon, topology/material shift, and planning utility.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 8. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Optional specialization
- **Prerequisites:** Sessions 1–7; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R006, R019, R021, R026
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 9. Topic synthesis and original research directions

- **Central question / objective:** Which physical structure must be explicit for learned models of deformable objects to generalize?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Optional specialization
- **Prerequisites:** Sessions 1–8
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R006, R019, R021, R026
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: P5, D5, S1.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | F3–F4, F6, P3–P5. |
| Closely related / cross-area | Links learned physics to difficult manipulation. |
| Outgoing capability | P5, D5, S1 |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P181, P182, P183, P184 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**Which physical structure must be explicit for learned models of deformable objects to generalize?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to P5, D5, S1 is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 4 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** No change to topic boundary or primary-paper inventory is proposed.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
