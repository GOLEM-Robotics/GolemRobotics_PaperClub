# L7 — Sim-to-real transfer, system identification, and adaptation: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** C. Learning to act  
**Execution status:** **Active Research Track**

## 1. Topic scope and target depth

### Covers

Domain and dynamics randomization, simulator calibration, privileged learning, online adaptation, latency and actuator modeling, and robustness.

### Excludes

It excludes generic robustness augmentation without a physical-parameter or deployment hypothesis.

### Target competence

Model the reality gap, design domain/dynamics randomization and simulator adaptation, use privileged information correctly, and evaluate rapid adaptation under physical mismatch.

### Place in the wider curriculum

Required for physical-system competence. Connects simulation, physical deployment, locomotion, and manipulation.

## 2. Execution status and completion boundary

- **Topic execution status:** Active Research Track
- **Planned sessions:** 10
- **Classification:** 9 required core · 1 advanced continuation · 0 optional specialization · 0 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 10, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 10

## 3. Dependencies and required foundations

- **Master prerequisites:** F6–F8, L1–L2.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Parameter distributions, system identification, observability of dynamics, privileged learning, dynamics encoders, actuator/sensor latency, contact uncertainty, and robust evaluation.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R006 — [Underactuated Robotics](https://underactuated.csail.mit.edu/)** (Open textbook/lecture notes): Nonlinear dynamics, optimal control, planning, and learning for physical systems.
- **R019 — [ManiSkill Documentation](https://maniskill.readthedocs.io/)** (Simulation/benchmark documentation): High-throughput manipulation experiments and standardized evaluation.
- **R020 — [MuJoCo Documentation](https://mujoco.readthedocs.io/)** (Physics simulator documentation): Reliable dynamics/control simulation reference.
- **R021 — [Isaac Lab Documentation](https://isaac-sim.github.io/IsaacLab/)** (Simulation and robot-learning documentation): GPU-parallel robot-learning workflows, domain randomization, and deployment interfaces.
- **R024 — [Robot Learning from Randomized Simulations: A Review](https://arxiv.org/abs/2111.00956)** (Survey): Structured overview of domain randomization assumptions, methods, and limitations.
- **R030 — [ROS 2 Real-Time Programming Documentation](https://docs.ros.org/en/kilted/Tutorials/Demos/Real-Time-Programming.html)** (Official systems documentation): Deadline, jitter, memory-allocation, scheduling, and execution-path constraints for physical robot deployment.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: F6–F8, L1–L2.
        │
        ▼
S1 Topic-local foundations: Parameter distributions, system identification, observability of dynamics, privileged learning, dynamics encoders, actuator/sensor latency, contact uncertainty, and robust evaluation.
        │
        ▼
Paper lineage: P107 → P108 → P109 → P110 → P111
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► D5, S1, S3
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for sim-to-real transfer, system identification, and adaptation and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** F6–F8, L1–L2.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R006, R019, R020, R021, R024, R030
- **Concepts covered:** Parameter distributions, system identification, observability of dynamics, privileged learning, dynamics encoders, actuator/sensor latency, contact uncertainty, and robust evaluation.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Domain and dynamics randomization, simulator calibration, privileged learning, online adaptation, latency and actuator modeling, and robustness. Next, enter the ordered paper lineage.

### 2. P107 — Domain Randomization for Transferring Deep Neural Networks from Simulation to the Real World

- **Central question / objective:** Shows visual randomization can make real images appear as one variation of simulation.
- **Stage / role:** Paper lineage — Seminal
- **Status:** Required core
- **Prerequisites:** Session 1; F6–F8, L1–L2.
- **Papers:** [P107 — Domain Randomization for Transferring Deep Neural Networks from Simulation to the Real World](https://arxiv.org/abs/1703.06907)
- **Supporting materials:** R006, R019
- **Concepts covered:** Shows visual randomization can make real images appear as one variation of simulation. Preparation profile: Seminal · Intermediate · Low–Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in sim-to-real transfer, system identification, and adaptation.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P108). Master lineage note: Foundation for sim-to-real perception.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Manual randomization ranges and unrealistic variation can hurt transfer.
- **Resumption context:** The durable takeaway is: Shows visual randomization can make real images appear as one variation of simulation. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P108 — Sim-to-Real Transfer of Robotic Control with Dynamics Randomization

- **Central question / objective:** Randomizes physical parameters during training to transfer control policies.
- **Stage / role:** Paper lineage — Seminal; Bridge
- **Status:** Required core
- **Prerequisites:** Session 2; F6–F8, L1–L2.
- **Papers:** [P108 — Sim-to-Real Transfer of Robotic Control with Dynamics Randomization](https://arxiv.org/abs/1710.06537)
- **Supporting materials:** R006, R019
- **Concepts covered:** Randomizes physical parameters during training to transfer control policies. Preparation profile: Seminal; Bridge · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in sim-to-real transfer, system identification, and adaptation.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P109). Master lineage note: Extends domain randomization from vision to dynamics.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Coverage of real dynamics and actuator/latency modeling is critical.
- **Resumption context:** The durable takeaway is: Randomizes physical parameters during training to transfer control policies. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P109 — SimOpt: Learning to Adapt Simulators to Real-World Conditions

- **Central question / objective:** Updates simulator-parameter distributions from real trajectories to improve transfer.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 3; F6–F8, L1–L2.
- **Papers:** [P109 — SimOpt: Learning to Adapt Simulators to Real-World Conditions](https://arxiv.org/abs/1810.05687)
- **Supporting materials:** R006, R019
- **Concepts covered:** Updates simulator-parameter distributions from real trajectories to improve transfer. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in sim-to-real transfer, system identification, and adaptation.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P110). Master lineage note: System-identification complement to broad randomization.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Requires informative real rollouts and chosen simulator parameterization.
- **Resumption context:** The durable takeaway is: Updates simulator-parameter distributions from real trajectories to improve transfer. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P110 — Learning Agile and Dynamic Motor Skills for Legged Robots

- **Central question / objective:** Combines massively parallel simulation, dynamics randomization, and learned actuator modeling for quadruped transfer.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 4; F6–F8, L1–L2.
- **Papers:** [P110 — Learning Agile and Dynamic Motor Skills for Legged Robots](https://www.science.org/doi/10.1126/scirobotics.aau5872)
- **Supporting materials:** R006, R019
- **Concepts covered:** Combines massively parallel simulation, dynamics randomization, and learned actuator modeling for quadruped transfer. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in sim-to-real transfer, system identification, and adaptation.
- **Relationship in sequence:** Builds on paper session 4; leads to the next paper in the master sequence (P111). Master lineage note: Important systems proof for simulation-trained control.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Specialized hardware and extensive engineering obscure individual contributions.
- **Resumption context:** The durable takeaway is: Combines massively parallel simulation, dynamics randomization, and learned actuator modeling for quadruped transfer. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. P111 — RMA: Rapid Motor Adaptation for Legged Robots

- **Central question / objective:** Uses privileged training and an online adaptation module to infer environmental dynamics.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Advanced continuation
- **Prerequisites:** Session 5; F6–F8, L1–L2.
- **Papers:** [P111 — RMA: Rapid Motor Adaptation for Legged Robots](https://arxiv.org/abs/2107.04034)
- **Supporting materials:** R006, R019
- **Concepts covered:** Uses privileged training and an online adaptation module to infer environmental dynamics. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in sim-to-real transfer, system identification, and adaptation.
- **Relationship in sequence:** Builds on paper session 5; leads to the topic reconstruction/comparison session. Master lineage note: Moves from robust randomization toward rapid latent adaptation.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Primarily locomotion; adaptation identifiability and safety under novelty remain open.
- **Resumption context:** The durable takeaway is: Uses privileged training and an online adaptation module to infer environmental dynamics. Continue by comparing its assumptions and evidence with the next lineage stage.

### 7. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Trace visual randomization, dynamics randomization, SimOpt, agile locomotion, and RMA as increasingly adaptive sim-to-real strategies.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–6
- **Papers:** [P107 — Domain Randomization for Transferring Deep Neural Networks from Simulation to the Real World](https://arxiv.org/abs/1703.06907), [P108 — Sim-to-Real Transfer of Robotic Control with Dynamics Randomization](https://arxiv.org/abs/1710.06537), [P109 — SimOpt: Learning to Adapt Simulators to Real-World Conditions](https://arxiv.org/abs/1810.05687), [P110 — Learning Agile and Dynamic Motor Skills for Legged Robots](https://www.science.org/doi/10.1126/scirobotics.aau5872), [P111 — RMA: Rapid Motor Adaptation for Legged Robots](https://arxiv.org/abs/2107.04034)
- **Supporting materials:** R006, R019, R020, R021, R024, R030
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 8. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Build a simulation-to-real or simulation-to-held-out-dynamics study with parameter calibration, randomization ablations, latency/noise models, and adaptation tests.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–7; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R006, R019, R020, R021, R024, R030
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Build a simulation-to-real or simulation-to-held-out-dynamics study with parameter calibration, randomization ablations, latency/noise models, and adaptation tests.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 9. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–8; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R006, R019, R020, R021, R024, R030
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 10. Topic synthesis and original research directions

- **Central question / objective:** Which uncertainties should be randomized, identified, adapted online, or handled by feedback control?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–9
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R006, R019, R020, R021, R024, R030
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: D5, S1, S3.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | F6–F8, L1–L2. |
| Closely related / cross-area | Connects simulation, physical deployment, locomotion, and manipulation. |
| Outgoing capability | D5, S1, S3 |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P107, P108, P109, P110, P111 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**Which uncertainties should be randomized, identified, adapted online, or handled by feedback control?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to D5, S1, S3 is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 5 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** Propose adding the following supporting resources to the master supporting-material index: R030. They fill implementation/reconstruction gaps without changing the paper sequence.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
