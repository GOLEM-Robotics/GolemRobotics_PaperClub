# S3 — Legged locomotion and whole-body control: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** F. Specialization branches  
**Execution status:** **Specialization**

## 1. Topic scope and target depth

### Covers

Policy learning for locomotion, motion imitation, terrain adaptation, privileged learning, humanoid control, and loco-manipulation.

### Excludes

It excludes general rigid-body control already covered in F6 and sim-to-real methodology already covered in L7 except as applied to locomotion.

### Target competence

Reconstruct locomotion and whole-body policy architectures, reward/reference design, privileged learning, terrain adaptation, and humanoid/loco-manipulation evaluation.

### Place in the wider curriculum

Executable with simulation-first infrastructure. Whole-body and humanoid specialization.

## 2. Execution status and completion boundary

- **Topic execution status:** Specialization
- **Planned sessions:** 10
- **Classification:** 8 required core · 1 advanced continuation · 0 optional specialization · 1 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 10, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 10

## 3. Dependencies and required foundations

- **Master prerequisites:** F6–F8, L2, L7.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Floating-base dynamics, contacts, gait/phase representations, reward shaping, motion imitation, terrain curricula, privileged observations, adaptation, and fall/safety metrics.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R006 — [Underactuated Robotics](https://underactuated.csail.mit.edu/)** (Open textbook/lecture notes): Nonlinear dynamics, optimal control, planning, and learning for physical systems.
- **R020 — [MuJoCo Documentation](https://mujoco.readthedocs.io/)** (Physics simulator documentation): Reliable dynamics/control simulation reference.
- **R021 — [Isaac Lab Documentation](https://isaac-sim.github.io/IsaacLab/)** (Simulation and robot-learning documentation): GPU-parallel robot-learning workflows, domain randomization, and deployment interfaces.
- **R034 — [Drake Documentation and Tutorials](https://drake.mit.edu/tutorials/)** (Model-based robotics framework and tutorials): Multibody dynamics, contact, mathematical programming, automatic differentiation, systems diagrams, and model-based verification.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: F6–F8, L2, L7.
        │
        ▼
S1 Topic-local foundations: Floating-base dynamics, contacts, gait/phase representations, reward shaping, motion imitation, terrain curricula, privileged observations, adaptation, and fall/safety metrics.
        │
        ▼
Paper lineage: P172 → P173 → P174 → P175 → P176
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► whole-body/humanoid E2 and L7 work
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for legged locomotion and whole-body control and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** F6–F8, L2, L7.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R006, R020, R021, R034
- **Concepts covered:** Floating-base dynamics, contacts, gait/phase representations, reward shaping, motion imitation, terrain curricula, privileged observations, adaptation, and fall/safety metrics.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Policy learning for locomotion, motion imitation, terrain adaptation, privileged learning, humanoid control, and loco-manipulation. Next, enter the ordered paper lineage.

### 2. P172 — DeepMimic: Example-Guided Deep Reinforcement Learning of Physics-Based Character Skills

- **Central question / objective:** Combines motion-imitation rewards and task objectives to learn robust physics-based skills.
- **Stage / role:** Paper lineage — Foundation; Modern Core
- **Status:** Required core
- **Prerequisites:** Session 1; F6–F8, L2, L7.
- **Papers:** [P172 — DeepMimic: Example-Guided Deep Reinforcement Learning of Physics-Based Character Skills](https://arxiv.org/abs/1804.02717)
- **Supporting materials:** R006, R020
- **Concepts covered:** Combines motion-imitation rewards and task objectives to learn robust physics-based skills. Preparation profile: Foundation; Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in legged locomotion and whole-body control.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P173). Master lineage note: Foundation for motion-prior humanoid and quadruped control.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Simulation characters and reward engineering; not direct robot transfer.
- **Resumption context:** The durable takeaway is: Combines motion-imitation rewards and task objectives to learn robust physics-based skills. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P173 — Learning Quadrupedal Locomotion over Challenging Terrain

- **Central question / objective:** Uses privileged learning and teacher–student training for robust rough-terrain locomotion.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 2; F6–F8, L2, L7.
- **Papers:** [P173 — Learning Quadrupedal Locomotion over Challenging Terrain](https://www.science.org/doi/10.1126/scirobotics.abc5986)
- **Supporting materials:** R006, R020
- **Concepts covered:** Uses privileged learning and teacher–student training for robust rough-terrain locomotion. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in legged locomotion and whole-body control.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P174). Master lineage note: Develops sim-to-real locomotion beyond flat-ground randomization.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Specialized platform and extensive engineering; terrain coverage remains bounded.
- **Resumption context:** The durable takeaway is: Uses privileged learning and teacher–student training for robust rough-terrain locomotion. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P174 — Adversarial Motion Priors Make Good Substitutes for Complex Reward Functions

- **Central question / objective:** Learns motion style priors adversarially from reference data while optimizing task objectives.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 3; F6–F8, L2, L7.
- **Papers:** [P174 — Adversarial Motion Priors Make Good Substitutes for Complex Reward Functions](https://arxiv.org/abs/2104.02180)
- **Supporting materials:** R006, R020
- **Concepts covered:** Learns motion style priors adversarially from reference data while optimizing task objectives. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in legged locomotion and whole-body control.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P175). Master lineage note: Successor to DeepMimic with less hand-designed imitation reward.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Reference data quality and adversarial training stability matter.
- **Resumption context:** The durable takeaway is: Learns motion style priors adversarially from reference data while optimizing task objectives. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P175 — Walk These Ways: Tuning Robot Control for Generalization with Multiplicity of Behavior

- **Central question / objective:** Conditions locomotion policies on interpretable behavior parameters for versatile deployment.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Advanced continuation
- **Prerequisites:** Session 4; F6–F8, L2, L7.
- **Papers:** [P175 — Walk These Ways: Tuning Robot Control for Generalization with Multiplicity of Behavior](https://arxiv.org/abs/2212.03238)
- **Supporting materials:** R006, R020
- **Concepts covered:** Conditions locomotion policies on interpretable behavior parameters for versatile deployment. Preparation profile: Modern Core · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in legged locomotion and whole-body control.
- **Relationship in sequence:** Builds on paper session 4; leads to the next paper in the master sequence (P176). Master lineage note: Connects skill conditioning and practical quadruped control.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Limited to locomotion and specific hardware/simulation assumptions.
- **Resumption context:** The durable takeaway is: Conditions locomotion policies on interpretable behavior parameters for versatile deployment. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. P176 — SONIC: Supersizing Motion Tracking for Natural Humanoid Whole-Body Control

- **Central question / objective:** Scales motion tracking data and models for natural humanoid whole-body control.
- **Stage / role:** Paper lineage — Frontier
- **Status:** Frontier continuation
- **Prerequisites:** Session 5; F6–F8, L2, L7.
- **Papers:** [P176 — SONIC: Supersizing Motion Tracking for Natural Humanoid Whole-Body Control](https://arxiv.org/abs/2511.07820)
- **Supporting materials:** R006, R020
- **Concepts covered:** Scales motion tracking data and models for natural humanoid whole-body control. Preparation profile: Frontier · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in legged locomotion and whole-body control.
- **Relationship in sequence:** Builds on paper session 5; leads to the topic reconstruction/comparison session. Master lineage note: Modern frontier after DeepMimic/AMP for humanoids.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Very recent; specialized hardware/large data and limited independent reproduction.
- **Resumption context:** The durable takeaway is: Scales motion tracking data and models for natural humanoid whole-body control. Continue by comparing its assumptions and evidence with the next lineage stage.

### 7. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Trace deep locomotion, DeepMimic, ANYmal-style sim-to-real, RMA, and humanoid whole-body control.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–6
- **Papers:** [P172 — DeepMimic: Example-Guided Deep Reinforcement Learning of Physics-Based Character Skills](https://arxiv.org/abs/1804.02717), [P173 — Learning Quadrupedal Locomotion over Challenging Terrain](https://www.science.org/doi/10.1126/scirobotics.abc5986), [P174 — Adversarial Motion Priors Make Good Substitutes for Complex Reward Functions](https://arxiv.org/abs/2104.02180), [P175 — Walk These Ways: Tuning Robot Control for Generalization with Multiplicity of Behavior](https://arxiv.org/abs/2212.03238), [P176 — SONIC: Supersizing Motion Tracking for Natural Humanoid Whole-Body Control](https://arxiv.org/abs/2511.07820)
- **Supporting materials:** R006, R020, R021, R034
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 8. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Train a simulation locomotion or whole-body policy; perform reward, terrain, latency, and dynamics-randomization ablations and analyze failure modes.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–7; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R006, R020, R021, R034
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Train a simulation locomotion or whole-body policy; perform reward, terrain, latency, and dynamics-randomization ablations and analyze failure modes.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 9. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–8; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R006, R020, R021, R034
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 10. Topic synthesis and original research directions

- **Central question / objective:** Which capabilities require learned whole-body coordination, and which should remain model-based or reference-driven?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–9
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R006, R020, R021, R034
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: whole-body/humanoid E2 and L7 work.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | F6–F8, L2, L7. |
| Closely related / cross-area | Whole-body and humanoid specialization. |
| Outgoing capability | whole-body/humanoid E2 and L7 work |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P172, P173, P174, P175, P176 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**Which capabilities require learned whole-body coordination, and which should remain model-based or reference-driven?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to whole-body/humanoid E2 and L7 work is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 5 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** Propose adding the following supporting resources to the master supporting-material index: R034. They fill implementation/reconstruction gaps without changing the paper sequence.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
