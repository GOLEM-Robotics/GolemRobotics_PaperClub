# F4 — Self-supervised and generative learning: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** A. Shared foundations  
**Execution status:** **Shared Core**

## 1. Topic scope and target depth

### Covers

Contrastive, masked, predictive, diffusion, score-based, and flow-based objectives.

### Excludes

It excludes domain-specific action policies and world models except as downstream connections.

### Target competence

Derive contrastive, masking, diffusion, score, and flow objectives and identify what representation or distribution each objective learns.

### Place in the wider curriculum

Mathematical bridge from representation learning to generative action policies. Supports P1, P4, P5, L6, D5, and E2.

## 2. Execution status and completion boundary

- **Topic execution status:** Shared Core
- **Planned sessions:** 11
- **Classification:** 10 required core · 0 advanced continuation · 1 optional specialization · 0 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 11, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 11

## 3. Dependencies and required foundations

- **Master prerequisites:** F2–F3; probability.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Likelihood, latent-variable intuition, contrastive estimation, corruption processes, denoising, score fields, ODE/SDE views, and conditional generation.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R011 — [Deep Learning](https://www.deeplearningbook.org/)** (Open textbook): Targeted chapters for optimization, regularization, sequence models, and generative modeling.
- **R012 — [Dive into Deep Learning](https://d2l.ai/)** (Interactive open textbook): Implementation-oriented prerequisite repair for uneven member backgrounds.
- **R013 — [Stanford CS231n](https://cs231n.github.io/)** (Lecture notes): Targeted computer-vision and optimization foundation.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: F2–F3; probability.
        │
        ▼
S1 Topic-local foundations: Likelihood, latent-variable intuition, contrastive estimation, corruption processes, denoising, score fields, ODE/SDE views, and conditional generation.
        │
        ▼
Paper lineage: P014 → P015 → P016 → P017 → P018 → P019
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► P1, P4–P5, L6, D5, E2
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for self-supervised and generative learning and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** F2–F3; probability.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R011, R012, R013
- **Concepts covered:** Likelihood, latent-variable intuition, contrastive estimation, corruption processes, denoising, score fields, ODE/SDE views, and conditional generation.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Contrastive, masked, predictive, diffusion, score-based, and flow-based objectives. Next, enter the ordered paper lineage.

### 2. P014 — A Simple Framework for Contrastive Learning of Visual Representations

- **Central question / objective:** Clarifies the data augmentation, projection head, and batch-size choices behind contrastive visual learning.
- **Stage / role:** Paper lineage — Foundation
- **Status:** Required core
- **Prerequisites:** Session 1; F2–F3; probability.
- **Papers:** [P014 — A Simple Framework for Contrastive Learning of Visual Representations](https://proceedings.mlr.press/v119/chen20j.html)
- **Supporting materials:** R011, R012
- **Concepts covered:** Clarifies the data augmentation, projection head, and batch-size choices behind contrastive visual learning. Preparation profile: Foundation · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in self-supervised and generative learning.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P015). Master lineage note: Precedes CLIP and later self-supervised vision methods.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Large-batch negatives and image-level invariances may discard spatial detail.
- **Resumption context:** The durable takeaway is: Clarifies the data augmentation, projection head, and batch-size choices behind contrastive visual learning. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P015 — Masked Autoencoders Are Scalable Vision Learners

- **Central question / objective:** Uses high-ratio masked image reconstruction to pretrain scalable ViT encoders.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 2; F2–F3; probability.
- **Papers:** [P015 — Masked Autoencoders Are Scalable Vision Learners](https://openaccess.thecvf.com/content/CVPR2022/html/He_Masked_Autoencoders_Are_Scalable_Vision_Learners_CVPR_2022_paper.html)
- **Supporting materials:** R011, R012
- **Concepts covered:** Uses high-ratio masked image reconstruction to pretrain scalable ViT encoders. Preparation profile: Modern Core · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in self-supervised and generative learning.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P016). Master lineage note: Alternative to contrastive learning; supports P1 and P4.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Pixel reconstruction does not guarantee physical or semantic relevance.
- **Resumption context:** The durable takeaway is: Uses high-ratio masked image reconstruction to pretrain scalable ViT encoders. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P016 — Denoising Diffusion Probabilistic Models

- **Central question / objective:** Establishes a practical diffusion-model formulation based on iterative denoising.
- **Stage / role:** Paper lineage — Foundation; Seminal
- **Status:** Required core
- **Prerequisites:** Session 3; F2–F3; probability.
- **Papers:** [P016 — Denoising Diffusion Probabilistic Models](https://arxiv.org/abs/2006.11239)
- **Supporting materials:** R011, R012
- **Concepts covered:** Establishes a practical diffusion-model formulation based on iterative denoising. Preparation profile: Foundation; Seminal · Advanced · High; derive forward/reverse processes and objective
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in self-supervised and generative learning.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P017). Master lineage note: Direct precursor to Diffusion Policy and many continuous-action generators.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Iterative sampling is computationally expensive; likelihood framing is not the only interpretation.
- **Resumption context:** The durable takeaway is: Establishes a practical diffusion-model formulation based on iterative denoising. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P017 — Score-Based Generative Modeling through Stochastic Differential Equations

- **Central question / objective:** Unifies score matching, diffusion processes, and probability-flow ODEs.
- **Stage / role:** Paper lineage — Bridge
- **Status:** Required core
- **Prerequisites:** Session 4; F2–F3; probability.
- **Papers:** [P017 — Score-Based Generative Modeling through Stochastic Differential Equations](https://arxiv.org/abs/2011.13456)
- **Supporting materials:** R011, R012
- **Concepts covered:** Unifies score matching, diffusion processes, and probability-flow ODEs. Preparation profile: Bridge · Advanced · High; SDE/ODE derivations
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in self-supervised and generative learning.
- **Relationship in sequence:** Builds on paper session 4; leads to the next paper in the master sequence (P018). Master lineage note: Connects DDPM to continuous-time generative control formulations.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Mathematically demanding; direct robot-policy transfer requires additional conditioning/control design.
- **Resumption context:** The durable takeaway is: Unifies score matching, diffusion processes, and probability-flow ODEs. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. P018 — Flow Matching for Generative Modeling

- **Central question / objective:** Introduces simulation-free training of continuous normalizing flows through flow matching.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 5; F2–F3; probability.
- **Papers:** [P018 — Flow Matching for Generative Modeling](https://arxiv.org/abs/2210.02747)
- **Supporting materials:** R011, R012
- **Concepts covered:** Introduces simulation-free training of continuous normalizing flows through flow matching. Preparation profile: Modern Core · Advanced · High; focus conditional probability paths and vector fields
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in self-supervised and generative learning.
- **Relationship in sequence:** Builds on paper session 5; leads to the next paper in the master sequence (P019). Master lineage note: Directly relevant to π-series action experts and modern VLA action heads.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Choice of probability path and solver affects efficiency and quality.
- **Resumption context:** The durable takeaway is: Introduces simulation-free training of continuous normalizing flows through flow matching. Continue by comparing its assumptions and evidence with the next lineage stage.

### 7. P019 — Flow Straight and Fast: Learning to Generate and Transfer Data with Rectified Flow

- **Central question / objective:** Learns straighter transport paths to reduce sampling steps.
- **Stage / role:** Paper lineage — Optional Specialization
- **Status:** Optional specialization
- **Prerequisites:** Session 6; F2–F3; probability.
- **Papers:** [P019 — Flow Straight and Fast: Learning to Generate and Transfer Data with Rectified Flow](https://arxiv.org/abs/2209.03003)
- **Supporting materials:** R011, R012
- **Concepts covered:** Learns straighter transport paths to reduce sampling steps. Preparation profile: Optional Specialization · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in self-supervised and generative learning.
- **Relationship in sequence:** Builds on paper session 6; leads to the topic reconstruction/comparison session. Master lineage note: Related to flow matching and efficient action generation.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Terminology and relationships among rectified flow/flow matching variants require careful comparison.
- **Resumption context:** The durable takeaway is: Learns straighter transport paths to reduce sampling steps. Continue by comparing its assumptions and evidence with the next lineage stage.

### 8. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Map each objective to its training target, sampling/inference procedure, inductive bias, and failure mode.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–7
- **Papers:** [P014 — A Simple Framework for Contrastive Learning of Visual Representations](https://proceedings.mlr.press/v119/chen20j.html), [P015 — Masked Autoencoders Are Scalable Vision Learners](https://openaccess.thecvf.com/content/CVPR2022/html/He_Masked_Autoencoders_Are_Scalable_Vision_Learners_CVPR_2022_paper.html), [P016 — Denoising Diffusion Probabilistic Models](https://arxiv.org/abs/2006.11239), [P017 — Score-Based Generative Modeling through Stochastic Differential Equations](https://arxiv.org/abs/2011.13456), [P018 — Flow Matching for Generative Modeling](https://arxiv.org/abs/2210.02747), [P019 — Flow Straight and Fast: Learning to Generate and Transfer Data with Rectified Flow](https://arxiv.org/abs/2209.03003)
- **Supporting materials:** R011, R012, R013
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 9. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Train miniature contrastive, masked-autoencoding, and diffusion/flow models on a controlled dataset and compare representations, likelihood proxies, and sampling cost.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–8; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R011, R012, R013
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Train miniature contrastive, masked-autoencoding, and diffusion/flow models on a controlled dataset and compare representations, likelihood proxies, and sampling cost.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 10. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–9; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R011, R012, R013
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 11. Topic synthesis and original research directions

- **Central question / objective:** When should physical-AI systems predict representations, pixels, actions, scores, or vector fields?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–10
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R011, R012, R013
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: P1, P4–P5, L6, D5, E2.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | F2–F3; probability. |
| Closely related / cross-area | Supports P1, P4, P5, L6, D5, and E2. |
| Outgoing capability | P1, P4–P5, L6, D5, E2 |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P014, P015, P016, P017, P018, P019 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**When should physical-AI systems predict representations, pixels, actions, scores, or vector fields?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to P1, P4–P5, L6, D5, E2 is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 6 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** No change to topic boundary or primary-paper inventory is proposed.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
