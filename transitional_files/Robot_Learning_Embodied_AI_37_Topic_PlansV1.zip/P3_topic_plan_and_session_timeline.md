# P3 — 3D representation, reconstruction, and semantic mapping: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** B. Perception, spatial intelligence, and world models  
**Execution status:** **Active Research Track**

## 1. Topic scope and target depth

### Covers

Point sets, implicit fields, radiance fields, Gaussian splats, open-vocabulary 3D features, and semantic maps.

### Excludes

It excludes classical multi-view geometry in full depth and does not treat rendering quality as the final objective.

### Target competence

Reason across point, implicit, radiance-field, Gaussian, and semantic-map representations; select representations for mapping, planning, manipulation, and simulation.

### Place in the wider curriculum

Spatial-intelligence track. Connects perception to planning, manipulation, simulation, and world models.

## 2. Execution status and completion boundary

- **Topic execution status:** Active Research Track
- **Planned sessions:** 12
- **Classification:** 11 required core · 1 advanced continuation · 0 optional specialization · 0 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 12, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 12

## 3. Dependencies and required foundations

- **Master prerequisites:** P1, F8.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Coordinate frames, camera geometry, point sets, occupancy/SDFs, volume rendering, splats, feature fields, map fusion, and pose dependence.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R008 — [Probabilistic Robotics](https://mitpress.mit.edu/9780262201629/probabilistic-robotics/)** (Textbook): Bayesian filtering, localization, mapping, and SLAM foundation.
- **R013 — [Stanford CS231n](https://cs231n.github.io/)** (Lecture notes): Targeted computer-vision and optimization foundation.
- **R019 — [ManiSkill Documentation](https://maniskill.readthedocs.io/)** (Simulation/benchmark documentation): High-throughput manipulation experiments and standardized evaluation.
- **R021 — [Isaac Lab Documentation](https://isaac-sim.github.io/IsaacLab/)** (Simulation and robot-learning documentation): GPU-parallel robot-learning workflows, domain randomization, and deployment interfaces.
- **R028 — [MIT Robotic Manipulation: Perception, Planning, and Control](https://manipulation.csail.mit.edu/)** (Open course notes and exercises): Integrated manipulation stack connecting geometry, perception, planning, contact, control, and learning.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: P1, F8.
        │
        ▼
S1 Topic-local foundations: Coordinate frames, camera geometry, point sets, occupancy/SDFs, volume rendering, splats, feature fields, map fusion, and pose dependence.
        │
        ▼
Paper lineage: P054 → P055 → P056 → P057 → P058 → P059 → P060
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► P5, D5, E1, S1, S4–S5
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for 3d representation, reconstruction, and semantic mapping and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** P1, F8.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R008, R013, R019, R021, R028
- **Concepts covered:** Coordinate frames, camera geometry, point sets, occupancy/SDFs, volume rendering, splats, feature fields, map fusion, and pose dependence.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Point sets, implicit fields, radiance fields, Gaussian splats, open-vocabulary 3D features, and semantic maps. Next, enter the ordered paper lineage.

### 2. P054 — PointNet: Deep Learning on Point Sets for 3D Classification and Segmentation

- **Central question / objective:** Introduces permutation-invariant direct learning over point sets.
- **Stage / role:** Paper lineage — Foundation; Seminal
- **Status:** Required core
- **Prerequisites:** Session 1; P1, F8.
- **Papers:** [P054 — PointNet: Deep Learning on Point Sets for 3D Classification and Segmentation](https://openaccess.thecvf.com/content_cvpr_2017/html/Qi_PointNet_Deep_Learning_CVPR_2017_paper.html)
- **Supporting materials:** R008, R013
- **Concepts covered:** Introduces permutation-invariant direct learning over point sets. Preparation profile: Foundation; Seminal · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in 3d representation, reconstruction, and semantic mapping.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P055). Master lineage note: Foundation for learned point-cloud perception.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Weak local-geometry modeling motivates PointNet++.
- **Resumption context:** The durable takeaway is: Introduces permutation-invariant direct learning over point sets. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P055 — PointNet++: Deep Hierarchical Feature Learning on Point Sets in a Metric Space

- **Central question / objective:** Adds hierarchical neighborhood aggregation and multi-scale geometry.
- **Stage / role:** Paper lineage — Bridge; Modern Core
- **Status:** Required core
- **Prerequisites:** Session 2; P1, F8.
- **Papers:** [P055 — PointNet++: Deep Hierarchical Feature Learning on Point Sets in a Metric Space](https://arxiv.org/abs/1706.02413)
- **Supporting materials:** R008, R013
- **Concepts covered:** Adds hierarchical neighborhood aggregation and multi-scale geometry. Preparation profile: Bridge; Modern Core · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in 3d representation, reconstruction, and semantic mapping.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P056). Master lineage note: Direct development of PointNet toward local 3D structure.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Neighborhood sampling and density variation remain costly/sensitive.
- **Resumption context:** The durable takeaway is: Adds hierarchical neighborhood aggregation and multi-scale geometry. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P056 — Point Transformer

- **Central question / objective:** Adapts vector attention to local point-cloud processing.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 3; P1, F8.
- **Papers:** [P056 — Point Transformer](https://openaccess.thecvf.com/content/ICCV2021/html/Zhao_Point_Transformer_ICCV_2021_paper.html)
- **Supporting materials:** R008, R013
- **Concepts covered:** Adapts vector attention to local point-cloud processing. Preparation profile: Modern Core · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in 3d representation, reconstruction, and semantic mapping.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P057). Master lineage note: Transformer-based successor to PointNet-family representations.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Compute/memory cost and sparse neighborhood design matter.
- **Resumption context:** The durable takeaway is: Adapts vector attention to local point-cloud processing. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P057 — Occupancy Networks: Learning 3D Reconstruction in Function Space

- **Central question / objective:** Represents 3D geometry as a continuous learned occupancy function.
- **Stage / role:** Paper lineage — Bridge
- **Status:** Required core
- **Prerequisites:** Session 4; P1, F8.
- **Papers:** [P057 — Occupancy Networks: Learning 3D Reconstruction in Function Space](https://openaccess.thecvf.com/content_CVPR_2019/html/Mescheder_Occupancy_Networks_Learning_3D_Reconstruction_in_Function_Space_CVPR_2019_paper.html)
- **Supporting materials:** R008, R013
- **Concepts covered:** Represents 3D geometry as a continuous learned occupancy function. Preparation profile: Bridge · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in 3d representation, reconstruction, and semantic mapping.
- **Relationship in sequence:** Builds on paper session 4; leads to the next paper in the master sequence (P058). Master lineage note: Precursor to neural implicit scene representations.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Static object-centric setting; extracting meshes and high-frequency detail can be costly.
- **Resumption context:** The durable takeaway is: Represents 3D geometry as a continuous learned occupancy function. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. P058 — NeRF: Representing Scenes as Neural Radiance Fields for View Synthesis

- **Central question / objective:** Represents scenes as continuous density and radiance fields optimized through differentiable rendering.
- **Stage / role:** Paper lineage — Seminal; Bridge
- **Status:** Required core
- **Prerequisites:** Session 5; P1, F8.
- **Papers:** [P058 — NeRF: Representing Scenes as Neural Radiance Fields for View Synthesis](https://arxiv.org/abs/2003.08934)
- **Supporting materials:** R008, R013
- **Concepts covered:** Represents scenes as continuous density and radiance fields optimized through differentiable rendering. Preparation profile: Seminal; Bridge · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in 3d representation, reconstruction, and semantic mapping.
- **Relationship in sequence:** Builds on paper session 5; leads to the next paper in the master sequence (P059). Master lineage note: Foundation for neural scene reconstruction and synthetic asset generation.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Slow optimization/rendering in original form; static-scene and calibrated-camera assumptions.
- **Resumption context:** The durable takeaway is: Represents scenes as continuous density and radiance fields optimized through differentiable rendering. Continue by comparing its assumptions and evidence with the next lineage stage.

### 7. P059 — 3D Gaussian Splatting for Real-Time Radiance Field Rendering

- **Central question / objective:** Uses anisotropic 3D Gaussians and differentiable splatting for high-quality real-time rendering.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 6; P1, F8.
- **Papers:** [P059 — 3D Gaussian Splatting for Real-Time Radiance Field Rendering](https://repo-sam.inria.fr/fungraph/3d-gaussian-splatting/)
- **Supporting materials:** R008, R013
- **Concepts covered:** Uses anisotropic 3D Gaussians and differentiable splatting for high-quality real-time rendering. Preparation profile: Modern Core · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in 3d representation, reconstruction, and semantic mapping.
- **Relationship in sequence:** Builds on paper session 6; leads to the next paper in the master sequence (P060). Master lineage note: Operational alternative to NeRF for scene capture and simulation assets.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Geometry can be noisy; dynamic scenes, relighting, and physical semantics require extensions.
- **Resumption context:** The durable takeaway is: Uses anisotropic 3D Gaussians and differentiable splatting for high-quality real-time rendering. Continue by comparing its assumptions and evidence with the next lineage stage.

### 8. P060 — ConceptFusion: Open-set Multimodal 3D Mapping

- **Central question / objective:** Fuses open-vocabulary 2D features into queryable 3D maps.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Advanced continuation
- **Prerequisites:** Session 7; P1, F8.
- **Papers:** [P060 — ConceptFusion: Open-set Multimodal 3D Mapping](https://arxiv.org/abs/2302.07241)
- **Supporting materials:** R008, R013
- **Concepts covered:** Fuses open-vocabulary 2D features into queryable 3D maps. Preparation profile: Modern Core · Advanced · Medium–High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in 3d representation, reconstruction, and semantic mapping.
- **Relationship in sequence:** Builds on paper session 7; leads to the topic reconstruction/comparison session. Master lineage note: Connects CLIP-like representations, SLAM, and embodied querying.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Feature projection inherits 2D encoder and pose-estimation errors.
- **Resumption context:** The durable takeaway is: Fuses open-vocabulary 2D features into queryable 3D maps. Continue by comparing its assumptions and evidence with the next lineage stage.

### 9. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Compare PointNet-family, occupancy fields, NeRF, 3DGS, and ConceptFusion by representation, supervision, rendering, update cost, semantics, and geometry fidelity.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–8
- **Papers:** [P054 — PointNet: Deep Learning on Point Sets for 3D Classification and Segmentation](https://openaccess.thecvf.com/content_cvpr_2017/html/Qi_PointNet_Deep_Learning_CVPR_2017_paper.html), [P055 — PointNet++: Deep Hierarchical Feature Learning on Point Sets in a Metric Space](https://arxiv.org/abs/1706.02413), [P056 — Point Transformer](https://openaccess.thecvf.com/content/ICCV2021/html/Zhao_Point_Transformer_ICCV_2021_paper.html), [P057 — Occupancy Networks: Learning 3D Reconstruction in Function Space](https://openaccess.thecvf.com/content_CVPR_2019/html/Mescheder_Occupancy_Networks_Learning_3D_Reconstruction_in_Function_Space_CVPR_2019_paper.html), [P058 — NeRF: Representing Scenes as Neural Radiance Fields for View Synthesis](https://arxiv.org/abs/2003.08934), [P059 — 3D Gaussian Splatting for Real-Time Radiance Field Rendering](https://repo-sam.inria.fr/fungraph/3d-gaussian-splatting/), [P060 — ConceptFusion: Open-set Multimodal 3D Mapping](https://arxiv.org/abs/2302.07241)
- **Supporting materials:** R008, R013, R019, R021, R028
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 10. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Reconstruct a small scene with point/implicit or Gaussian methods and build a semantic query layer; evaluate geometry, pose sensitivity, latency, and downstream utility.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–9; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R008, R013, R019, R021, R028
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Reconstruct a small scene with point/implicit or Gaussian methods and build a semantic query layer; evaluate geometry, pose sensitivity, latency, and downstream utility.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 11. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–10; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R008, R013, R019, R021, R028
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 12. Topic synthesis and original research directions

- **Central question / objective:** Which 3D representation preserves the information needed for action, not merely view synthesis?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–11
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R008, R013, R019, R021, R028
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: P5, D5, E1, S1, S4–S5.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | P1, F8. |
| Closely related / cross-area | Connects perception to planning, manipulation, simulation, and world models. |
| Outgoing capability | P5, D5, E1, S1, S4–S5 |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P054, P055, P056, P057, P058, P059, P060 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**Which 3D representation preserves the information needed for action, not merely view synthesis?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to P5, D5, E1, S1, S4–S5 is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 7 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** Propose adding the following supporting resources to the master supporting-material index: R028. They fill implementation/reconstruction gaps without changing the paper sequence.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
