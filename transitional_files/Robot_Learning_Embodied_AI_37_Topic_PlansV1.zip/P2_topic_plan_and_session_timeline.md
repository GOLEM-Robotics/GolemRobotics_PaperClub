# P2 — Detection, segmentation, grounding, and tracking: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** B. Perception, spatial intelligence, and world models  
**Execution status:** **Active Research Track**

## 1. Topic scope and target depth

### Covers

Set-based detection, instance and promptable segmentation, open-vocabulary grounding, and temporal object tracking.

### Excludes

It excludes full 3D reconstruction and policy learning; models are studied as perception and data-engineering components.

### Target competence

Construct and evaluate detection, grounding, promptable segmentation, and temporal tracking pipelines, including open-vocabulary and annotation-use cases.

### Place in the wider curriculum

Executable perception and data-processing track. Supports automated labeling in D1, semantic planning in E1, and manipulation in S1.

## 2. Execution status and completion boundary

- **Topic execution status:** Active Research Track
- **Planned sessions:** 11
- **Classification:** 10 required core · 0 advanced continuation · 1 optional specialization · 0 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 11, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 11

## 3. Dependencies and required foundations

- **Master prerequisites:** P1.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Boxes, masks, set prediction, matching, prompt encodings, open-vocabulary alignment, temporal memory, identity persistence, and calibration.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R013 — [Stanford CS231n](https://cs231n.github.io/)** (Lecture notes): Targeted computer-vision and optimization foundation.
- **R017 — [LeRobot Documentation](https://huggingface.co/docs/lerobot/)** (Documentation and open framework): Dataset schema, teleoperation, policy training, evaluation, and low-cost hardware integration.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: P1.
        │
        ▼
S1 Topic-local foundations: Boxes, masks, set prediction, matching, prompt encodings, open-vocabulary alignment, temporal memory, identity persistence, and calibration.
        │
        ▼
Paper lineage: P048 → P049 → P050 → P051 → P052 → P053
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► D1, E1, S1
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for detection, segmentation, grounding, and tracking and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** P1.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R013, R017
- **Concepts covered:** Boxes, masks, set prediction, matching, prompt encodings, open-vocabulary alignment, temporal memory, identity persistence, and calibration.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Set-based detection, instance and promptable segmentation, open-vocabulary grounding, and temporal object tracking. Next, enter the ordered paper lineage.

### 2. P048 — Mask R-CNN

- **Central question / objective:** Extends two-stage detection with instance masks and aligned region features.
- **Stage / role:** Paper lineage — Foundation
- **Status:** Required core
- **Prerequisites:** Session 1; P1.
- **Papers:** [P048 — Mask R-CNN](https://openaccess.thecvf.com/content_ICCV_2017/html/He_Mask_R-CNN_ICCV_2017_paper.html)
- **Supporting materials:** R013, R017
- **Concepts covered:** Extends two-stage detection with instance masks and aligned region features. Preparation profile: Foundation · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in detection, segmentation, grounding, and tracking.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P049). Master lineage note: Foundation for instance-level robot scene understanding and annotation.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Closed-set categories and proposal pipeline limit open-world use.
- **Resumption context:** The durable takeaway is: Extends two-stage detection with instance masks and aligned region features. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P049 — End-to-End Object Detection with Transformers

- **Central question / objective:** Recasts detection as set prediction using bipartite matching and Transformers.
- **Stage / role:** Paper lineage — Bridge; Modern Core
- **Status:** Required core
- **Prerequisites:** Session 2; P1.
- **Papers:** [P049 — End-to-End Object Detection with Transformers](https://arxiv.org/abs/2005.12872)
- **Supporting materials:** R013, R017
- **Concepts covered:** Recasts detection as set prediction using bipartite matching and Transformers. Preparation profile: Bridge; Modern Core · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in detection, segmentation, grounding, and tracking.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P050). Master lineage note: Precedes open-vocabulary and grounded detector families.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Original DETR converges slowly and struggles with small objects.
- **Resumption context:** The durable takeaway is: Recasts detection as set prediction using bipartite matching and Transformers. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P050 — Grounding DINO: Marrying DINO with Grounded Pre-Training for Open-Set Object Detection

- **Central question / objective:** Combines language grounding with Transformer detection for open-set object localization.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 3; P1.
- **Papers:** [P050 — Grounding DINO: Marrying DINO with Grounded Pre-Training for Open-Set Object Detection](https://arxiv.org/abs/2303.05499)
- **Supporting materials:** R013, R017
- **Concepts covered:** Combines language grounding with Transformer detection for open-set object localization. Preparation profile: Modern Core · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in detection, segmentation, grounding, and tracking.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P051). Master lineage note: Builds on DETR/DINO and CLIP-like grounding; pairs naturally with SAM.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Large pretraining mix and benchmark choices complicate attribution.
- **Resumption context:** The durable takeaway is: Combines language grounding with Transformer detection for open-set object localization. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P051 — Segment Anything

- **Central question / objective:** Introduces promptable segmentation trained on a large mask dataset.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 4; P1.
- **Papers:** [P051 — Segment Anything](https://openaccess.thecvf.com/content/ICCV2023/html/Kirillov_Segment_Anything_ICCV_2023_paper.html)
- **Supporting materials:** R013, R017
- **Concepts covered:** Introduces promptable segmentation trained on a large mask dataset. Preparation profile: Modern Core · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in detection, segmentation, grounding, and tracking.
- **Relationship in sequence:** Builds on paper session 4; leads to the next paper in the master sequence (P052). Master lineage note: Enables general annotation pipelines and object-centric robotics preprocessing.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Masks are not semantic, temporal, or guaranteed physically meaningful.
- **Resumption context:** The durable takeaway is: Introduces promptable segmentation trained on a large mask dataset. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. P052 — SAM 2: Segment Anything in Images and Videos

- **Central question / objective:** Extends promptable segmentation to streaming video with memory.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 5; P1.
- **Papers:** [P052 — SAM 2: Segment Anything in Images and Videos](https://arxiv.org/abs/2408.00714)
- **Supporting materials:** R013, R017
- **Concepts covered:** Extends promptable segmentation to streaming video with memory. Preparation profile: Modern Core · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in detection, segmentation, grounding, and tracking.
- **Relationship in sequence:** Builds on paper session 5; leads to the next paper in the master sequence (P053). Master lineage note: Builds on SAM; supports tracking-assisted annotation and online perception.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Performance can degrade under occlusion, appearance change, and long sequences.
- **Resumption context:** The durable takeaway is: Extends promptable segmentation to streaming video with memory. Continue by comparing its assumptions and evidence with the next lineage stage.

### 7. P053 — XMem: Long-Term Video Object Segmentation with an Atkinson–Shiffrin Memory Model

- **Central question / objective:** Uses sensory, working, and long-term memory for efficient video object segmentation.
- **Stage / role:** Paper lineage — Bridge; Optional
- **Status:** Optional specialization
- **Prerequisites:** Session 6; P1.
- **Papers:** [P053 — XMem: Long-Term Video Object Segmentation with an Atkinson–Shiffrin Memory Model](https://arxiv.org/abs/2207.07115)
- **Supporting materials:** R013, R017
- **Concepts covered:** Uses sensory, working, and long-term memory for efficient video object segmentation. Preparation profile: Bridge; Optional · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in detection, segmentation, grounding, and tracking.
- **Relationship in sequence:** Builds on paper session 6; leads to the topic reconstruction/comparison session. Master lineage note: Precedes memory-centric video segmentation and embodied memory ideas.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Requires initial object specification and is not a semantic reasoner.
- **Resumption context:** The durable takeaway is: Uses sensory, working, and long-term memory for efficient video object segmentation. Continue by comparing its assumptions and evidence with the next lineage stage.

### 8. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Trace the transition from region-based detection to set prediction, language grounding, promptable segmentation, and memory-based video tracking.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–7
- **Papers:** [P048 — Mask R-CNN](https://openaccess.thecvf.com/content_ICCV_2017/html/He_Mask_R-CNN_ICCV_2017_paper.html), [P049 — End-to-End Object Detection with Transformers](https://arxiv.org/abs/2005.12872), [P050 — Grounding DINO: Marrying DINO with Grounded Pre-Training for Open-Set Object Detection](https://arxiv.org/abs/2303.05499), [P051 — Segment Anything](https://openaccess.thecvf.com/content/ICCV2023/html/Kirillov_Segment_Anything_ICCV_2023_paper.html), [P052 — SAM 2: Segment Anything in Images and Videos](https://arxiv.org/abs/2408.00714), [P053 — XMem: Long-Term Video Object Segmentation with an Atkinson–Shiffrin Memory Model](https://arxiv.org/abs/2207.07115)
- **Supporting materials:** R013, R017
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 9. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Build an annotation pipeline combining Grounding DINO, SAM/SAM2, and tracking; audit precision, recall, temporal consistency, and human correction load.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–8; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R013, R017
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Build an annotation pipeline combining Grounding DINO, SAM/SAM2, and tracking; audit precision, recall, temporal consistency, and human correction load.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 10. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–9; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R013, R017
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 11. Topic synthesis and original research directions

- **Central question / objective:** When can foundation perception models generate trustworthy robot-training labels, and where is verification mandatory?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–10
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R013, R017
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: D1, E1, S1.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | P1. |
| Closely related / cross-area | Supports automated labeling in D1, semantic planning in E1, and manipulation in S1. |
| Outgoing capability | D1, E1, S1 |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P048, P049, P050, P051, P052, P053 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**When can foundation perception models generate trustworthy robot-training labels, and where is verification mandatory?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to D1, E1, S1 is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 6 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** No change to topic boundary or primary-paper inventory is proposed.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
