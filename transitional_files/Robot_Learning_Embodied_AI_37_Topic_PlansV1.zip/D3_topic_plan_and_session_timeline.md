# D3 — Research systems, experiment infrastructure, and reproducible training: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** D. Data, evaluation, and research systems  
**Execution status:** **Active Research Track**

## 1. Topic scope and target depth

### Covers

Configuration and provenance, distributed training, checkpointing, deterministic evaluation, artifact tracking, hardware-aware profiling, and recovery.

### Excludes

It excludes generic MLOps product engineering unrelated to scientific reproducibility or robot-learning scale.

### Target competence

Build recoverable, observable, configuration-driven research systems with distributed training, artifact/data provenance, deterministic evaluation, and hardware-aware profiling.

### Place in the wider curriculum

Systems competence track. Supports all implementation and reproduction work.

## 2. Execution status and completion boundary

- **Topic execution status:** Active Research Track
- **Planned sessions:** 9
- **Classification:** 9 required core · 0 advanced continuation · 0 optional specialization · 0 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 9, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 9

## 3. Dependencies and required foundations

- **Master prerequisites:** F1–F5.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Configuration immutability, provenance, environment capture, experiment DAGs, checkpoint semantics, distributed parallelism, failure recovery, profiling, and evaluation isolation.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R015 — [Full Stack Deep Learning](https://fullstackdeeplearning.com/)** (Course): Experiment management, deployment, testing, data, and production ML systems.
- **R016 — [Machine Learning Systems](https://mlsysbook.ai/)** (Open textbook): Hardware-aware training and inference support; use current online version.
- **R017 — [LeRobot Documentation](https://huggingface.co/docs/lerobot/)** (Documentation and open framework): Dataset schema, teleoperation, policy training, evaluation, and low-cost hardware integration.
- **R021 — [Isaac Lab Documentation](https://isaac-sim.github.io/IsaacLab/)** (Simulation and robot-learning documentation): GPU-parallel robot-learning workflows, domain randomization, and deployment interfaces.
- **R027 — [Stanford CS336: Language Modeling from Scratch](https://cs336.stanford.edu/)** (Course, notes, and implementation assignments): End-to-end reconstruction of tokenization, Transformer training, systems optimization, scaling, data preparation, evaluation, and post-training.
- **R029 — [CleanRL Documentation and Reference Implementations](https://docs.cleanrl.dev/)** (Research-oriented single-file implementations): Code-level reconstruction, implementation-difference audits, seeded baselines, and reproducibility checks.
- **R033 — [PyTorch Distributed and Distributed Checkpoint Documentation](https://docs.pytorch.org/tutorials/distributed.html)** (Official framework documentation): DDP/FSDP/tensor parallelism, distributed checkpointing, recovery, profiling, and topology-aware training experiments.
- **R038 — [CORL: Clean Offline Reinforcement Learning](https://corl-team.github.io/CORL/)** (Research-oriented single-file implementations): Auditable CQL/IQL/Decision Transformer/offline-to-online baselines with published benchmark configurations and logs.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: F1–F5.
        │
        ▼
S1 Topic-local foundations: Configuration immutability, provenance, environment capture, experiment DAGs, checkpoint semantics, distributed parallelism, failure recovery, profiling, and evaluation isolation.
        │
        ▼
Paper lineage: P131 → P132 → P133 → P134
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► all implementation/reproduction tracks
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for research systems, experiment infrastructure, and reproducible training and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** F1–F5.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R015, R016, R017, R021, R027, R029, R033, R038
- **Concepts covered:** Configuration immutability, provenance, environment capture, experiment DAGs, checkpoint semantics, distributed parallelism, failure recovery, profiling, and evaluation isolation.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Configuration and provenance, distributed training, checkpointing, deterministic evaluation, artifact tracking, hardware-aware profiling, and recovery. Next, enter the ordered paper lineage.

### 2. P131 — Hidden Technical Debt in Machine Learning Systems

- **Central question / objective:** Catalogs data, dependency, configuration, feedback-loop, and monitoring debt in deployed ML systems.
- **Stage / role:** Paper lineage — Entry Point; Critical
- **Status:** Required core
- **Prerequisites:** Session 1; F1–F5.
- **Papers:** [P131 — Hidden Technical Debt in Machine Learning Systems](https://papers.nips.cc/paper/5656-hidden-technical-debt-in-machine-learning-systems)
- **Supporting materials:** R015, R016
- **Concepts covered:** Catalogs data, dependency, configuration, feedback-loop, and monitoring debt in deployed ML systems. Preparation profile: Entry Point; Critical · Introductory · Low
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in research systems, experiment infrastructure, and reproducible training.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P132). Master lineage note: Frames why experiment infrastructure and data lineage are research requirements.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Conceptual/experience paper rather than controlled experimental evidence.
- **Resumption context:** The durable takeaway is: Catalogs data, dependency, configuration, feedback-loop, and monitoring debt in deployed ML systems. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P132 — ZeRO: Memory Optimizations Toward Training Trillion Parameter Models

- **Central question / objective:** Partitions optimizer, gradient, and parameter states across devices for memory-efficient distributed training.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 2; F1–F5.
- **Papers:** [P132 — ZeRO: Memory Optimizations Toward Training Trillion Parameter Models](https://arxiv.org/abs/1910.02054)
- **Supporting materials:** R015, R016
- **Concepts covered:** Partitions optimizer, gradient, and parameter states across devices for memory-efficient distributed training. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in research systems, experiment infrastructure, and reproducible training.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P133). Master lineage note: Important distributed-training lineage for large VLM/VLA reproduction.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Communication and framework complexity; model scale may exceed club needs.
- **Resumption context:** The durable takeaway is: Partitions optimizer, gradient, and parameter states across devices for memory-efficient distributed training. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P133 — Megatron-LM: Training Multi-Billion Parameter Language Models Using Model Parallelism

- **Central question / objective:** Demonstrates tensor model parallelism for large Transformer training.
- **Stage / role:** Paper lineage — Bridge
- **Status:** Required core
- **Prerequisites:** Session 3; F1–F5.
- **Papers:** [P133 — Megatron-LM: Training Multi-Billion Parameter Language Models Using Model Parallelism](https://arxiv.org/abs/1909.08053)
- **Supporting materials:** R015, R016
- **Concepts covered:** Demonstrates tensor model parallelism for large Transformer training. Preparation profile: Bridge · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in research systems, experiment infrastructure, and reproducible training.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P134). Master lineage note: Complements data parallelism and ZeRO; useful for systems literacy.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Proprietary-scale assumptions and rapidly evolving implementations.
- **Resumption context:** The durable takeaway is: Demonstrates tensor model parallelism for large Transformer training. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P134 — SERL: A Software Suite for Sample-Efficient Robotic Reinforcement Learning

- **Central question / objective:** Packages asynchronous data collection, replay, resets, demonstrations, and actor–learner infrastructure for real-robot RL.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 4; F1–F5.
- **Papers:** [P134 — SERL: A Software Suite for Sample-Efficient Robotic Reinforcement Learning](https://arxiv.org/abs/2401.16013)
- **Supporting materials:** R015, R016
- **Concepts covered:** Packages asynchronous data collection, replay, resets, demonstrations, and actor–learner infrastructure for real-robot RL. Preparation profile: Modern Core · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in research systems, experiment infrastructure, and reproducible training.
- **Relationship in sequence:** Builds on paper session 4; leads to the topic reconstruction/comparison session. Master lineage note: Connects RLPD-style algorithms to reliable physical experimentation.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Hardware/task integration still requires substantial engineering; not a general benchmark.
- **Resumption context:** The durable takeaway is: Packages asynchronous data collection, replay, resets, demonstrations, and actor–learner infrastructure for real-robot RL. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Relate ML technical debt, ZeRO, Megatron-LM, and SERL to the requirements of small-team robot-learning research.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–5
- **Papers:** [P131 — Hidden Technical Debt in Machine Learning Systems](https://papers.nips.cc/paper/5656-hidden-technical-debt-in-machine-learning-systems), [P132 — ZeRO: Memory Optimizations Toward Training Trillion Parameter Models](https://arxiv.org/abs/1910.02054), [P133 — Megatron-LM: Training Multi-Billion Parameter Language Models Using Model Parallelism](https://arxiv.org/abs/1909.08053), [P134 — SERL: A Software Suite for Sample-Efficient Robotic Reinforcement Learning](https://arxiv.org/abs/2401.16013)
- **Supporting materials:** R015, R016, R017, R021, R027, R029, R033, R038
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 7. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Create a reference experiment stack with config validation, seeds, artifact tracking, distributed/checkpoint tests, interruption recovery, and reproducibility reports.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–6; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R015, R016, R017, R021, R027, R029, R033, R038
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Create a reference experiment stack with config validation, seeds, artifact tracking, distributed/checkpoint tests, interruption recovery, and reproducibility reports.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 8. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–7; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R015, R016, R017, R021, R027, R029, R033, R038
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 9. Topic synthesis and original research directions

- **Central question / objective:** Which infrastructure guarantees are prerequisites for believing and extending the club’s experiments?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–8
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R015, R016, R017, R021, R027, R029, R033, R038
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: all implementation/reproduction tracks.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | F1–F5. |
| Closely related / cross-area | Supports all implementation and reproduction work. |
| Outgoing capability | all implementation/reproduction tracks |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P131, P132, P133, P134 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**Which infrastructure guarantees are prerequisites for believing and extending the club’s experiments?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to all implementation/reproduction tracks is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 4 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** Propose adding the following supporting resources to the master supporting-material index: R027, R029, R033, R038. They fill implementation/reconstruction gaps without changing the paper sequence.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
