# L6 — Generative action policies and action representations: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** C. Learning to act  
**Execution status:** **Active Research Track**

## 1. Topic scope and target depth

### Covers

Multimodal action distributions, latent-variable policies, action chunking, autoregressive tokens, diffusion, flow matching, and receding-horizon execution.

### Excludes

It excludes generic image generation and generalist VLA scaling beyond action representation and policy heads.

### Target competence

Compare direct regression, latent-variable, chunked autoregressive, diffusion, flow, and tokenized action policies; reason about multimodality, horizons, closed-loop correction, and latency.

### Place in the wider curriculum

Modern core policy architecture track. Direct bridge to E2 and D4.

## 2. Execution status and completion boundary

- **Topic execution status:** Active Research Track
- **Planned sessions:** 10
- **Classification:** 9 required core · 1 advanced continuation · 0 optional specialization · 0 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 10, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 10

## 3. Dependencies and required foundations

- **Master prerequisites:** F3–F4, L3.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Conditional density modeling, multimodal actions, action chunks, temporal ensembling, receding horizon, diffusion/flow sampling, quantization/tokenization, and control frequency.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R004 — [CS285: Deep Reinforcement Learning](https://rail.eecs.berkeley.edu/deeprlcourse/)** (Lecture notes and videos): Modern bridge from theory to model-free, model-based, imitation, and offline RL.
- **R017 — [LeRobot Documentation](https://huggingface.co/docs/lerobot/)** (Documentation and open framework): Dataset schema, teleoperation, policy training, evaluation, and low-cost hardware integration.
- **R018 — [robomimic Documentation](https://robomimic.github.io/)** (Documentation and benchmark recipes): Reference implementation for demonstration learning and benchmark audits.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: F3–F4, L3.
        │
        ▼
S1 Topic-local foundations: Conditional density modeling, multimodal actions, action chunks, temporal ensembling, receding horizon, diffusion/flow sampling, quantization/tokenization, and control frequency.
        │
        ▼
Paper lineage: P102 → P103 → P104 → P105 → P106
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► D4, E2, S1
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for generative action policies and action representations and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** F3–F4, L3.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R004, R017, R018
- **Concepts covered:** Conditional density modeling, multimodal actions, action chunks, temporal ensembling, receding horizon, diffusion/flow sampling, quantization/tokenization, and control frequency.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Multimodal action distributions, latent-variable policies, action chunking, autoregressive tokens, diffusion, flow matching, and receding-horizon execution. Next, enter the ordered paper lineage.

### 2. P102 — Behavior Transformers: Cloning k Modes with One Stone

- **Central question / objective:** Introduces BeT, combining discrete behavior modes with continuous residual actions.
- **Stage / role:** Paper lineage — Bridge
- **Status:** Required core
- **Prerequisites:** Session 1; F3–F4, L3.
- **Papers:** [P102 — Behavior Transformers: Cloning k Modes with One Stone](https://arxiv.org/abs/2206.11251)
- **Supporting materials:** R004, R017
- **Concepts covered:** Introduces BeT, combining discrete behavior modes with continuous residual actions. Preparation profile: Bridge · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in generative action policies and action representations.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P103). Master lineage note: Alternative to direct regression and precursor to richer generative policies.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Token clustering and autoregressive errors limit precision/latency.
- **Resumption context:** The durable takeaway is: Introduces BeT, combining discrete behavior modes with continuous residual actions. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P103 — Learning Fine-Grained Bimanual Manipulation with Low-Cost Hardware

- **Central question / objective:** Introduces ACT: action-chunking Transformer, temporal ensembling, and low-cost ALOHA data collection.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 2; F3–F4, L3.
- **Papers:** [P103 — Learning Fine-Grained Bimanual Manipulation with Low-Cost Hardware](https://arxiv.org/abs/2304.13705)
- **Supporting materials:** R004, R017
- **Concepts covered:** Introduces ACT: action-chunking Transformer, temporal ensembling, and low-cost ALOHA data collection. Preparation profile: Modern Core · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in generative action policies and action representations.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P104). Master lineage note: Directly links D1 teleoperation to chunked imitation policies.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Task-specific training and fixed observation/action conventions limit generality.
- **Resumption context:** The durable takeaway is: Introduces ACT: action-chunking Transformer, temporal ensembling, and low-cost ALOHA data collection. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P104 — Diffusion Policy: Visuomotor Policy Learning via Action Diffusion

- **Central question / objective:** Models action sequences with conditional diffusion and receding-horizon control.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 3; F3–F4, L3.
- **Papers:** [P104 — Diffusion Policy: Visuomotor Policy Learning via Action Diffusion](https://arxiv.org/abs/2303.04137)
- **Supporting materials:** R004, R017
- **Concepts covered:** Models action sequences with conditional diffusion and receding-horizon control. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in generative action policies and action representations.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P105). Master lineage note: Direct application of F4 diffusion models to multimodal robot behavior.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Iterative sampling and horizon design create latency/reactivity tradeoffs.
- **Resumption context:** The durable takeaway is: Models action sequences with conditional diffusion and receding-horizon control. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P105 — RT-1: Robotics Transformer for Real-World Control at Scale

- **Central question / objective:** Uses tokenized actions and a Transformer policy trained on a large multi-task real-robot dataset.
- **Stage / role:** Paper lineage — Bridge
- **Status:** Required core
- **Prerequisites:** Session 4; F3–F4, L3.
- **Papers:** [P105 — RT-1: Robotics Transformer for Real-World Control at Scale](https://arxiv.org/abs/2212.06817)
- **Supporting materials:** R004, R017
- **Concepts covered:** Uses tokenized actions and a Transformer policy trained on a large multi-task real-robot dataset. Preparation profile: Bridge · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in generative action policies and action representations.
- **Relationship in sequence:** Builds on paper session 4; leads to the next paper in the master sequence (P106). Master lineage note: Bridge from specialist imitation policies to E2 generalist VLAs.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Single-organization data and embodiment; limited open reproduction.
- **Resumption context:** The durable takeaway is: Uses tokenized actions and a Transformer policy trained on a large multi-task real-robot dataset. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. P106 — FAST: Efficient Action Tokenization for Vision-Language-Action Models

- **Central question / objective:** Compresses high-frequency action trajectories into efficient discrete tokens.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Advanced continuation
- **Prerequisites:** Session 5; F3–F4, L3.
- **Papers:** [P106 — FAST: Efficient Action Tokenization for Vision-Language-Action Models](https://arxiv.org/abs/2501.09747)
- **Supporting materials:** R004, R017
- **Concepts covered:** Compresses high-frequency action trajectories into efficient discrete tokens. Preparation profile: Modern Core · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in generative action policies and action representations.
- **Relationship in sequence:** Builds on paper session 5; leads to the topic reconstruction/comparison session. Master lineage note: Improves autoregressive VLA action efficiency and connects to D4.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Tokenization quality is embodiment/data dependent; discrete reconstruction errors matter.
- **Resumption context:** The durable takeaway is: Compresses high-frequency action trajectories into efficient discrete tokens. Continue by comparing its assumptions and evidence with the next lineage stage.

### 7. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Build a common representation of BeT, ACT, Diffusion Policy, RT-1, and FAST, separating observation encoder, action representation, objective, sampler, and execution loop.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–6
- **Papers:** [P102 — Behavior Transformers: Cloning k Modes with One Stone](https://arxiv.org/abs/2206.11251), [P103 — Learning Fine-Grained Bimanual Manipulation with Low-Cost Hardware](https://arxiv.org/abs/2304.13705), [P104 — Diffusion Policy: Visuomotor Policy Learning via Action Diffusion](https://arxiv.org/abs/2303.04137), [P105 — RT-1: Robotics Transformer for Real-World Control at Scale](https://arxiv.org/abs/2212.06817), [P106 — FAST: Efficient Action Tokenization for Vision-Language-Action Models](https://arxiv.org/abs/2501.09747)
- **Supporting materials:** R004, R017, R018
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 8. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Train at least two action-policy families on the same demonstrations and measure rollout success, diversity, smoothness, latency, and sensitivity to chunk/horizon settings.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–7; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R004, R017, R018
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Train at least two action-policy families on the same demonstrations and measure rollout success, diversity, smoothness, latency, and sensitivity to chunk/horizon settings.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 9. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–8; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R004, R017, R018
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 10. Topic synthesis and original research directions

- **Central question / objective:** How should an action distribution be represented when behavior is multimodal but control must remain reactive and real-time?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–9
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R004, R017, R018
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: D4, E2, S1.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | F3–F4, L3. |
| Closely related / cross-area | Direct bridge to E2 and D4. |
| Outgoing capability | D4, E2, S1 |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P102, P103, P104, P105, P106 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**How should an action distribution be represented when behavior is multimodal but control must remain reactive and real-time?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to D4, E2, S1 is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 5 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** No change to topic boundary or primary-paper inventory is proposed.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
