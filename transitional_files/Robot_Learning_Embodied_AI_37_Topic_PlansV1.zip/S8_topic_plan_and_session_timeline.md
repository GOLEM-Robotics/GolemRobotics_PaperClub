# S8 — Human feedback, shared autonomy, and human–robot interaction: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** F. Specialization branches  
**Execution status:** **Optional**

## 1. Topic scope and target depth

### Covers

Preference learning, corrections, interventions, shared autonomy, intent inference, and human-centered evaluation.

### Excludes

It excludes broad social-robotics theory unrelated to learning, feedback, shared control, or evaluation of physical systems.

### Target competence

Design human-feedback, correction, intervention, and shared-autonomy systems; model intent and authority; conduct valid human-centered evaluations.

### Place in the wider curriculum

Optional cross-cutting branch. Supports safe deployment and data collection.

## 2. Execution status and completion boundary

- **Topic execution status:** Optional
- **Planned sessions:** 9
- **Classification:** 4 required core · 0 advanced continuation · 5 optional specialization · 0 frontier continuation
- **Completion boundary:** The topic is not part of the currently executable curriculum. If activated, its internal required core runs through Session 6; remaining sessions are optional specialization or frontier continuations.
- **Required core endpoint:** Session 6

## 3. Dependencies and required foundations

- **Master prerequisites:** L3–L4, L8, E1.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Preference elicitation, corrections, interventions, shared-control blending, intent inference, trust/calibration, study design, ethics, workload, and user variability.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R001 — [Reinforcement Learning: An Introduction, 2nd ed.](http://incompleteideas.net/book/the-book-2nd.html)** (Textbook): Primary mathematical entry point; use selected chapters before original TD/Q/policy-gradient papers.
- **R004 — [CS285: Deep Reinforcement Learning](https://rail.eecs.berkeley.edu/deeprlcourse/)** (Lecture notes and videos): Modern bridge from theory to model-free, model-based, imitation, and offline RL.
- **R018 — [robomimic Documentation](https://robomimic.github.io/)** (Documentation and benchmark recipes): Reference implementation for demonstration learning and benchmark audits.
- **R035 — [Human–Robot Interaction: An Introduction, 2nd ed.](https://www.human-robot-interaction.org/)** (Open textbook): HRI concepts, study design, human-centered evaluation, interaction modalities, and societal constraints.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: L3–L4, L8, E1.
        │
        ▼
S1 Topic-local foundations: Preference elicitation, corrections, interventions, shared-control blending, intent inference, trust/calibration, study design, ethics, workload, and user variability.
        │
        ▼
Paper lineage: P190 → P191 → P192 → P193
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► D1, L8, E1–E3
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for human feedback, shared autonomy, and human–robot interaction and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** L3–L4, L8, E1.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R001, R004, R018, R035
- **Concepts covered:** Preference elicitation, corrections, interventions, shared-control blending, intent inference, trust/calibration, study design, ethics, workload, and user variability.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Preference learning, corrections, interventions, shared autonomy, intent inference, and human-centered evaluation. Next, enter the ordered paper lineage.

### 2. P190 — Deep Reinforcement Learning from Human Preferences

- **Central question / objective:** Learns reward models from pairwise human trajectory preferences and optimizes policies against them.
- **Stage / role:** Paper lineage — Foundation
- **Status:** Required core
- **Prerequisites:** Session 1; L3–L4, L8, E1.
- **Papers:** [P190 — Deep Reinforcement Learning from Human Preferences](https://arxiv.org/abs/1706.03741)
- **Supporting materials:** R001, R004
- **Concepts covered:** Learns reward models from pairwise human trajectory preferences and optimizes policies against them. Preparation profile: Foundation · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in human feedback, shared autonomy, and human–robot interaction.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P191). Master lineage note: Foundation for RLHF and embodied reward learning.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Preference burden, reward hacking, and distribution shift remain serious.
- **Resumption context:** The durable takeaway is: Learns reward models from pairwise human trajectory preferences and optimizes policies against them. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P191 — PEBBLE: Feedback-Efficient Interactive Reinforcement Learning via Relabeling Experience and Unsupervised Pre-Training

- **Central question / objective:** Improves preference-based RL with unsupervised pretraining and relabeling.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 2; L3–L4, L8, E1.
- **Papers:** [P191 — PEBBLE: Feedback-Efficient Interactive Reinforcement Learning via Relabeling Experience and Unsupervised Pre-Training](https://proceedings.mlr.press/v139/lee21i.html)
- **Supporting materials:** R001, R004
- **Concepts covered:** Improves preference-based RL with unsupervised pretraining and relabeling. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in human feedback, shared autonomy, and human–robot interaction.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P192). Master lineage note: Develops human-preference RL toward greater feedback efficiency.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Mostly simulated benchmarks; preference-model exploitation remains.
- **Resumption context:** The durable takeaway is: Improves preference-based RL with unsupervised pretraining and relabeling. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P192 — Shared Autonomy via Deep Reinforcement Learning

- **Central question / objective:** Learns assistance policies from user input while inferring intended goals.
- **Stage / role:** Paper lineage — Bridge
- **Status:** Optional specialization
- **Prerequisites:** Session 3; L3–L4, L8, E1.
- **Papers:** [P192 — Shared Autonomy via Deep Reinforcement Learning](https://arxiv.org/abs/1802.01744)
- **Supporting materials:** R001, R004
- **Concepts covered:** Learns assistance policies from user input while inferring intended goals. Preparation profile: Bridge · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in human feedback, shared autonomy, and human–robot interaction.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P193). Master lineage note: Connects HRI, intent inference, and policy learning.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Assumes goal sets/training distribution and can over-assist under ambiguity.
- **Resumption context:** The durable takeaway is: Learns assistance policies from user input while inferring intended goals. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P193 — Learning from Interventions Using Hierarchical Policies for Safe Learning

- **Central question / objective:** Corrects reaction-delay labels and adds hierarchical subgoal prediction to intervention-based learning.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Optional specialization
- **Prerequisites:** Session 4; L3–L4, L8, E1.
- **Papers:** [P193 — Learning from Interventions Using Hierarchical Policies for Safe Learning](https://ojs.aaai.org/index.php/AAAI/article/view/6602)
- **Supporting materials:** R001, R004
- **Concepts covered:** Corrects reaction-delay labels and adds hierarchical subgoal prediction to intervention-based learning. Preparation profile: Modern Core · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in human feedback, shared autonomy, and human–robot interaction.
- **Relationship in sequence:** Builds on paper session 4; leads to the topic reconstruction/comparison session. Master lineage note: Complements DAgger, ThriftyDAgger, and HIL-SERL.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Evidence is primarily simulated and depends on consistent expert oversight.
- **Resumption context:** The durable takeaway is: Corrects reaction-delay labels and adds hierarchical subgoal prediction to intervention-based learning. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Connect preference learning, corrective feedback, shared autonomy, and intervention-based learning as different allocations of human authority and information.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–5
- **Papers:** [P190 — Deep Reinforcement Learning from Human Preferences](https://arxiv.org/abs/1706.03741), [P191 — PEBBLE: Feedback-Efficient Interactive Reinforcement Learning via Relabeling Experience and Unsupervised Pre-Training](https://proceedings.mlr.press/v139/lee21i.html), [P192 — Shared Autonomy via Deep Reinforcement Learning](https://arxiv.org/abs/1802.01744), [P193 — Learning from Interventions Using Hierarchical Policies for Safe Learning](https://ojs.aaai.org/index.php/AAAI/article/view/6602)
- **Supporting materials:** R001, R004, R018, R035
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 7. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Prototype a shared-autonomy or feedback interface and run a small controlled/user study or simulation-based evaluation with safety, workload, and performance metrics.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Optional specialization
- **Prerequisites:** Sessions 1–6; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R001, R004, R018, R035
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Prototype a shared-autonomy or feedback interface and run a small controlled/user study or simulation-based evaluation with safety, workload, and performance metrics.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 8. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Optional specialization
- **Prerequisites:** Sessions 1–7; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R001, R004, R018, R035
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 9. Topic synthesis and original research directions

- **Central question / objective:** How should authority, learning, uncertainty, and accountability be distributed between human and robot?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Optional specialization
- **Prerequisites:** Sessions 1–8
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R001, R004, R018, R035
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: D1, L8, E1–E3.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | L3–L4, L8, E1. |
| Closely related / cross-area | Supports safe deployment and data collection. |
| Outgoing capability | D1, L8, E1–E3 |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P190, P191, P192, P193 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**How should authority, learning, uncertainty, and accountability be distributed between human and robot?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to D1, L8, E1–E3 is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 4 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** Propose adding the following supporting resources to the master supporting-material index: R035. They fill implementation/reconstruction gaps without changing the paper sequence.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
