# F3 — Neural architectures and sequence models: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** A. Shared foundations  
**Execution status:** **Shared Core**

## 1. Topic scope and target depth

### Covers

Residual networks, attention, Transformers, tokenization, positional representations, state-space alternatives, and architectural inductive biases.

### Excludes

It excludes full foundation-model data/post-training pipelines, which belong to F5, and domain-specific perception/policy uses.

### Target competence

Reconstruct residual, attention, Transformer, tokenization/position, and state-space mechanisms; reason about inductive bias, complexity, memory, and suitability for physical sequences.

### Place in the wider curriculum

Common architectural language. Supports P1–P4, E1–E3, L6, and E2.

## 2. Execution status and completion boundary

- **Topic execution status:** Shared Core
- **Planned sessions:** 10
- **Classification:** 8 required core · 0 advanced continuation · 2 optional specialization · 0 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 10, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 10

## 3. Dependencies and required foundations

- **Master prerequisites:** F2.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Tensor shapes, convolution and residual paths, sequence tokenization, attention algebra, positional information, recurrence/state-space views, compute and memory scaling.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R011 — [Deep Learning](https://www.deeplearningbook.org/)** (Open textbook): Targeted chapters for optimization, regularization, sequence models, and generative modeling.
- **R012 — [Dive into Deep Learning](https://d2l.ai/)** (Interactive open textbook): Implementation-oriented prerequisite repair for uneven member backgrounds.
- **R014 — [Stanford CS224n](https://web.stanford.edu/class/cs224n/)** (Lecture notes): Transformer, language-model, and alignment prerequisites.
- **R027 — [Stanford CS336: Language Modeling from Scratch](https://cs336.stanford.edu/)** (Course, notes, and implementation assignments): End-to-end reconstruction of tokenization, Transformer training, systems optimization, scaling, data preparation, evaluation, and post-training.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: F2.
        │
        ▼
S1 Topic-local foundations: Tensor shapes, convolution and residual paths, sequence tokenization, attention algebra, positional information, recurrence/state-space views, compute and memory scaling.
        │
        ▼
Paper lineage: P009 → P010 → P011 → P012 → P013
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► F4–F5, P1–P4, L6, E1–E3
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for neural architectures and sequence models and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** F2.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R011, R012, R014, R027
- **Concepts covered:** Tensor shapes, convolution and residual paths, sequence tokenization, attention algebra, positional information, recurrence/state-space views, compute and memory scaling.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Residual networks, attention, Transformers, tokenization, positional representations, state-space alternatives, and architectural inductive biases. Next, enter the ordered paper lineage.

### 2. P009 — Deep Residual Learning for Image Recognition

- **Central question / objective:** Establishes residual connections as a practical mechanism for training deep networks.
- **Stage / role:** Paper lineage — Foundation; Seminal
- **Status:** Required core
- **Prerequisites:** Session 1; F2.
- **Papers:** [P009 — Deep Residual Learning for Image Recognition](https://openaccess.thecvf.com/content_cvpr_2016/html/He_Deep_Residual_Learning_CVPR_2016_paper.html)
- **Supporting materials:** R011, R012
- **Concepts covered:** Establishes residual connections as a practical mechanism for training deep networks. Preparation profile: Foundation; Seminal · Intermediate · Medium; focus architecture and ablations
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in neural architectures and sequence models.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P010). Master lineage note: Architectural precursor to modern vision and multimodal backbones.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Image classification setting; later architectures alter normalization and block design.
- **Resumption context:** The durable takeaway is: Establishes residual connections as a practical mechanism for training deep networks. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P010 — Attention Is All You Need

- **Central question / objective:** Introduces the Transformer architecture based on self-attention and cross-attention.
- **Stage / role:** Paper lineage — Seminal
- **Status:** Required core
- **Prerequisites:** Session 2; F2.
- **Papers:** [P010 — Attention Is All You Need](https://arxiv.org/abs/1706.03762)
- **Supporting materials:** R011, R012
- **Concepts covered:** Introduces the Transformer architecture based on self-attention and cross-attention. Preparation profile: Seminal · Intermediate · High; reconstruct attention, masking, and positional encoding
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in neural architectures and sequence models.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P011). Master lineage note: Foundation for F5, P1/P4, E1/E2, and L6.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Original model is small and sequence-length quadratic; later variants are substantial.
- **Resumption context:** The durable takeaway is: Introduces the Transformer architecture based on self-attention and cross-attention. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P011 — An Image Is Worth 16×16 Words: Transformers for Image Recognition at Scale

- **Central question / objective:** Shows patch-tokenized Transformers can become strong visual backbones under large-scale pretraining.
- **Stage / role:** Paper lineage — Bridge; Modern Core
- **Status:** Required core
- **Prerequisites:** Session 3; F2.
- **Papers:** [P011 — An Image Is Worth 16×16 Words: Transformers for Image Recognition at Scale](https://arxiv.org/abs/2010.11929)
- **Supporting materials:** R011, R012
- **Concepts covered:** Shows patch-tokenized Transformers can become strong visual backbones under large-scale pretraining. Preparation profile: Bridge; Modern Core · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in neural architectures and sequence models.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P012). Master lineage note: Connects Transformer sequence modeling to P1 and E2.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Data-hungry relative to convolutional baselines; limited dense prediction analysis.
- **Resumption context:** The durable takeaway is: Shows patch-tokenized Transformers can become strong visual backbones under large-scale pretraining. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P012 — Efficiently Modeling Long Sequences with Structured State Spaces

- **Central question / objective:** Introduces S4, a structured state-space sequence model for long contexts.
- **Stage / role:** Paper lineage — Optional Specialization; Bridge
- **Status:** Optional specialization
- **Prerequisites:** Session 4; F2.
- **Papers:** [P012 — Efficiently Modeling Long Sequences with Structured State Spaces](https://arxiv.org/abs/2111.00396)
- **Supporting materials:** R011, R012
- **Concepts covered:** Introduces S4, a structured state-space sequence model for long contexts. Preparation profile: Optional Specialization; Bridge · Advanced · High; focus state-space construction and convolutional form
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in neural architectures and sequence models.
- **Relationship in sequence:** Builds on paper session 4; leads to the next paper in the master sequence (P013). Master lineage note: Alternative lineage to Transformers; precedes Mamba.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Complex implementation and limited direct robotics evidence.
- **Resumption context:** The durable takeaway is: Introduces S4, a structured state-space sequence model for long contexts. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. P013 — Mamba: Linear-Time Sequence Modeling with Selective State Spaces

- **Central question / objective:** Introduces input-dependent selective state-space models with linear-time sequence processing.
- **Stage / role:** Paper lineage — Modern Core; Optional
- **Status:** Optional specialization
- **Prerequisites:** Session 5; F2.
- **Papers:** [P013 — Mamba: Linear-Time Sequence Modeling with Selective State Spaces](https://arxiv.org/abs/2312.00752)
- **Supporting materials:** R011, R012
- **Concepts covered:** Introduces input-dependent selective state-space models with linear-time sequence processing. Preparation profile: Modern Core; Optional · Advanced · High; focus selective SSM and hardware-aware scan
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in neural architectures and sequence models.
- **Relationship in sequence:** Builds on paper session 5; leads to the topic reconstruction/comparison session. Master lineage note: Builds on S4; relevant to long-context embodied memory and D4.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Early robotics evidence remains limited relative to Transformer baselines.
- **Resumption context:** The durable takeaway is: Introduces input-dependent selective state-space models with linear-time sequence processing. Continue by comparing its assumptions and evidence with the next lineage stage.

### 7. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Build a shape- and equation-level comparison of ResNet, Transformer/ViT, S4, and Mamba blocks.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–6
- **Papers:** [P009 — Deep Residual Learning for Image Recognition](https://openaccess.thecvf.com/content_cvpr_2016/html/He_Deep_Residual_Learning_CVPR_2016_paper.html), [P010 — Attention Is All You Need](https://arxiv.org/abs/1706.03762), [P011 — An Image Is Worth 16×16 Words: Transformers for Image Recognition at Scale](https://arxiv.org/abs/2010.11929), [P012 — Efficiently Modeling Long Sequences with Structured State Spaces](https://arxiv.org/abs/2111.00396), [P013 — Mamba: Linear-Time Sequence Modeling with Selective State Spaces](https://arxiv.org/abs/2312.00752)
- **Supporting materials:** R011, R012, R014, R027
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 8. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Implement minimal residual, attention, and selective-state-space blocks; profile sequence-length scaling and verify masking/state behavior.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–7; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R011, R012, R014, R027
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Implement minimal residual, attention, and selective-state-space blocks; profile sequence-length scaling and verify masking/state behavior.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 9. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–8; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R011, R012, R014, R027
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 10. Topic synthesis and original research directions

- **Central question / objective:** How should architecture choice change for images, language, video, and high-rate robot trajectories?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–9
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R011, R012, R014, R027
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: F4–F5, P1–P4, L6, E1–E3.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | F2. |
| Closely related / cross-area | Supports P1–P4, E1–E3, L6, and E2. |
| Outgoing capability | F4–F5, P1–P4, L6, E1–E3 |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P009, P010, P011, P012, P013 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**How should architecture choice change for images, language, video, and high-rate robot trajectories?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to F4–F5, P1–P4, L6, E1–E3 is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 5 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** Propose adding the following supporting resources to the master supporting-material index: R027. They fill implementation/reconstruction gaps without changing the paper sequence.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
