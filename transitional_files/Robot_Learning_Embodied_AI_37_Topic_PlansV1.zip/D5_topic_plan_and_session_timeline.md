# D5 — Synthetic data, learned simulators, and scalable data engines: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** D. Data, evaluation, and research systems  
**Execution status:** **Specialization**

## 1. Topic scope and target depth

### Covers

Procedural generation, imitation-data generation, world-model rollouts, video generation, learned physics, and synthetic-to-real validation.

### Excludes

It excludes synthetic data used only for visual novelty without a validated downstream learning or evaluation purpose.

### Target competence

Design procedural and learned data engines; evaluate coverage, bias, controllability, sim-to-real transfer, and whether synthetic rollouts improve policies or benchmarks.

### Place in the wider curriculum

Specialized scaling and data-generation branch. Feeds E2 and specialization tracks.

## 2. Execution status and completion boundary

- **Topic execution status:** Specialization
- **Planned sessions:** 10
- **Classification:** 7 required core · 0 advanced continuation · 0 optional specialization · 3 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 10, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 10

## 3. Dependencies and required foundations

- **Master prerequisites:** P3–P5, L7, D1.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Procedural generation, scene/task distributions, synthetic labels, simulator fidelity, learned simulators, rollout filtering, domain gap, and coverage metrics.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R019 — [ManiSkill Documentation](https://maniskill.readthedocs.io/)** (Simulation/benchmark documentation): High-throughput manipulation experiments and standardized evaluation.
- **R021 — [Isaac Lab Documentation](https://isaac-sim.github.io/IsaacLab/)** (Simulation and robot-learning documentation): GPU-parallel robot-learning workflows, domain randomization, and deployment interfaces.
- **R024 — [Robot Learning from Randomized Simulations: A Review](https://arxiv.org/abs/2111.00956)** (Survey): Structured overview of domain randomization assumptions, methods, and limitations.
- **R026 — [A Survey on Model-Based Reinforcement Learning](https://arxiv.org/abs/2006.16712)** (Survey): Taxonomy of learned models, planning, uncertainty, and policy learning.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: P3–P5, L7, D1.
        │
        ▼
S1 Topic-local foundations: Procedural generation, scene/task distributions, synthetic labels, simulator fidelity, learned simulators, rollout filtering, domain gap, and coverage metrics.
        │
        ▼
Paper lineage: P139 → P140 → P141 → P142 → P143
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► P5, E2–E3, S5
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for synthetic data, learned simulators, and scalable data engines and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** P3–P5, L7, D1.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R019, R021, R024, R026
- **Concepts covered:** Procedural generation, scene/task distributions, synthetic labels, simulator fidelity, learned simulators, rollout filtering, domain gap, and coverage metrics.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Procedural generation, imitation-data generation, world-model rollouts, video generation, learned physics, and synthetic-to-real validation. Next, enter the ordered paper lineage.

### 2. P139 — MimicGen: A Data Generation System for Scalable Robot Learning using Human Demonstrations

- **Central question / objective:** Generates diverse task demonstrations by transforming and recomposing a small set of human demonstrations in simulation.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 1; P3–P5, L7, D1.
- **Papers:** [P139 — MimicGen: A Data Generation System for Scalable Robot Learning using Human Demonstrations](https://arxiv.org/abs/2310.17596)
- **Supporting materials:** R019, R021
- **Concepts covered:** Generates diverse task demonstrations by transforming and recomposing a small set of human demonstrations in simulation. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in synthetic data, learned simulators, and scalable data engines.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P140). Master lineage note: Scales imitation data while preserving task structure.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Requires object-centric state and simulator access; sim-to-real validity must be tested.
- **Resumption context:** The durable takeaway is: Generates diverse task demonstrations by transforming and recomposing a small set of human demonstrations in simulation. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P140 — RoboGen: Towards Unleashing Infinite Data for Automated Robot Learning via Generative Simulation

- **Central question / objective:** Uses generative models and LLMs to propose tasks, assets, environments, and training procedures in simulation.
- **Stage / role:** Paper lineage — Bridge; Frontier
- **Status:** Frontier continuation
- **Prerequisites:** Session 2; P3–P5, L7, D1.
- **Papers:** [P140 — RoboGen: Towards Unleashing Infinite Data for Automated Robot Learning via Generative Simulation](https://arxiv.org/abs/2311.01455)
- **Supporting materials:** R019, R021
- **Concepts covered:** Uses generative models and LLMs to propose tasks, assets, environments, and training procedures in simulation. Preparation profile: Bridge; Frontier · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in synthetic data, learned simulators, and scalable data engines.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P141). Master lineage note: Extends procedural generation toward autonomous data engines.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Generated tasks/rewards can be invalid or biased; physical transfer is limited.
- **Resumption context:** The durable takeaway is: Uses generative models and LLMs to propose tasks, assets, environments, and training procedures in simulation. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P141 — GenSim: Generating Robotic Simulation Tasks via Large Language Models

- **Central question / objective:** Generates task code and simulation assets with LLMs and self-refinement.
- **Stage / role:** Paper lineage — Bridge
- **Status:** Required core
- **Prerequisites:** Session 3; P3–P5, L7, D1.
- **Papers:** [P141 — GenSim: Generating Robotic Simulation Tasks via Large Language Models](https://arxiv.org/abs/2310.01361)
- **Supporting materials:** R019, R021
- **Concepts covered:** Generates task code and simulation assets with LLMs and self-refinement. Preparation profile: Bridge · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in synthetic data, learned simulators, and scalable data engines.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P142). Master lineage note: Task-generation counterpart to MimicGen and RoboGen.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Code generation errors and simulator-task validity require human verification.
- **Resumption context:** The durable takeaway is: Generates task code and simulation assets with LLMs and self-refinement. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P142 — DreamGen: Unlocking Generalization in Robot Learning through Video World Models

- **Central question / objective:** Uses video world models to generate diverse synthetic robot trajectories for policy training.
- **Stage / role:** Paper lineage — Frontier Bridge
- **Status:** Frontier continuation
- **Prerequisites:** Session 4; P3–P5, L7, D1.
- **Papers:** [P142 — DreamGen: Unlocking Generalization in Robot Learning through Video World Models](https://arxiv.org/abs/2505.12705)
- **Supporting materials:** R019, R021
- **Concepts covered:** Uses video world models to generate diverse synthetic robot trajectories for policy training. Preparation profile: Frontier Bridge · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in synthetic data, learned simulators, and scalable data engines.
- **Relationship in sequence:** Builds on paper session 4; leads to the next paper in the master sequence (P143). Master lineage note: Connects video generation, data augmentation, and generalist policies.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Synthetic action/physics fidelity and closed-loop benefit require independent validation.
- **Resumption context:** The durable takeaway is: Uses video world models to generate diverse synthetic robot trajectories for policy training. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. P143 — DreamDojo: A Generalist Robot World Model from Large-Scale Human Videos

- **Central question / objective:** Trains a generalist robot world model from large-scale human video for prediction, evaluation, and planning.
- **Stage / role:** Paper lineage — Frontier
- **Status:** Frontier continuation
- **Prerequisites:** Session 5; P3–P5, L7, D1.
- **Papers:** [P143 — DreamDojo: A Generalist Robot World Model from Large-Scale Human Videos](https://dreamdojo-world.github.io/)
- **Supporting materials:** R019, R021
- **Concepts covered:** Trains a generalist robot world model from large-scale human video for prediction, evaluation, and planning. Preparation profile: Frontier · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in synthetic data, learned simulators, and scalable data engines.
- **Relationship in sequence:** Builds on paper session 5; leads to the topic reconstruction/comparison session. Master lineage note: Extends video world models from synthetic data generation toward interactive robot-world simulation.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Very recent; compute, data, and evaluation independence require scrutiny.
- **Resumption context:** The durable takeaway is: Trains a generalist robot world model from large-scale human video for prediction, evaluation, and planning. Continue by comparing its assumptions and evidence with the next lineage stage.

### 7. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Compare procedural generation, scalable simulators, learned world models, and data-engine approaches by controllability, cost, fidelity, and validation.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–6
- **Papers:** [P139 — MimicGen: A Data Generation System for Scalable Robot Learning using Human Demonstrations](https://arxiv.org/abs/2310.17596), [P140 — RoboGen: Towards Unleashing Infinite Data for Automated Robot Learning via Generative Simulation](https://arxiv.org/abs/2311.01455), [P141 — GenSim: Generating Robotic Simulation Tasks via Large Language Models](https://arxiv.org/abs/2310.01361), [P142 — DreamGen: Unlocking Generalization in Robot Learning through Video World Models](https://arxiv.org/abs/2505.12705), [P143 — DreamDojo: A Generalist Robot World Model from Large-Scale Human Videos](https://dreamdojo-world.github.io/)
- **Supporting materials:** R019, R021, R024, R026
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 8. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Generate a controlled synthetic dataset or simulator curriculum, train a downstream model, and measure transfer against real/held-out data with ablations.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–7; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R019, R021, R024, R026
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Generate a controlled synthetic dataset or simulator curriculum, train a downstream model, and measure transfer against real/held-out data with ablations.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 9. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–8; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R019, R021, R024, R026
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 10. Topic synthesis and original research directions

- **Central question / objective:** When does synthetic scale create capability, and when does it amplify simulator or generator bias?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–9
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R019, R021, R024, R026
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: P5, E2–E3, S5.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | P3–P5, L7, D1. |
| Closely related / cross-area | Feeds E2 and specialization tracks. |
| Outgoing capability | P5, E2–E3, S5 |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P139, P140, P141, P142, P143 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**When does synthetic scale create capability, and when does it amplify simulator or generator bias?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to P5, E2–E3, S5 is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 5 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** No change to topic boundary or primary-paper inventory is proposed.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
