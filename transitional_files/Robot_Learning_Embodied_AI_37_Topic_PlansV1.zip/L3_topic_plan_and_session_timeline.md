# L3 — Imitation learning and inverse reinforcement learning: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** C. Learning to act  
**Execution status:** **Shared Core**

## 1. Topic scope and target depth

### Covers

Behavior cloning, covariate shift, interactive imitation, occupancy matching, reward recovery, and demonstration-guided policy optimization.

### Excludes

It excludes fixed-dataset value learning covered in L4 and modern generative policy architectures covered in L6.

### Target competence

Diagnose behavior-cloning distribution shift; derive DAgger, max-entropy IRL, GAIL/AIRL, and demonstration-guided RL; select intervention and demonstration strategies.

### Place in the wider curriculum

Central learning-from-demonstration lineage. Precedes L4, L6, D1, and most robot-policy work.

## 2. Execution status and completion boundary

- **Topic execution status:** Shared Core
- **Planned sessions:** 11
- **Classification:** 11 required core · 0 advanced continuation · 0 optional specialization · 0 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 11, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 11

## 3. Dependencies and required foundations

- **Master prerequisites:** L1; supervised learning.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Supervised policy learning, covariate shift, compounding error, occupancy measures, maximum entropy, reward ambiguity, discriminator objectives, and expert-query cost.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R001 — [Reinforcement Learning: An Introduction, 2nd ed.](http://incompleteideas.net/book/the-book-2nd.html)** (Textbook): Primary mathematical entry point; use selected chapters before original TD/Q/policy-gradient papers.
- **R004 — [CS285: Deep Reinforcement Learning](https://rail.eecs.berkeley.edu/deeprlcourse/)** (Lecture notes and videos): Modern bridge from theory to model-free, model-based, imitation, and offline RL.
- **R018 — [robomimic Documentation](https://robomimic.github.io/)** (Documentation and benchmark recipes): Reference implementation for demonstration learning and benchmark audits.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: L1; supervised learning.
        │
        ▼
S1 Topic-local foundations: Supervised policy learning, covariate shift, compounding error, occupancy measures, maximum entropy, reward ambiguity, discriminator objectives, and expert-query cost.
        │
        ▼
Paper lineage: P084 → P085 → P086 → P087 → P088 → P089
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► L4, L6, D1, E2, S1–S2, S8
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for imitation learning and inverse reinforcement learning and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** L1; supervised learning.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R001, R004, R018
- **Concepts covered:** Supervised policy learning, covariate shift, compounding error, occupancy measures, maximum entropy, reward ambiguity, discriminator objectives, and expert-query cost.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Behavior cloning, covariate shift, interactive imitation, occupancy matching, reward recovery, and demonstration-guided policy optimization. Next, enter the ordered paper lineage.

### 2. P084 — A Reduction of Imitation Learning and Structured Prediction to No-Regret Online Learning

- **Central question / objective:** Introduces DAgger and formalizes compounding error from covariate shift.
- **Stage / role:** Paper lineage — Seminal
- **Status:** Required core
- **Prerequisites:** Session 1; L1; supervised learning.
- **Papers:** [P084 — A Reduction of Imitation Learning and Structured Prediction to No-Regret Online Learning](https://proceedings.mlr.press/v15/ross11a.html)
- **Supporting materials:** R001, R004
- **Concepts covered:** Introduces DAgger and formalizes compounding error from covariate shift. Preparation profile: Seminal · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in imitation learning and inverse reinforcement learning.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P085). Master lineage note: Foundation for interactive corrections and human-in-the-loop data loops.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Requires expert queries during rollout; unsafe states may be costly.
- **Resumption context:** The durable takeaway is: Introduces DAgger and formalizes compounding error from covariate shift. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P085 — Maximum Entropy Inverse Reinforcement Learning

- **Central question / objective:** Infers rewards by maximum-entropy trajectory modeling.
- **Stage / role:** Paper lineage — Foundation
- **Status:** Required core
- **Prerequisites:** Session 2; L1; supervised learning.
- **Papers:** [P085 — Maximum Entropy Inverse Reinforcement Learning](https://www.aaai.org/Papers/AAAI/2008/AAAI08-227.pdf)
- **Supporting materials:** R001, R004
- **Concepts covered:** Infers rewards by maximum-entropy trajectory modeling. Preparation profile: Foundation · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in imitation learning and inverse reinforcement learning.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P086). Master lineage note: Foundation for probabilistic IRL and GAIL/AIRL.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Reward identifiability and dynamics knowledge remain difficult.
- **Resumption context:** The durable takeaway is: Infers rewards by maximum-entropy trajectory modeling. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P086 — Generative Adversarial Imitation Learning

- **Central question / objective:** Matches expert occupancy measures through adversarial learning.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 3; L1; supervised learning.
- **Papers:** [P086 — Generative Adversarial Imitation Learning](https://arxiv.org/abs/1606.03476)
- **Supporting materials:** R001, R004
- **Concepts covered:** Matches expert occupancy measures through adversarial learning. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in imitation learning and inverse reinforcement learning.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P087). Master lineage note: Connects IRL and policy optimization without explicit reward recovery.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Training instability and sample cost; discriminator reward may not transfer.
- **Resumption context:** The durable takeaway is: Matches expert occupancy measures through adversarial learning. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P087 — Learning Robust Rewards with Adversarial Inverse Reinforcement Learning

- **Central question / objective:** Introduces AIRL to recover disentangled rewards under adversarial imitation.
- **Stage / role:** Paper lineage — Bridge
- **Status:** Required core
- **Prerequisites:** Session 4; L1; supervised learning.
- **Papers:** [P087 — Learning Robust Rewards with Adversarial Inverse Reinforcement Learning](https://arxiv.org/abs/1710.11248)
- **Supporting materials:** R001, R004
- **Concepts covered:** Introduces AIRL to recover disentangled rewards under adversarial imitation. Preparation profile: Bridge · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in imitation learning and inverse reinforcement learning.
- **Relationship in sequence:** Builds on paper session 4; leads to the next paper in the master sequence (P088). Master lineage note: Develops GAIL toward transferable reward learning.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Identifiability assumptions and adversarial instability remain.
- **Resumption context:** The durable takeaway is: Introduces AIRL to recover disentangled rewards under adversarial imitation. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. P088 — Learning Complex Dexterous Manipulation with Deep Reinforcement Learning and Demonstrations

- **Central question / objective:** Introduces DAPG, combining demonstrations with policy-gradient fine-tuning for dexterous hands.
- **Stage / role:** Paper lineage — Bridge; Modern Core
- **Status:** Required core
- **Prerequisites:** Session 5; L1; supervised learning.
- **Papers:** [P088 — Learning Complex Dexterous Manipulation with Deep Reinforcement Learning and Demonstrations](https://arxiv.org/abs/1709.10087)
- **Supporting materials:** R001, R004
- **Concepts covered:** Introduces DAPG, combining demonstrations with policy-gradient fine-tuning for dexterous hands. Preparation profile: Bridge; Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in imitation learning and inverse reinforcement learning.
- **Relationship in sequence:** Builds on paper session 5; leads to the next paper in the master sequence (P089). Master lineage note: Connects behavior cloning, RL, and sim-to-real dexterity.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Simulation-heavy, task-specific, and dependent on demonstrations and reward design.
- **Resumption context:** The durable takeaway is: Introduces DAPG, combining demonstrations with policy-gradient fine-tuning for dexterous hands. Continue by comparing its assumptions and evidence with the next lineage stage.

### 7. P089 — What Matters in Learning from Offline Human Demonstrations for Robot Manipulation

- **Central question / objective:** Systematically studies demonstration quality, observation modalities, algorithms, and datasets in robomimic.
- **Stage / role:** Paper lineage — Critical; Modern Core
- **Status:** Required core
- **Prerequisites:** Session 6; L1; supervised learning.
- **Papers:** [P089 — What Matters in Learning from Offline Human Demonstrations for Robot Manipulation](https://arxiv.org/abs/2108.03298)
- **Supporting materials:** R001, R004
- **Concepts covered:** Systematically studies demonstration quality, observation modalities, algorithms, and datasets in robomimic. Preparation profile: Critical; Modern Core · Intermediate · High; focus controlled factors and benchmark design
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in imitation learning and inverse reinforcement learning.
- **Relationship in sequence:** Builds on paper session 6; leads to the topic reconstruction/comparison session. Master lineage note: Provides empirical correction to architecture-only narratives.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Limited task/platform diversity relative to current generalist datasets.
- **Resumption context:** The durable takeaway is: Systematically studies demonstration quality, observation modalities, algorithms, and datasets in robomimic. Continue by comparing its assumptions and evidence with the next lineage stage.

### 8. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Trace the lineage from BC failure to interactive imitation, inverse RL, adversarial occupancy matching, and demonstration-guided optimization.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–7
- **Papers:** [P084 — A Reduction of Imitation Learning and Structured Prediction to No-Regret Online Learning](https://proceedings.mlr.press/v15/ross11a.html), [P085 — Maximum Entropy Inverse Reinforcement Learning](https://www.aaai.org/Papers/AAAI/2008/AAAI08-227.pdf), [P086 — Generative Adversarial Imitation Learning](https://arxiv.org/abs/1606.03476), [P087 — Learning Robust Rewards with Adversarial Inverse Reinforcement Learning](https://arxiv.org/abs/1710.11248), [P088 — Learning Complex Dexterous Manipulation with Deep Reinforcement Learning and Demonstrations](https://arxiv.org/abs/1709.10087), [P089 — What Matters in Learning from Offline Human Demonstrations for Robot Manipulation](https://arxiv.org/abs/2108.03298)
- **Supporting materials:** R001, R004, R018
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 9. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Compare BC and DAgger in a sequential task, then audit GAIL/AIRL or demonstration-guided RL on a controlled benchmark.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–8; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R001, R004, R018
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Compare BC and DAgger in a sequential task, then audit GAIL/AIRL or demonstration-guided RL on a controlled benchmark.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 10. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–9; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R001, R004, R018
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 11. Topic synthesis and original research directions

- **Central question / objective:** When should a robot copy actions, infer rewards, match occupancies, request corrections, or improve through interaction?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–10
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R001, R004, R018
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: L4, L6, D1, E2, S1–S2, S8.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | L1; supervised learning. |
| Closely related / cross-area | Precedes L4, L6, D1, and most robot-policy work. |
| Outgoing capability | L4, L6, D1, E2, S1–S2, S8 |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P084, P085, P086, P087, P088, P089 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**When should a robot copy actions, infer rewards, match occupancies, request corrections, or improve through interaction?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to L4, L6, D1, E2, S1–S2, S8 is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 6 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** No change to topic boundary or primary-paper inventory is proposed.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
