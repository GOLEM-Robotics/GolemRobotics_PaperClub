# F5 — Foundation-model training, post-training, and adaptation: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** A. Shared foundations  
**Execution status:** **Shared Core**

## 1. Topic scope and target depth

### Covers

Scaling laws, data–compute tradeoffs, instruction tuning, preference optimization, parameter-efficient adaptation, quantization, and multimodal alignment.

### Excludes

It does not attempt frontier-scale pretraining; it targets reconstructable small-model experiments and systems understanding.

### Target competence

Understand and reproduce the complete lifecycle of a small language/multimodal model: data, scaling, architecture, training, instruction tuning, preference optimization, PEFT, quantization, and evaluation.

### Place in the wider curriculum

Complete model lifecycle at a level relevant to embodied systems. Direct prerequisite for E1–E3 and D4; useful for P1.

## 2. Execution status and completion boundary

- **Topic execution status:** Shared Core
- **Planned sessions:** 13
- **Classification:** 13 required core · 0 advanced continuation · 0 optional specialization · 0 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 13, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 13

## 3. Dependencies and required foundations

- **Master prerequisites:** F2–F4.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Tokenization, data mixtures, compute accounting, scaling laws, supervised fine-tuning, preference data, KL control, low-rank adaptation, quantization error, and multimodal connectors.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R012 — [Dive into Deep Learning](https://d2l.ai/)** (Interactive open textbook): Implementation-oriented prerequisite repair for uneven member backgrounds.
- **R014 — [Stanford CS224n](https://web.stanford.edu/class/cs224n/)** (Lecture notes): Transformer, language-model, and alignment prerequisites.
- **R015 — [Full Stack Deep Learning](https://fullstackdeeplearning.com/)** (Course): Experiment management, deployment, testing, data, and production ML systems.
- **R016 — [Machine Learning Systems](https://mlsysbook.ai/)** (Open textbook): Hardware-aware training and inference support; use current online version.
- **R022 — [The Bitter Lesson](http://www.incompleteideas.net/IncIdeas/BitterLesson.html)** (Research essay): Short framing resource for scale-versus-hand-engineering debates; not a primary scientific result.
- **R027 — [Stanford CS336: Language Modeling from Scratch](https://cs336.stanford.edu/)** (Course, notes, and implementation assignments): End-to-end reconstruction of tokenization, Transformer training, systems optimization, scaling, data preparation, evaluation, and post-training.
- **R033 — [PyTorch Distributed and Distributed Checkpoint Documentation](https://docs.pytorch.org/tutorials/distributed.html)** (Official framework documentation): DDP/FSDP/tensor parallelism, distributed checkpointing, recovery, profiling, and topology-aware training experiments.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: F2–F4.
        │
        ▼
S1 Topic-local foundations: Tokenization, data mixtures, compute accounting, scaling laws, supervised fine-tuning, preference data, KL control, low-rank adaptation, quantization error, and multimodal connectors.
        │
        ▼
Paper lineage: P020 → P021 → P022 → P023 → P024 → P025 → P026 → P027
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► P1, D3–D4, E1–E3
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for foundation-model training, post-training, and adaptation and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** F2–F4.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R012, R014, R015, R016, R022, R027, R033
- **Concepts covered:** Tokenization, data mixtures, compute accounting, scaling laws, supervised fine-tuning, preference data, KL control, low-rank adaptation, quantization error, and multimodal connectors.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Scaling laws, data–compute tradeoffs, instruction tuning, preference optimization, parameter-efficient adaptation, quantization, and multimodal alignment. Next, enter the ordered paper lineage.

### 2. P020 — Scaling Laws for Neural Language Models

- **Central question / objective:** Documents power-law relationships among model size, data, compute, and loss.
- **Stage / role:** Paper lineage — Foundation
- **Status:** Required core
- **Prerequisites:** Session 1; F2–F4.
- **Papers:** [P020 — Scaling Laws for Neural Language Models](https://arxiv.org/abs/2001.08361)
- **Supporting materials:** R012, R014
- **Concepts covered:** Documents power-law relationships among model size, data, compute, and loss. Preparation profile: Foundation · Advanced · Medium–High; focus empirical scaling methodology
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in foundation-model training, post-training, and adaptation.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P021). Master lineage note: Precedes compute-optimal scaling and robot-data scaling studies.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Language-domain results do not transfer mechanically to robot policies.
- **Resumption context:** The durable takeaway is: Documents power-law relationships among model size, data, compute, and loss. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P021 — Training Compute-Optimal Large Language Models

- **Central question / objective:** Shows many large models were undertrained and derives compute-optimal data/model tradeoffs.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 2; F2–F4.
- **Papers:** [P021 — Training Compute-Optimal Large Language Models](https://arxiv.org/abs/2203.15556)
- **Supporting materials:** R012, R014
- **Concepts covered:** Shows many large models were undertrained and derives compute-optimal data/model tradeoffs. Preparation profile: Modern Core · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in foundation-model training, post-training, and adaptation.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P022). Master lineage note: Corrects earlier scaling allocation; informs embodied pretraining design.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Derived from language modeling; data quality and multimodality complicate transfer.
- **Resumption context:** The durable takeaway is: Shows many large models were undertrained and derives compute-optimal data/model tradeoffs. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P022 — Training Language Models to Follow Instructions with Human Feedback

- **Central question / objective:** Establishes a practical supervised-plus-RLHF post-training pipeline.
- **Stage / role:** Paper lineage — Bridge; Modern Core
- **Status:** Required core
- **Prerequisites:** Session 3; F2–F4.
- **Papers:** [P022 — Training Language Models to Follow Instructions with Human Feedback](https://arxiv.org/abs/2203.02155)
- **Supporting materials:** R012, R014
- **Concepts covered:** Establishes a practical supervised-plus-RLHF post-training pipeline. Preparation profile: Bridge; Modern Core · Advanced · High; focus SFT, reward modeling, PPO, evaluation
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in foundation-model training, post-training, and adaptation.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P023). Master lineage note: Precedes preference optimization and embodied reward modeling.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Proprietary data/model; annotator preferences and reward hacking remain concerns.
- **Resumption context:** The durable takeaway is: Establishes a practical supervised-plus-RLHF post-training pipeline. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P023 — LoRA: Low-Rank Adaptation of Large Language Models

- **Central question / objective:** Introduces low-rank parameter updates for efficient model adaptation.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 4; F2–F4.
- **Papers:** [P023 — LoRA: Low-Rank Adaptation of Large Language Models](https://arxiv.org/abs/2106.09685)
- **Supporting materials:** R012, R014
- **Concepts covered:** Introduces low-rank parameter updates for efficient model adaptation. Preparation profile: Modern Core · Intermediate · Low–Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in foundation-model training, post-training, and adaptation.
- **Relationship in sequence:** Builds on paper session 4; leads to the next paper in the master sequence (P024). Master lineage note: Foundation for practical adaptation of VLM/VLA backbones.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Rank/module choices can bottleneck large domain shifts.
- **Resumption context:** The durable takeaway is: Introduces low-rank parameter updates for efficient model adaptation. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. P024 — QLoRA: Efficient Finetuning of Quantized LLMs

- **Central question / objective:** Combines 4-bit quantization with LoRA to reduce fine-tuning memory.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 5; F2–F4.
- **Papers:** [P024 — QLoRA: Efficient Finetuning of Quantized LLMs](https://arxiv.org/abs/2305.14314)
- **Supporting materials:** R012, R014
- **Concepts covered:** Combines 4-bit quantization with LoRA to reduce fine-tuning memory. Preparation profile: Modern Core · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in foundation-model training, post-training, and adaptation.
- **Relationship in sequence:** Builds on paper session 5; leads to the next paper in the master sequence (P025). Master lineage note: Connects PEFT to D4 deployment constraints.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Quality and throughput depend on kernels, quantizer, and hardware; primarily language evidence.
- **Resumption context:** The durable takeaway is: Combines 4-bit quantization with LoRA to reduce fine-tuning memory. Continue by comparing its assumptions and evidence with the next lineage stage.

### 7. P025 — Direct Preference Optimization: Your Language Model is Secretly a Reward Model

- **Central question / objective:** Recasts preference alignment as a direct classification-like objective without explicit reward-model RL.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 6; F2–F4.
- **Papers:** [P025 — Direct Preference Optimization: Your Language Model is Secretly a Reward Model](https://arxiv.org/abs/2305.18290)
- **Supporting materials:** R012, R014
- **Concepts covered:** Recasts preference alignment as a direct classification-like objective without explicit reward-model RL. Preparation profile: Modern Core · Advanced · Medium–High; derive objective from KL-constrained RL
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in foundation-model training, post-training, and adaptation.
- **Relationship in sequence:** Builds on paper session 6; leads to the next paper in the master sequence (P026). Master lineage note: Relevant to preference-based robotics and E3 reward interfaces.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Offline preference datasets can encode bias; not a substitute for closed-loop safety evaluation.
- **Resumption context:** The durable takeaway is: Recasts preference alignment as a direct classification-like objective without explicit reward-model RL. Continue by comparing its assumptions and evidence with the next lineage stage.

### 8. P026 — Flamingo: a Visual Language Model for Few-Shot Learning

- **Central question / objective:** Introduces cross-attention-based multimodal conditioning with frozen vision/language components.
- **Stage / role:** Paper lineage — Bridge
- **Status:** Required core
- **Prerequisites:** Session 7; F2–F4.
- **Papers:** [P026 — Flamingo: a Visual Language Model for Few-Shot Learning](https://arxiv.org/abs/2204.14198)
- **Supporting materials:** R012, R014
- **Concepts covered:** Introduces cross-attention-based multimodal conditioning with frozen vision/language components. Preparation profile: Bridge · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in foundation-model training, post-training, and adaptation.
- **Relationship in sequence:** Builds on paper session 7; leads to the next paper in the master sequence (P027). Master lineage note: Precedes embodied multimodal models and VLA backbones.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Closed model/data and expensive training limit reproduction.
- **Resumption context:** The durable takeaway is: Introduces cross-attention-based multimodal conditioning with frozen vision/language components. Continue by comparing its assumptions and evidence with the next lineage stage.

### 9. P027 — BLIP-2: Bootstrapping Language-Image Pre-training with Frozen Image Encoders and Large Language Models

- **Central question / objective:** Uses a lightweight query transformer to connect frozen vision and language models.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 8; F2–F4.
- **Papers:** [P027 — BLIP-2: Bootstrapping Language-Image Pre-training with Frozen Image Encoders and Large Language Models](https://arxiv.org/abs/2301.12597)
- **Supporting materials:** R012, R014
- **Concepts covered:** Uses a lightweight query transformer to connect frozen vision and language models. Preparation profile: Modern Core · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in foundation-model training, post-training, and adaptation.
- **Relationship in sequence:** Builds on paper session 8; leads to the topic reconstruction/comparison session. Master lineage note: Alternative multimodal adaptation pattern relevant to embodied VLMs.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Image-centric and not designed for real-time control.
- **Resumption context:** The durable takeaway is: Uses a lightweight query transformer to connect frozen vision and language models. Continue by comparing its assumptions and evidence with the next lineage stage.

### 10. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Reconstruct the training and adaptation stack, separating data, objective, architecture, systems, and evaluation effects.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–9
- **Papers:** [P020 — Scaling Laws for Neural Language Models](https://arxiv.org/abs/2001.08361), [P021 — Training Compute-Optimal Large Language Models](https://arxiv.org/abs/2203.15556), [P022 — Training Language Models to Follow Instructions with Human Feedback](https://arxiv.org/abs/2203.02155), [P023 — LoRA: Low-Rank Adaptation of Large Language Models](https://arxiv.org/abs/2106.09685), [P024 — QLoRA: Efficient Finetuning of Quantized LLMs](https://arxiv.org/abs/2305.14314), [P025 — Direct Preference Optimization: Your Language Model is Secretly a Reward Model](https://arxiv.org/abs/2305.18290), [P026 — Flamingo: a Visual Language Model for Few-Shot Learning](https://arxiv.org/abs/2204.14198), [P027 — BLIP-2: Bootstrapping Language-Image Pre-training with Frozen Image Encoders and Large Language Models](https://arxiv.org/abs/2301.12597)
- **Supporting materials:** R012, R014, R015, R016, R022, R027, R033
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 11. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Train a small LM or multimodal adapter, fit a limited scaling curve, then compare full fine-tuning, LoRA/QLoRA, and preference tuning under fixed resources.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–10; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R012, R014, R015, R016, R022, R027, R033
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Train a small LM or multimodal adapter, fit a limited scaling curve, then compare full fine-tuning, LoRA/QLoRA, and preference tuning under fixed resources.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 12. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–11; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R012, R014, R015, R016, R022, R027, R033
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 13. Topic synthesis and original research directions

- **Central question / objective:** Which foundation-model competencies are genuinely necessary to investigate embodied systems rather than merely consume APIs?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–12
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R012, R014, R015, R016, R022, R027, R033
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: P1, D3–D4, E1–E3.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | F2–F4. |
| Closely related / cross-area | Direct prerequisite for E1–E3 and D4; useful for P1. |
| Outgoing capability | P1, D3–D4, E1–E3 |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P020, P021, P022, P023, P024, P025, P026, P027 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**Which foundation-model competencies are genuinely necessary to investigate embodied systems rather than merely consume APIs?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to P1, D3–D4, E1–E3 is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 8 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** Propose adding the following supporting resources to the master supporting-material index: R027, R033. They fill implementation/reconstruction gaps without changing the paper sequence.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
