# S1 — Manipulation, grasping, contact, and bimanual control: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** F. Specialization branches  
**Execution status:** **Specialization**

## 1. Topic scope and target depth

### Covers

Grasp synthesis, spatial action structure, contact-rich insertion, semantic manipulation, bimanual coordination, and mobile manipulation.

### Excludes

It excludes tactile-specialized methods (S2) and generic VLA scaling unless directly relevant to manipulation mechanics.

### Target competence

Integrate grasping, spatial action representations, contact-rich execution, semantic manipulation, bimanual coordination, and mobile manipulation on a concrete platform.

### Place in the wider curriculum

Executable when tied to a robot platform. Primary manipulation specialization.

## 2. Execution status and completion boundary

- **Topic execution status:** Specialization
- **Planned sessions:** 10
- **Classification:** 8 required core · 1 advanced continuation · 1 optional specialization · 0 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 10, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 10

## 3. Dependencies and required foundations

- **Master prerequisites:** F6–F8, P2–P3, L3, L6.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Grasp geometry and stability, SE(3) actions, contact/friction, insertion tolerances, visual servoing, bimanual constraints, demonstrations, and task success metrics.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R005 — [Modern Robotics: Mechanics, Planning, and Control](https://modernrobotics.northwestern.edu/)** (Open textbook/course): Kinematics, dynamics, Jacobians, control, and planning prerequisites.
- **R018 — [robomimic Documentation](https://robomimic.github.io/)** (Documentation and benchmark recipes): Reference implementation for demonstration learning and benchmark audits.
- **R019 — [ManiSkill Documentation](https://maniskill.readthedocs.io/)** (Simulation/benchmark documentation): High-throughput manipulation experiments and standardized evaluation.
- **R020 — [MuJoCo Documentation](https://mujoco.readthedocs.io/)** (Physics simulator documentation): Reliable dynamics/control simulation reference.
- **R028 — [MIT Robotic Manipulation: Perception, Planning, and Control](https://manipulation.csail.mit.edu/)** (Open course notes and exercises): Integrated manipulation stack connecting geometry, perception, planning, contact, control, and learning.
- **R034 — [Drake Documentation and Tutorials](https://drake.mit.edu/tutorials/)** (Model-based robotics framework and tutorials): Multibody dynamics, contact, mathematical programming, automatic differentiation, systems diagrams, and model-based verification.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: F6–F8, P2–P3, L3, L6.
        │
        ▼
S1 Topic-local foundations: Grasp geometry and stability, SE(3) actions, contact/friction, insertion tolerances, visual servoing, bimanual constraints, demonstrations, and task success metrics.
        │
        ▼
Paper lineage: P163 → P164 → P165 → P166 → P167
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► S2 and platform-specific E2/D1 work
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for manipulation, grasping, contact, and bimanual control and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** F6–F8, P2–P3, L3, L6.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R005, R018, R019, R020, R028, R034
- **Concepts covered:** Grasp geometry and stability, SE(3) actions, contact/friction, insertion tolerances, visual servoing, bimanual constraints, demonstrations, and task success metrics.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Grasp synthesis, spatial action structure, contact-rich insertion, semantic manipulation, bimanual coordination, and mobile manipulation. Next, enter the ordered paper lineage.

### 2. P163 — Dex-Net 2.0: Deep Learning to Plan Robust Grasps with Synthetic Point Clouds and Analytic Grasp Metrics

- **Central question / objective:** Combines analytic grasp metrics, synthetic depth data, and deep grasp scoring.
- **Stage / role:** Paper lineage — Foundation; Modern Core
- **Status:** Required core
- **Prerequisites:** Session 1; F6–F8, P2–P3, L3, L6.
- **Papers:** [P163 — Dex-Net 2.0: Deep Learning to Plan Robust Grasps with Synthetic Point Clouds and Analytic Grasp Metrics](https://arxiv.org/abs/1703.09312)
- **Supporting materials:** R005, R018
- **Concepts covered:** Combines analytic grasp metrics, synthetic depth data, and deep grasp scoring. Preparation profile: Foundation; Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in manipulation, grasping, contact, and bimanual control.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P164). Master lineage note: Foundation for data-driven parallel-jaw grasp planning.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Relies on simplified gripper/contact models and object assumptions.
- **Resumption context:** The durable takeaway is: Combines analytic grasp metrics, synthetic depth data, and deep grasp scoring. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P164 — Transporter Networks: Rearranging the Visual World for Robotic Manipulation

- **Central question / objective:** Models pick-and-place as spatial feature transport with strong translational equivariance.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 2; F6–F8, P2–P3, L3, L6.
- **Papers:** [P164 — Transporter Networks: Rearranging the Visual World for Robotic Manipulation](https://arxiv.org/abs/2010.14406)
- **Supporting materials:** R005, R018
- **Concepts covered:** Models pick-and-place as spatial feature transport with strong translational equivariance. Preparation profile: Modern Core · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in manipulation, grasping, contact, and bimanual control.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P165). Master lineage note: Precursor to CLIPort and structured visuomotor policies.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Best suited to top-down planar manipulation and discrete pick/place actions.
- **Resumption context:** The durable takeaway is: Models pick-and-place as spatial feature transport with strong translational equivariance. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P165 — CLIPort: What and Where Pathways for Robotic Manipulation

- **Central question / objective:** Combines CLIP semantic features with Transporter spatial features for language-conditioned manipulation.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 3; F6–F8, P2–P3, L3, L6.
- **Papers:** [P165 — CLIPort: What and Where Pathways for Robotic Manipulation](https://arxiv.org/abs/2109.12098)
- **Supporting materials:** R005, R018
- **Concepts covered:** Combines CLIP semantic features with Transporter spatial features for language-conditioned manipulation. Preparation profile: Modern Core · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in manipulation, grasping, contact, and bimanual control.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P166). Master lineage note: Bridges P1 representations, E1 language, and structured manipulation.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Primarily planar simulated tasks; inherited CLIP grounding limitations.
- **Resumption context:** The durable takeaway is: Combines CLIP semantic features with Transporter spatial features for language-conditioned manipulation. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P166 — Perceiver-Actor: A Multi-Task Transformer for Robotic Manipulation

- **Central question / objective:** Uses voxelized 3D observations and a Perceiver policy for language-conditioned 6-DoF actions.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Advanced continuation
- **Prerequisites:** Session 4; F6–F8, P2–P3, L3, L6.
- **Papers:** [P166 — Perceiver-Actor: A Multi-Task Transformer for Robotic Manipulation](https://arxiv.org/abs/2209.05451)
- **Supporting materials:** R005, R018
- **Concepts covered:** Uses voxelized 3D observations and a Perceiver policy for language-conditioned 6-DoF actions. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in manipulation, grasping, contact, and bimanual control.
- **Relationship in sequence:** Builds on paper session 4; leads to the next paper in the master sequence (P167). Master lineage note: Develops CLIPort toward 3D multi-task manipulation.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Voxel resolution and compute cost; simulation-centric evidence.
- **Resumption context:** The durable takeaway is: Uses voxelized 3D observations and a Perceiver policy for language-conditioned 6-DoF actions. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. P167 — Learning to Manipulate Deformable Objects without Demonstrations

- **Central question / objective:** Uses a structured conditional pick–place action space and visual RL to learn cloth and rope manipulation without demonstrations, including sim-to-real transfer.
- **Stage / role:** Paper lineage — Optional Specialization; Critical
- **Status:** Optional specialization
- **Prerequisites:** Session 5; F6–F8, P2–P3, L3, L6.
- **Papers:** [P167 — Learning to Manipulate Deformable Objects without Demonstrations](https://arxiv.org/abs/1910.13439)
- **Supporting materials:** R005, R018
- **Concepts covered:** Uses a structured conditional pick–place action space and visual RL to learn cloth and rope manipulation without demonstrations, including sim-to-real transfer. Preparation profile: Optional Specialization; Critical · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in manipulation, grasping, contact, and bimanual control.
- **Relationship in sequence:** Builds on paper session 5; leads to the topic reconstruction/comparison session. Master lineage note: Early demonstration-free deformable manipulation; bridge from S1 to S5.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Narrow action structure and tasks; learned picking baselines were not uniformly superior, making the failure analysis important.
- **Resumption context:** The durable takeaway is: Uses a structured conditional pick–place action space and visual RL to learn cloth and rope manipulation without demonstrations, including sim-to-real transfer. Continue by comparing its assumptions and evidence with the next lineage stage.

### 7. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Connect Dex-Net, Transporter Networks, CLIPort, PerAct, and Mobile ALOHA as successive representations of manipulation action and data.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–6
- **Papers:** [P163 — Dex-Net 2.0: Deep Learning to Plan Robust Grasps with Synthetic Point Clouds and Analytic Grasp Metrics](https://arxiv.org/abs/1703.09312), [P164 — Transporter Networks: Rearranging the Visual World for Robotic Manipulation](https://arxiv.org/abs/2010.14406), [P165 — CLIPort: What and Where Pathways for Robotic Manipulation](https://arxiv.org/abs/2109.12098), [P166 — Perceiver-Actor: A Multi-Task Transformer for Robotic Manipulation](https://arxiv.org/abs/2209.05451), [P167 — Learning to Manipulate Deformable Objects without Demonstrations](https://arxiv.org/abs/1910.13439)
- **Supporting materials:** R005, R018, R019, R020, R028, R034
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 8. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Implement/reproduce one grasping or language-conditioned manipulation baseline and one contact/bimanual task; evaluate geometry, semantics, precision, and failure recovery.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–7; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R005, R018, R019, R020, R028, R034
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Implement/reproduce one grasping or language-conditioned manipulation baseline and one contact/bimanual task; evaluate geometry, semantics, precision, and failure recovery.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 9. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–8; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R005, R018, R019, R020, R028, R034
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 10. Topic synthesis and original research directions

- **Central question / objective:** How should manipulation systems combine semantic intent, geometric precision, contact feedback, and coordinated control?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–9
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R005, R018, R019, R020, R028, R034
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: S2 and platform-specific E2/D1 work.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | F6–F8, P2–P3, L3, L6. |
| Closely related / cross-area | Primary manipulation specialization. |
| Outgoing capability | S2 and platform-specific E2/D1 work |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P163, P164, P165, P166, P167 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**How should manipulation systems combine semantic intent, geometric precision, contact feedback, and coordinated control?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to S2 and platform-specific E2/D1 work is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 5 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** Propose adding the following supporting resources to the master supporting-material index: R028, R034. They fill implementation/reconstruction gaps without changing the paper sequence.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
