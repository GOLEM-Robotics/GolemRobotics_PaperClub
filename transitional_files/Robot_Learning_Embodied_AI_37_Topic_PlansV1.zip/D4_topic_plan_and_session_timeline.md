# D4 — Efficient deployment, latency, compression, and real-time policy execution: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** D. Data, evaluation, and research systems  
**Execution status:** **Active Research Track**

## 1. Topic scope and target depth

### Covers

Action frequency, asynchronous inference, action chunking, token compression, PEFT, quantization, distillation, edge deployment, and closed-loop latency.

### Excludes

It excludes generic cloud serving and focuses on closed-loop robot inference where latency and timing affect behavior.

### Target competence

Measure and optimize end-to-end policy latency, jitter, throughput, memory, precision, action buffering, and control-loop stability without hiding accuracy regressions.

### Place in the wider curriculum

Deployment track. Links model design to physical control constraints.

## 2. Execution status and completion boundary

- **Topic execution status:** Active Research Track
- **Planned sessions:** 9
- **Classification:** 8 required core · 0 advanced continuation · 1 optional specialization · 0 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 9, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 9

## 3. Dependencies and required foundations

- **Master prerequisites:** F5, L6, E2.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Latency decomposition, deadlines/jitter, asynchronous pipelines, batching tradeoffs, quantization, distillation, kernel/graph optimization, action chunking, and feedback-loop effects.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R015 — [Full Stack Deep Learning](https://fullstackdeeplearning.com/)** (Course): Experiment management, deployment, testing, data, and production ML systems.
- **R016 — [Machine Learning Systems](https://mlsysbook.ai/)** (Open textbook): Hardware-aware training and inference support; use current online version.
- **R017 — [LeRobot Documentation](https://huggingface.co/docs/lerobot/)** (Documentation and open framework): Dataset schema, teleoperation, policy training, evaluation, and low-cost hardware integration.
- **R027 — [Stanford CS336: Language Modeling from Scratch](https://cs336.stanford.edu/)** (Course, notes, and implementation assignments): End-to-end reconstruction of tokenization, Transformer training, systems optimization, scaling, data preparation, evaluation, and post-training.
- **R030 — [ROS 2 Real-Time Programming Documentation](https://docs.ros.org/en/kilted/Tutorials/Demos/Real-Time-Programming.html)** (Official systems documentation): Deadline, jitter, memory-allocation, scheduling, and execution-path constraints for physical robot deployment.
- **R031 — [NVIDIA TensorRT Documentation](https://docs.nvidia.com/deeplearning/tensorrt/latest/)** (Official inference/deployment documentation): Profiling, graph optimization, precision selection, dynamic shapes, engine construction, and latency/accuracy validation.
- **R033 — [PyTorch Distributed and Distributed Checkpoint Documentation](https://docs.pytorch.org/tutorials/distributed.html)** (Official framework documentation): DDP/FSDP/tensor parallelism, distributed checkpointing, recovery, profiling, and topology-aware training experiments.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: F5, L6, E2.
        │
        ▼
S1 Topic-local foundations: Latency decomposition, deadlines/jitter, asynchronous pipelines, batching tradeoffs, quantization, distillation, kernel/graph optimization, action chunking, and feedback-loop effects.
        │
        ▼
Paper lineage: P135 → P136 → P137 → P138
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► E2, S1, S3 and real-robot deployment
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for efficient deployment, latency, compression, and real-time policy execution and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** F5, L6, E2.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R015, R016, R017, R027, R030, R031, R033
- **Concepts covered:** Latency decomposition, deadlines/jitter, asynchronous pipelines, batching tradeoffs, quantization, distillation, kernel/graph optimization, action chunking, and feedback-loop effects.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Action frequency, asynchronous inference, action chunking, token compression, PEFT, quantization, distillation, edge deployment, and closed-loop latency. Next, enter the ordered paper lineage.

### 2. P135 — OpenVLA-OFT: Fine-Tuning Vision-Language-Action Models via Optimized Actions and Fast Inference

- **Central question / objective:** Improves OpenVLA fine-tuning and action generation for stronger, faster control.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 1; F5, L6, E2.
- **Papers:** [P135 — OpenVLA-OFT: Fine-Tuning Vision-Language-Action Models via Optimized Actions and Fast Inference](https://arxiv.org/abs/2502.19645)
- **Supporting materials:** R015, R016
- **Concepts covered:** Improves OpenVLA fine-tuning and action generation for stronger, faster control. Preparation profile: Modern Core · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in efficient deployment, latency, compression, and real-time policy execution.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P136). Master lineage note: Direct continuation of OpenVLA and bridge to deployable open VLAs.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Results remain benchmark/platform dependent and inherit backbone cost.
- **Resumption context:** The durable takeaway is: Improves OpenVLA fine-tuning and action generation for stronger, faster control. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P136 — Real-Time Action Chunking with Large Models

- **Central question / objective:** Decouples slow model inference from fast control through asynchronous chunk prediction and execution.
- **Stage / role:** Paper lineage — Modern Core; Systems
- **Status:** Required core
- **Prerequisites:** Session 2; F5, L6, E2.
- **Papers:** [P136 — Real-Time Action Chunking with Large Models](https://www.pi.website/research/real_time_chunking)
- **Supporting materials:** R015, R016
- **Concepts covered:** Decouples slow model inference from fast control through asynchronous chunk prediction and execution. Preparation profile: Modern Core; Systems · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in efficient deployment, latency, compression, and real-time policy execution.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P137). Master lineage note: Extends ACT/action chunking to high-latency large VLAs.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Closed-system evidence and synchronization assumptions need independent reproduction.
- **Resumption context:** The durable takeaway is: Decouples slow model inference from fast control through asynchronous chunk prediction and execution. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P137 — SmolVLA: A Vision-Language-Action Model for Affordable and Efficient Robotics

- **Central question / objective:** Presents a compact open VLA with public data, consumer-hardware training, and asynchronous inference.
- **Stage / role:** Paper lineage — Modern Core; Reproduction Candidate
- **Status:** Required core
- **Prerequisites:** Session 3; F5, L6, E2.
- **Papers:** [P137 — SmolVLA: A Vision-Language-Action Model for Affordable and Efficient Robotics](https://arxiv.org/abs/2506.01844)
- **Supporting materials:** R015, R016
- **Concepts covered:** Presents a compact open VLA with public data, consumer-hardware training, and asynchronous inference. Preparation profile: Modern Core; Reproduction Candidate · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in efficient deployment, latency, compression, and real-time policy execution.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P138). Master lineage note: Open, low-cost counterpart to larger generalist policies; integrates with LeRobot.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Results are narrower than large proprietary models and depend on benchmark/robot-specific fine-tuning.
- **Resumption context:** The durable takeaway is: Presents a compact open VLA with public data, consumer-hardware training, and asynchronous inference. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P138 — Efficient Memory Management for Large Language Model Serving with PagedAttention

- **Central question / objective:** Introduces PagedAttention and vLLM for high-throughput memory-efficient autoregressive serving.
- **Stage / role:** Paper lineage — Optional Specialization
- **Status:** Optional specialization
- **Prerequisites:** Session 4; F5, L6, E2.
- **Papers:** [P138 — Efficient Memory Management for Large Language Model Serving with PagedAttention](https://arxiv.org/abs/2309.06180)
- **Supporting materials:** R015, R016
- **Concepts covered:** Introduces PagedAttention and vLLM for high-throughput memory-efficient autoregressive serving. Preparation profile: Optional Specialization · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in efficient deployment, latency, compression, and real-time policy execution.
- **Relationship in sequence:** Builds on paper session 4; leads to the topic reconstruction/comparison session. Master lineage note: Useful for embodied planners/VLMs and shared inference infrastructure.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Robot control adds latency determinism and multimodal preprocessing not addressed here.
- **Resumption context:** The durable takeaway is: Introduces PagedAttention and vLLM for high-throughput memory-efficient autoregressive serving. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Connect model compression and efficient action representation to real-time control architecture and deployment hardware.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–5
- **Papers:** [P135 — OpenVLA-OFT: Fine-Tuning Vision-Language-Action Models via Optimized Actions and Fast Inference](https://arxiv.org/abs/2502.19645), [P136 — Real-Time Action Chunking with Large Models](https://www.pi.website/research/real_time_chunking), [P137 — SmolVLA: A Vision-Language-Action Model for Affordable and Efficient Robotics](https://arxiv.org/abs/2506.01844), [P138 — Efficient Memory Management for Large Language Model Serving with PagedAttention](https://arxiv.org/abs/2309.06180)
- **Supporting materials:** R015, R016, R017, R027, R030, R031, R033
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 7. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Profile a representative policy end to end; compare eager/compiled/TensorRT and precision variants; inject delay/jitter and measure task-level degradation.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–6; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R015, R016, R017, R027, R030, R031, R033
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Profile a representative policy end to end; compare eager/compiled/TensorRT and precision variants; inject delay/jitter and measure task-level degradation.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 8. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–7; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R015, R016, R017, R027, R030, R031, R033
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 9. Topic synthesis and original research directions

- **Central question / objective:** What deployment envelope preserves policy capability and closed-loop stability on the target robot?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–8
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R015, R016, R017, R027, R030, R031, R033
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: E2, S1, S3 and real-robot deployment.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | F5, L6, E2. |
| Closely related / cross-area | Links model design to physical control constraints. |
| Outgoing capability | E2, S1, S3 and real-robot deployment |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P135, P136, P137, P138 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**What deployment envelope preserves policy capability and closed-loop stability on the target robot?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to E2, S1, S3 and real-robot deployment is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 4 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** Propose adding the following supporting resources to the master supporting-material index: R027, R030, R031, R033. They fill implementation/reconstruction gaps without changing the paper sequence.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
