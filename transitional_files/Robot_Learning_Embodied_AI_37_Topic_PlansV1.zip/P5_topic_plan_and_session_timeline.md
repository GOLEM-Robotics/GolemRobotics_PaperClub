# P5 — Learned dynamics, model-based RL, and world models: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** B. Perception, spatial intelligence, and world models  
**Execution status:** **Active Research Track**

## 1. Topic scope and target depth

### Covers

Probabilistic dynamics, latent state-space models, imagined rollouts, value-equivalent models, and planning in learned models.

### Excludes

It excludes passive video representation learning and proprietary world-action claims not yet supported by mature evidence.

### Target competence

Derive probabilistic and latent dynamics models, understand planning/imagination/value-equivalence, diagnose model bias, and evaluate modern world-model control systems.

### Place in the wider curriculum

Primary world-model lineage. Connects control, prediction, data engines, and frontier world-action models.

## 2. Execution status and completion boundary

- **Topic execution status:** Active Research Track
- **Planned sessions:** 11
- **Classification:** 8 required core · 3 advanced continuation · 0 optional specialization · 0 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 11, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 11

## 3. Dependencies and required foundations

- **Master prerequisites:** F4, F7, L1–L2.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Dynamics uncertainty, compounding error, latent state-space models, variational objectives, model-predictive control, imagination, value-equivalent modeling, and planning horizons.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R004 — [CS285: Deep Reinforcement Learning](https://rail.eecs.berkeley.edu/deeprlcourse/)** (Lecture notes and videos): Modern bridge from theory to model-free, model-based, imitation, and offline RL.
- **R006 — [Underactuated Robotics](https://underactuated.csail.mit.edu/)** (Open textbook/lecture notes): Nonlinear dynamics, optimal control, planning, and learning for physical systems.
- **R026 — [A Survey on Model-Based Reinforcement Learning](https://arxiv.org/abs/2006.16712)** (Survey): Taxonomy of learned models, planning, uncertainty, and policy learning.
- **R034 — [Drake Documentation and Tutorials](https://drake.mit.edu/tutorials/)** (Model-based robotics framework and tutorials): Multibody dynamics, contact, mathematical programming, automatic differentiation, systems diagrams, and model-based verification.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: F4, F7, L1–L2.
        │
        ▼
S1 Topic-local foundations: Dynamics uncertainty, compounding error, latent state-space models, variational objectives, model-predictive control, imagination, value-equivalent modeling, and planning horizons.
        │
        ▼
Paper lineage: P066 → P067 → P068 → P069 → P070 → P071
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► D5, E3, S5, S7
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for learned dynamics, model-based rl, and world models and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** F4, F7, L1–L2.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R004, R006, R026, R034
- **Concepts covered:** Dynamics uncertainty, compounding error, latent state-space models, variational objectives, model-predictive control, imagination, value-equivalent modeling, and planning horizons.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Probabilistic dynamics, latent state-space models, imagined rollouts, value-equivalent models, and planning in learned models. Next, enter the ordered paper lineage.

### 2. P066 — PILCO: A Model-Based and Data-Efficient Approach to Policy Search

- **Central question / objective:** Uses Gaussian-process dynamics and analytic uncertainty propagation for data-efficient control.
- **Stage / role:** Paper lineage — Foundation; Seminal
- **Status:** Required core
- **Prerequisites:** Session 1; F4, F7, L1–L2.
- **Papers:** [P066 — PILCO: A Model-Based and Data-Efficient Approach to Policy Search](https://proceedings.mlr.press/v15/deisenroth11a.html)
- **Supporting materials:** R004, R006
- **Concepts covered:** Uses Gaussian-process dynamics and analytic uncertainty propagation for data-efficient control. Preparation profile: Foundation; Seminal · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in learned dynamics, model-based rl, and world models.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P067). Master lineage note: Foundational uncertainty-aware model-based policy search.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Scales poorly with state/data dimension and relies on smooth low-dimensional dynamics.
- **Resumption context:** The durable takeaway is: Uses Gaussian-process dynamics and analytic uncertainty propagation for data-efficient control. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P067 — Deep Reinforcement Learning in a Handful of Trials using Probabilistic Dynamics Models

- **Central question / objective:** Introduces PETS: probabilistic ensembles plus trajectory sampling for uncertainty-aware planning.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 2; F4, F7, L1–L2.
- **Papers:** [P067 — Deep Reinforcement Learning in a Handful of Trials using Probabilistic Dynamics Models](https://arxiv.org/abs/1805.12114)
- **Supporting materials:** R004, R006
- **Concepts covered:** Introduces PETS: probabilistic ensembles plus trajectory sampling for uncertainty-aware planning. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in learned dynamics, model-based rl, and world models.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P068). Master lineage note: Scalable neural successor to PILCO; precursor to modern ensemble MBRL.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Short-horizon benchmark focus and expensive online planning.
- **Resumption context:** The durable takeaway is: Introduces PETS: probabilistic ensembles plus trajectory sampling for uncertainty-aware planning. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P068 — Learning Latent Dynamics for Planning from Pixels

- **Central question / objective:** Introduces PlaNet, a recurrent latent state-space model used for planning from images.
- **Stage / role:** Paper lineage — Bridge; Modern Core
- **Status:** Required core
- **Prerequisites:** Session 3; F4, F7, L1–L2.
- **Papers:** [P068 — Learning Latent Dynamics for Planning from Pixels](https://proceedings.mlr.press/v97/hafner19a.html)
- **Supporting materials:** R004, R006
- **Concepts covered:** Introduces PlaNet, a recurrent latent state-space model used for planning from images. Preparation profile: Bridge; Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in learned dynamics, model-based rl, and world models.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P069). Master lineage note: Precursor to Dreamer and latent imagination methods.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Planning quality depends on latent model and reward prediction; limited long-horizon uncertainty.
- **Resumption context:** The durable takeaway is: Introduces PlaNet, a recurrent latent state-space model used for planning from images. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P069 — Mastering Atari, Go, Chess and Shogi by Planning with a Learned Model

- **Central question / objective:** Introduces MuZero, learning reward/value/policy-relevant dynamics without reconstructing observations.
- **Stage / role:** Paper lineage — Bridge
- **Status:** Advanced continuation
- **Prerequisites:** Session 4; F4, F7, L1–L2.
- **Papers:** [P069 — Mastering Atari, Go, Chess and Shogi by Planning with a Learned Model](https://www.nature.com/articles/s41586-020-03051-4)
- **Supporting materials:** R004, R006
- **Concepts covered:** Introduces MuZero, learning reward/value/policy-relevant dynamics without reconstructing observations. Preparation profile: Bridge · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in learned dynamics, model-based rl, and world models.
- **Relationship in sequence:** Builds on paper session 4; leads to the next paper in the master sequence (P070). Master lineage note: Value-equivalent alternative to generative world models.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Large compute, discrete domains, and proprietary implementation limit robotics transfer.
- **Resumption context:** The durable takeaway is: Introduces MuZero, learning reward/value/policy-relevant dynamics without reconstructing observations. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. P070 — Mastering Diverse Domains through World Models

- **Central question / objective:** Presents a robust latent world-model actor–critic recipe across diverse domains with one configuration.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Advanced continuation
- **Prerequisites:** Session 5; F4, F7, L1–L2.
- **Papers:** [P070 — Mastering Diverse Domains through World Models](https://arxiv.org/abs/2301.04104)
- **Supporting materials:** R004, R006
- **Concepts covered:** Presents a robust latent world-model actor–critic recipe across diverse domains with one configuration. Preparation profile: Modern Core · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in learned dynamics, model-based rl, and world models.
- **Relationship in sequence:** Builds on paper session 5; leads to the next paper in the master sequence (P071). Master lineage note: Extends PlaNet/Dreamer lineage; strong baseline for imagined rollouts.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Mostly simulated benchmarks; real-robot and model-bias questions remain.
- **Resumption context:** The durable takeaway is: Presents a robust latent world-model actor–critic recipe across diverse domains with one configuration. Continue by comparing its assumptions and evidence with the next lineage stage.

### 7. P071 — TD-MPC2: Scalable, Robust World Models for Continuous Control

- **Central question / objective:** Combines latent dynamics, value learning, and local trajectory optimization for multi-task control.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Advanced continuation
- **Prerequisites:** Session 6; F4, F7, L1–L2.
- **Papers:** [P071 — TD-MPC2: Scalable, Robust World Models for Continuous Control](https://arxiv.org/abs/2310.16828)
- **Supporting materials:** R004, R006
- **Concepts covered:** Combines latent dynamics, value learning, and local trajectory optimization for multi-task control. Preparation profile: Modern Core · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in learned dynamics, model-based rl, and world models.
- **Relationship in sequence:** Builds on paper session 6; leads to the topic reconstruction/comparison session. Master lineage note: Modern model-based alternative to Dreamer-style policy learning.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Primarily simulated control; planning cost and representation choices matter.
- **Resumption context:** The durable takeaway is: Combines latent dynamics, value learning, and local trajectory optimization for multi-task control. Continue by comparing its assumptions and evidence with the next lineage stage.

### 8. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Reconstruct PILCO, PETS, PlaNet/Dreamer, MuZero, and TD-MPC2 as distinct answers to model representation and policy/planning integration.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–7
- **Papers:** [P066 — PILCO: A Model-Based and Data-Efficient Approach to Policy Search](https://proceedings.mlr.press/v15/deisenroth11a.html), [P067 — Deep Reinforcement Learning in a Handful of Trials using Probabilistic Dynamics Models](https://arxiv.org/abs/1805.12114), [P068 — Learning Latent Dynamics for Planning from Pixels](https://proceedings.mlr.press/v97/hafner19a.html), [P069 — Mastering Atari, Go, Chess and Shogi by Planning with a Learned Model](https://www.nature.com/articles/s41586-020-03051-4), [P070 — Mastering Diverse Domains through World Models](https://arxiv.org/abs/2301.04104), [P071 — TD-MPC2: Scalable, Robust World Models for Continuous Control](https://arxiv.org/abs/2310.16828)
- **Supporting materials:** R004, R006, R026, R034
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 9. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Implement or reproduce a compact model-based controller; vary ensemble uncertainty, rollout horizon, representation, and planning budget.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–8; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R004, R006, R026, R034
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Implement or reproduce a compact model-based controller; vary ensemble uncertainty, rollout horizon, representation, and planning budget.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 10. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–9; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R004, R006, R026, R034
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 11. Topic synthesis and original research directions

- **Central question / objective:** What must a learned world model predict to support reliable physical decisions?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–10
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R004, R006, R026, R034
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: D5, E3, S5, S7.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | F4, F7, L1–L2. |
| Closely related / cross-area | Connects control, prediction, data engines, and frontier world-action models. |
| Outgoing capability | D5, E3, S5, S7 |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P066, P067, P068, P069, P070, P071 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**What must a learned world model predict to support reliable physical decisions?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to D5, E3, S5, S7 is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 6 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** Propose adding the following supporting resources to the master supporting-material index: R034. They fill implementation/reconstruction gaps without changing the paper sequence.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
