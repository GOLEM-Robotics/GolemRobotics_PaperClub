# F8 — State estimation, sensor fusion, and SLAM: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** A. Shared foundations  
**Execution status:** **Shared Core**

## 1. Topic scope and target depth

### Covers

Bayesian filtering, smoothing, factor graphs, visual–inertial odometry, mapping, observability, and uncertainty.

### Excludes

It excludes a complete computer-vision course and application-specific SLAM engineering beyond representative systems.

### Target competence

Formulate state estimation as probabilistic inference; derive filtering, smoothing, factor-graph, preintegration, and observability concepts; audit visual–inertial SLAM evidence.

### Place in the wider curriculum

Physical-state grounding and uncertainty foundation. Supports P3–P5, S3–S4, and real-world evaluation.

## 2. Execution status and completion boundary

- **Topic execution status:** Shared Core
- **Planned sessions:** 10
- **Classification:** 10 required core · 0 advanced continuation · 0 optional specialization · 0 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 10, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 10

## 3. Dependencies and required foundations

- **Master prerequisites:** Probability, linear algebra, F6.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Bayes rule, Gaussian propagation, linearization, manifolds, observability, filtering versus smoothing, factors, sparsity, and sensor timing/calibration.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R008 — [Probabilistic Robotics](https://mitpress.mit.edu/9780262201629/probabilistic-robotics/)** (Textbook): Bayesian filtering, localization, mapping, and SLAM foundation.
- **R009 — [Factor Graphs for Robot Perception](https://www.cs.cmu.edu/~kaess/pub/Dellaert17fnt.pdf)** (Monograph): Best structured entry point to factor graphs, smoothing, and sparse inference.
- **R010 — [GTSAM Documentation and Tutorials](https://gtsam.org/)** (Documentation/tutorials): Implementation support for factor graphs, preintegration, and SLAM reproductions.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: Probability, linear algebra, F6.
        │
        ▼
S1 Topic-local foundations: Bayes rule, Gaussian propagation, linearization, manifolds, observability, filtering versus smoothing, factors, sparsity, and sensor timing/calibration.
        │
        ▼
Paper lineage: P038 → P039 → P040 → P041 → P042
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► P3, P5, D1, L7, S3–S4
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for state estimation, sensor fusion, and slam and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** Probability, linear algebra, F6.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R008, R009, R010
- **Concepts covered:** Bayes rule, Gaussian propagation, linearization, manifolds, observability, filtering versus smoothing, factors, sparsity, and sensor timing/calibration.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Bayesian filtering, smoothing, factor graphs, visual–inertial odometry, mapping, observability, and uncertainty. Next, enter the ordered paper lineage.

### 2. P038 — A New Approach to Linear Filtering and Prediction Problems

- **Central question / objective:** Introduces recursive optimal state estimation for linear Gaussian systems.
- **Stage / role:** Paper lineage — Foundation; Seminal
- **Status:** Required core
- **Prerequisites:** Session 1; Probability, linear algebra, F6.
- **Papers:** [P038 — A New Approach to Linear Filtering and Prediction Problems](https://doi.org/10.1115/1.3662552)
- **Supporting materials:** R008, R009
- **Concepts covered:** Introduces recursive optimal state estimation for linear Gaussian systems. Preparation profile: Foundation; Seminal · Advanced · High; full derivation
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in state estimation, sensor fusion, and slam.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P039). Master lineage note: Foundation for EKF/VIO and model-based filtering.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Linear-Gaussian assumptions; consistency under nonlinearization is nontrivial.
- **Resumption context:** The durable takeaway is: Introduces recursive optimal state estimation for linear Gaussian systems. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P039 — iSAM2: Incremental Smoothing and Mapping Using the Bayes Tree

- **Central question / objective:** Introduces efficient incremental nonlinear smoothing using the Bayes tree.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 2; Probability, linear algebra, F6.
- **Papers:** [P039 — iSAM2: Incremental Smoothing and Mapping Using the Bayes Tree](https://doi.org/10.1177/0278364911430419)
- **Supporting materials:** R008, R009
- **Concepts covered:** Introduces efficient incremental nonlinear smoothing using the Bayes tree. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in state estimation, sensor fusion, and slam.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P040). Master lineage note: Connects factor graphs to real-time SLAM.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Requires careful factor modeling, linearization, and robustification.
- **Resumption context:** The durable takeaway is: Introduces efficient incremental nonlinear smoothing using the Bayes tree. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P040 — On-Manifold Preintegration for Real-Time Visual–Inertial Odometry

- **Central question / objective:** Develops IMU preintegration on manifolds for factor-graph estimation.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 3; Probability, linear algebra, F6.
- **Papers:** [P040 — On-Manifold Preintegration for Real-Time Visual–Inertial Odometry](https://arxiv.org/abs/1512.02363)
- **Supporting materials:** R008, R009
- **Concepts covered:** Develops IMU preintegration on manifolds for factor-graph estimation. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in state estimation, sensor fusion, and slam.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P041). Master lineage note: Prerequisite for modern VIO and many state-estimation stacks.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Bias/noise assumptions and calibration dominate practice.
- **Resumption context:** The durable takeaway is: Develops IMU preintegration on manifolds for factor-graph estimation. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P041 — VINS-Mono: A Robust and Versatile Monocular Visual–Inertial State Estimator

- **Central question / objective:** Presents a tightly coupled sliding-window monocular VIO system with initialization and loop closure.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 4; Probability, linear algebra, F6.
- **Papers:** [P041 — VINS-Mono: A Robust and Versatile Monocular Visual–Inertial State Estimator](https://arxiv.org/abs/1708.03852)
- **Supporting materials:** R008, R009
- **Concepts covered:** Presents a tightly coupled sliding-window monocular VIO system with initialization and loop closure. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in state estimation, sensor fusion, and slam.
- **Relationship in sequence:** Builds on paper session 4; leads to the next paper in the master sequence (P042). Master lineage note: Applies preintegration and nonlinear optimization in a full system.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Monocular scale/degeneracy and calibration sensitivity remain important.
- **Resumption context:** The durable takeaway is: Presents a tightly coupled sliding-window monocular VIO system with initialization and loop closure. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. P042 — ORB-SLAM3: An Accurate Open-Source Library for Visual, Visual–Inertial, and Multi-Map SLAM

- **Central question / objective:** Unifies monocular, stereo, RGB-D, and visual–inertial SLAM with atlas-based map reuse.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 5; Probability, linear algebra, F6.
- **Papers:** [P042 — ORB-SLAM3: An Accurate Open-Source Library for Visual, Visual–Inertial, and Multi-Map SLAM](https://arxiv.org/abs/2007.11898)
- **Supporting materials:** R008, R009
- **Concepts covered:** Unifies monocular, stereo, RGB-D, and visual–inertial SLAM with atlas-based map reuse. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in state estimation, sensor fusion, and slam.
- **Relationship in sequence:** Builds on paper session 5; leads to the topic reconstruction/comparison session. Master lineage note: Mature feature-based SLAM lineage after ORB-SLAM.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Texture, dynamics, calibration, and compute conditions affect robustness.
- **Resumption context:** The durable takeaway is: Unifies monocular, stereo, RGB-D, and visual–inertial SLAM with atlas-based map reuse. Continue by comparing its assumptions and evidence with the next lineage stage.

### 7. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Derive Kalman updates, factor-graph objectives, and IMU preintegration assumptions, then connect them to VINS/ORB-SLAM3 systems.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–6
- **Papers:** [P038 — A New Approach to Linear Filtering and Prediction Problems](https://doi.org/10.1115/1.3662552), [P039 — iSAM2: Incremental Smoothing and Mapping Using the Bayes Tree](https://doi.org/10.1177/0278364911430419), [P040 — On-Manifold Preintegration for Real-Time Visual–Inertial Odometry](https://arxiv.org/abs/1512.02363), [P041 — VINS-Mono: A Robust and Versatile Monocular Visual–Inertial State Estimator](https://arxiv.org/abs/1708.03852), [P042 — ORB-SLAM3: An Accurate Open-Source Library for Visual, Visual–Inertial, and Multi-Map SLAM](https://arxiv.org/abs/2007.11898)
- **Supporting materials:** R008, R009, R010
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 8. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Build a small factor-graph or visual–inertial pipeline; inject timestamp, calibration, bias, and dropout errors and analyze consistency.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–7; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R008, R009, R010
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Build a small factor-graph or visual–inertial pipeline; inject timestamp, calibration, bias, and dropout errors and analyze consistency.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 9. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–8; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R008, R009, R010
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 10. Topic synthesis and original research directions

- **Central question / objective:** How do state-estimation uncertainty and failure propagate into learned perception, planning, and control?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–9
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R008, R009, R010
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: P3, P5, D1, L7, S3–S4.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | Probability, linear algebra, F6. |
| Closely related / cross-area | Supports P3–P5, S3–S4, and real-world evaluation. |
| Outgoing capability | P3, P5, D1, L7, S3–S4 |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P038, P039, P040, P041, P042 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**How do state-estimation uncertainty and failure propagate into learned perception, planning, and control?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to P3, P5, D1, L7, S3–S4 is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 5 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** No change to topic boundary or primary-paper inventory is proposed.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
