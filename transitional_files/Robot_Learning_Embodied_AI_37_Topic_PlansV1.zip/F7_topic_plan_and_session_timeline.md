# F7 — Motion planning, trajectory optimization, and optimal control: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** A. Shared foundations  
**Execution status:** **Shared Core**

## 1. Topic scope and target depth

### Covers

Sampling-based planning, trajectory optimization, model predictive control, task-and-motion planning, and safety filters.

### Excludes

It excludes detailed state estimation and does not treat learned planning as a substitute for classical planning foundations.

### Target competence

Select, derive, and evaluate sampling-based, optimization-based, MPC, and task-and-motion planning methods under geometry, dynamics, uncertainty, and real-time constraints.

### Place in the wider curriculum

Shared planning vocabulary before learned planning. Links classical planning to P5, E1, L6, L8, and S1–S4.

## 2. Execution status and completion boundary

- **Topic execution status:** Shared Core
- **Planned sessions:** 11
- **Classification:** 11 required core · 0 advanced continuation · 0 optional specialization · 0 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 11, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 11

## 3. Dependencies and required foundations

- **Master prerequisites:** F6; optimization.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Configuration spaces, collision checking, feasibility, optimal control, trajectory discretization, convexification, receding horizon, and hybrid task/motion structure.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R005 — [Modern Robotics: Mechanics, Planning, and Control](https://modernrobotics.northwestern.edu/)** (Open textbook/course): Kinematics, dynamics, Jacobians, control, and planning prerequisites.
- **R006 — [Underactuated Robotics](https://underactuated.csail.mit.edu/)** (Open textbook/lecture notes): Nonlinear dynamics, optimal control, planning, and learning for physical systems.
- **R007 — [Planning Algorithms](https://lavalle.pl/planning/)** (Open textbook): Primary conceptual support for PRM/RRT, kinodynamic planning, and planning under uncertainty.
- **R020 — [MuJoCo Documentation](https://mujoco.readthedocs.io/)** (Physics simulator documentation): Reliable dynamics/control simulation reference.
- **R028 — [MIT Robotic Manipulation: Perception, Planning, and Control](https://manipulation.csail.mit.edu/)** (Open course notes and exercises): Integrated manipulation stack connecting geometry, perception, planning, contact, control, and learning.
- **R034 — [Drake Documentation and Tutorials](https://drake.mit.edu/tutorials/)** (Model-based robotics framework and tutorials): Multibody dynamics, contact, mathematical programming, automatic differentiation, systems diagrams, and model-based verification.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: F6; optimization.
        │
        ▼
S1 Topic-local foundations: Configuration spaces, collision checking, feasibility, optimal control, trajectory discretization, convexification, receding horizon, and hybrid task/motion structure.
        │
        ▼
Paper lineage: P032 → P033 → P034 → P035 → P036 → P037
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► P5, L8, E1, S1, S3–S4
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for motion planning, trajectory optimization, and optimal control and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** F6; optimization.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R005, R006, R007, R020, R028, R034
- **Concepts covered:** Configuration spaces, collision checking, feasibility, optimal control, trajectory discretization, convexification, receding horizon, and hybrid task/motion structure.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Sampling-based planning, trajectory optimization, model predictive control, task-and-motion planning, and safety filters. Next, enter the ordered paper lineage.

### 2. P032 — Probabilistic Roadmaps for Path Planning in High-Dimensional Configuration Spaces

- **Central question / objective:** Introduces multi-query sampling-based planning through a reusable roadmap.
- **Stage / role:** Paper lineage — Seminal
- **Status:** Required core
- **Prerequisites:** Session 1; F6; optimization.
- **Papers:** [P032 — Probabilistic Roadmaps for Path Planning in High-Dimensional Configuration Spaces](https://doi.org/10.1109/70.508439)
- **Supporting materials:** R005, R006
- **Concepts covered:** Introduces multi-query sampling-based planning through a reusable roadmap. Preparation profile: Seminal · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in motion planning, trajectory optimization, and optimal control.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P033). Master lineage note: Foundation for motion-planning libraries and later sampling methods.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Static known geometry and collision checking assumptions; no dynamics.
- **Resumption context:** The durable takeaway is: Introduces multi-query sampling-based planning through a reusable roadmap. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P033 — Rapidly-Exploring Random Trees: A New Tool for Path Planning

- **Central question / objective:** Introduces incremental exploration biased toward unvisited regions.
- **Stage / role:** Paper lineage — Seminal
- **Status:** Required core
- **Prerequisites:** Session 2; F6; optimization.
- **Papers:** [P033 — Rapidly-Exploring Random Trees: A New Tool for Path Planning](https://msl.cs.illinois.edu/~lavalle/papers/Lav98c.pdf)
- **Supporting materials:** R005, R006
- **Concepts covered:** Introduces incremental exploration biased toward unvisited regions. Preparation profile: Seminal · Intermediate · Low–Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in motion planning, trajectory optimization, and optimal control.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P034). Master lineage note: Foundation for single-query and kinodynamic planning variants.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Basic RRT is not asymptotically optimal and may produce poor paths.
- **Resumption context:** The durable takeaway is: Introduces incremental exploration biased toward unvisited regions. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P034 — CHOMP: Gradient Optimization Techniques for Efficient Motion Planning

- **Central question / objective:** Optimizes trajectories with smoothness and obstacle costs in functional space.
- **Stage / role:** Paper lineage — Bridge
- **Status:** Required core
- **Prerequisites:** Session 3; F6; optimization.
- **Papers:** [P034 — CHOMP: Gradient Optimization Techniques for Efficient Motion Planning](https://doi.org/10.1109/ROBOT.2009.5152817)
- **Supporting materials:** R005, R006
- **Concepts covered:** Optimizes trajectories with smoothness and obstacle costs in functional space. Preparation profile: Bridge · Advanced · Medium–High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in motion planning, trajectory optimization, and optimal control.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P035). Master lineage note: Connects sampling-based planning to differentiable trajectory optimization.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Local minima and cost-field quality matter; dynamics/contact are limited.
- **Resumption context:** The durable takeaway is: Optimizes trajectories with smoothness and obstacle costs in functional space. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P035 — Motion Planning with Sequential Convex Optimization and Convex Collision Checking

- **Central question / objective:** Introduces TrajOpt using sequential convex optimization and continuous-time collision checking.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 4; F6; optimization.
- **Papers:** [P035 — Motion Planning with Sequential Convex Optimization and Convex Collision Checking](https://arxiv.org/abs/1311.5605)
- **Supporting materials:** R005, R006
- **Concepts covered:** Introduces TrajOpt using sequential convex optimization and continuous-time collision checking. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in motion planning, trajectory optimization, and optimal control.
- **Relationship in sequence:** Builds on paper session 4; leads to the next paper in the master sequence (P036). Master lineage note: Builds on trajectory optimization; used widely in manipulation.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Local optimization requires good initialization and accurate collision geometry.
- **Resumption context:** The durable takeaway is: Introduces TrajOpt using sequential convex optimization and continuous-time collision checking. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. P036 — Hierarchical Task and Motion Planning in the Now

- **Central question / objective:** Integrates symbolic task planning with geometric feasibility through interleaved refinement.
- **Stage / role:** Paper lineage — Bridge
- **Status:** Required core
- **Prerequisites:** Session 5; F6; optimization.
- **Papers:** [P036 — Hierarchical Task and Motion Planning in the Now](https://doi.org/10.1109/ICRA.2011.5980391)
- **Supporting materials:** R005, R006
- **Concepts covered:** Integrates symbolic task planning with geometric feasibility through interleaved refinement. Preparation profile: Bridge · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in motion planning, trajectory optimization, and optimal control.
- **Relationship in sequence:** Builds on paper session 5; leads to the next paper in the master sequence (P037). Master lineage note: Direct precursor to language-guided task-and-motion planning.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Scalability and model specification remain difficult; limited learning.
- **Resumption context:** The durable takeaway is: Integrates symbolic task planning with geometric feasibility through interleaved refinement. Continue by comparing its assumptions and evidence with the next lineage stage.

### 7. P037 — Information-Theoretic Model Predictive Control: Theory and Applications to Autonomous Driving

- **Central question / objective:** Derives sampling-based MPC updates from information-theoretic control.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 6; F6; optimization.
- **Papers:** [P037 — Information-Theoretic Model Predictive Control: Theory and Applications to Autonomous Driving](https://arxiv.org/abs/1707.02342)
- **Supporting materials:** R005, R006
- **Concepts covered:** Derives sampling-based MPC updates from information-theoretic control. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in motion planning, trajectory optimization, and optimal control.
- **Relationship in sequence:** Builds on paper session 6; leads to the topic reconstruction/comparison session. Master lineage note: Links optimal control to GPU-parallel stochastic planning and learned models.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Compute and model fidelity constrain real-time performance.
- **Resumption context:** The durable takeaway is: Derives sampling-based MPC updates from information-theoretic control. Continue by comparing its assumptions and evidence with the next lineage stage.

### 8. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Compare PRM/RRT, CHOMP/TrajOpt, TAMP, and information-theoretic MPC by representation, solver, guarantees, and failure modes.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–7
- **Papers:** [P032 — Probabilistic Roadmaps for Path Planning in High-Dimensional Configuration Spaces](https://doi.org/10.1109/70.508439), [P033 — Rapidly-Exploring Random Trees: A New Tool for Path Planning](https://msl.cs.illinois.edu/~lavalle/papers/Lav98c.pdf), [P034 — CHOMP: Gradient Optimization Techniques for Efficient Motion Planning](https://doi.org/10.1109/ROBOT.2009.5152817), [P035 — Motion Planning with Sequential Convex Optimization and Convex Collision Checking](https://arxiv.org/abs/1311.5605), [P036 — Hierarchical Task and Motion Planning in the Now](https://doi.org/10.1109/ICRA.2011.5980391), [P037 — Information-Theoretic Model Predictive Control: Theory and Applications to Autonomous Driving](https://arxiv.org/abs/1707.02342)
- **Supporting materials:** R005, R006, R007, R020, R028, R034
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 9. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Solve one manipulation/navigation problem with sampling, trajectory optimization, and MPC variants; measure success, compute, constraint violations, and robustness.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–8; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R005, R006, R007, R020, R028, R034
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Solve one manipulation/navigation problem with sampling, trajectory optimization, and MPC variants; measure success, compute, constraint violations, and robustness.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 10. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–9; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R005, R006, R007, R020, R028, R034
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 11. Topic synthesis and original research directions

- **Central question / objective:** How should a robot allocate reasoning between discrete task plans, geometric paths, trajectory optimization, MPC, and learned policies?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–10
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R005, R006, R007, R020, R028, R034
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: P5, L8, E1, S1, S3–S4.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | F6; optimization. |
| Closely related / cross-area | Links classical planning to P5, E1, L6, L8, and S1–S4. |
| Outgoing capability | P5, L8, E1, S1, S3–S4 |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P032, P033, P034, P035, P036, P037 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**How should a robot allocate reasoning between discrete task plans, geometric paths, trajectory optimization, MPC, and learned policies?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to P5, L8, E1, S1, S3–S4 is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 6 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** Propose adding the following supporting resources to the master supporting-material index: R028, R034. They fill implementation/reconstruction gaps without changing the paper sequence.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
