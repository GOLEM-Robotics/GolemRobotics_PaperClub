# L2 — Deep model-free continuous control: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** C. Learning to act  
**Execution status:** **Shared Core**

## 1. Topic scope and target depth

### Covers

Trust regions, generalized advantage estimation, deterministic and stochastic actor–critic methods, replay, entropy, and sparse-reward goal learning.

### Excludes

It excludes offline-only learning, imitation, and model-based methods except as comparisons.

### Target competence

Implement and critically compare PPO/TRPO, DDPG/TD3, SAC, and HER for continuous control, including objective derivations, implementation sensitivities, exploration, and data efficiency.

### Place in the wider curriculum

Durable algorithmic core. Baseline family for physical control and comparison with imitation/VLA methods.

## 2. Execution status and completion boundary

- **Topic execution status:** Shared Core
- **Planned sessions:** 12
- **Classification:** 12 required core · 0 advanced continuation · 0 optional specialization · 0 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 12, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 12

## 3. Dependencies and required foundations

- **Master prerequisites:** L1, F2.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Actor–critic decomposition, likelihood ratios, advantage estimation, trust regions, replay, target networks, deterministic gradients, entropy regularization, and goal relabeling.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R001 — [Reinforcement Learning: An Introduction, 2nd ed.](http://incompleteideas.net/book/the-book-2nd.html)** (Textbook): Primary mathematical entry point; use selected chapters before original TD/Q/policy-gradient papers.
- **R003 — [OpenAI Spinning Up in Deep RL](https://spinningup.openai.com/)** (Course notes and reference implementations): Practical derivations and baseline implementations for policy-gradient and actor–critic methods.
- **R004 — [CS285: Deep Reinforcement Learning](https://rail.eecs.berkeley.edu/deeprlcourse/)** (Lecture notes and videos): Modern bridge from theory to model-free, model-based, imitation, and offline RL.
- **R029 — [CleanRL Documentation and Reference Implementations](https://docs.cleanrl.dev/)** (Research-oriented single-file implementations): Code-level reconstruction, implementation-difference audits, seeded baselines, and reproducibility checks.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: L1, F2.
        │
        ▼
S1 Topic-local foundations: Actor–critic decomposition, likelihood ratios, advantage estimation, trust regions, replay, target networks, deterministic gradients, entropy regularization, and goal relabeling.
        │
        ▼
Paper lineage: P077 → P078 → P079 → P080 → P081 → P082 → P083
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► P5, L5, L7–L8, S3
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for deep model-free continuous control and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** L1, F2.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R001, R003, R004, R029
- **Concepts covered:** Actor–critic decomposition, likelihood ratios, advantage estimation, trust regions, replay, target networks, deterministic gradients, entropy regularization, and goal relabeling.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Trust regions, generalized advantage estimation, deterministic and stochastic actor–critic methods, replay, entropy, and sparse-reward goal learning. Next, enter the ordered paper lineage.

### 2. P077 — Trust Region Policy Optimization

- **Central question / objective:** Derives constrained policy updates motivated by monotonic improvement.
- **Stage / role:** Paper lineage — Foundation; Modern Core
- **Status:** Required core
- **Prerequisites:** Session 1; L1, F2.
- **Papers:** [P077 — Trust Region Policy Optimization](https://proceedings.mlr.press/v37/schulman15.html)
- **Supporting materials:** R001, R003
- **Concepts covered:** Derives constrained policy updates motivated by monotonic improvement. Preparation profile: Foundation; Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in deep model-free continuous control.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P078). Master lineage note: Foundation for GAE/PPO and stable on-policy optimization.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Second-order approximation and implementation complexity; guarantees are local/idealized.
- **Resumption context:** The durable takeaway is: Derives constrained policy updates motivated by monotonic improvement. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P078 — High-Dimensional Continuous Control Using Generalized Advantage Estimation

- **Central question / objective:** Introduces GAE to trade bias against variance in policy-gradient estimates.
- **Stage / role:** Paper lineage — Bridge
- **Status:** Required core
- **Prerequisites:** Session 2; L1, F2.
- **Papers:** [P078 — High-Dimensional Continuous Control Using Generalized Advantage Estimation](https://arxiv.org/abs/1506.02438)
- **Supporting materials:** R001, R003
- **Concepts covered:** Introduces GAE to trade bias against variance in policy-gradient estimates. Preparation profile: Bridge · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in deep model-free continuous control.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P079). Master lineage note: Directly supports TRPO/PPO implementations.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Depends on value-function quality and trajectory truncation choices.
- **Resumption context:** The durable takeaway is: Introduces GAE to trade bias against variance in policy-gradient estimates. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P079 — Proximal Policy Optimization Algorithms

- **Central question / objective:** Introduces clipped and KL-penalized surrogate objectives for simpler stable on-policy updates.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 3; L1, F2.
- **Papers:** [P079 — Proximal Policy Optimization Algorithms](https://arxiv.org/abs/1707.06347)
- **Supporting materials:** R001, R003
- **Concepts covered:** Introduces clipped and KL-penalized surrogate objectives for simpler stable on-policy updates. Preparation profile: Modern Core · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in deep model-free continuous control.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P080). Master lineage note: Practical successor to TRPO; common robotics baseline.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Sensitive to implementation, normalization, batch reuse, and tuning; no strict trust-region guarantee.
- **Resumption context:** The durable takeaway is: Introduces clipped and KL-penalized surrogate objectives for simpler stable on-policy updates. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P080 — Continuous Control with Deep Reinforcement Learning

- **Central question / objective:** Introduces DDPG, combining deterministic policy gradients with replay and target networks.
- **Stage / role:** Paper lineage — Bridge
- **Status:** Required core
- **Prerequisites:** Session 4; L1, F2.
- **Papers:** [P080 — Continuous Control with Deep Reinforcement Learning](https://arxiv.org/abs/1509.02971)
- **Supporting materials:** R001, R003
- **Concepts covered:** Introduces DDPG, combining deterministic policy gradients with replay and target networks. Preparation profile: Bridge · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in deep model-free continuous control.
- **Relationship in sequence:** Builds on paper session 4; leads to the next paper in the master sequence (P081). Master lineage note: Precursor to TD3 and off-policy continuous-control methods.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Known instability, overestimation, and exploration weaknesses.
- **Resumption context:** The durable takeaway is: Introduces DDPG, combining deterministic policy gradients with replay and target networks. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. P081 — Addressing Function Approximation Error in Actor-Critic Methods

- **Central question / objective:** Introduces TD3 with twin critics, delayed policy updates, and target smoothing.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 5; L1, F2.
- **Papers:** [P081 — Addressing Function Approximation Error in Actor-Critic Methods](https://proceedings.mlr.press/v80/fujimoto18a.html)
- **Supporting materials:** R001, R003
- **Concepts covered:** Introduces TD3 with twin critics, delayed policy updates, and target smoothing. Preparation profile: Modern Core · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in deep model-free continuous control.
- **Relationship in sequence:** Builds on paper session 5; leads to the next paper in the master sequence (P082). Master lineage note: Direct correction of DDPG failure modes.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Deterministic exploration and tuning remain challenging.
- **Resumption context:** The durable takeaway is: Introduces TD3 with twin critics, delayed policy updates, and target smoothing. Continue by comparing its assumptions and evidence with the next lineage stage.

### 7. P082 — Soft Actor-Critic: Off-Policy Maximum Entropy Deep Reinforcement Learning with a Stochastic Actor

- **Central question / objective:** Introduces maximum-entropy stochastic actor–critic learning for robust exploration and off-policy control.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 6; L1, F2.
- **Papers:** [P082 — Soft Actor-Critic: Off-Policy Maximum Entropy Deep Reinforcement Learning with a Stochastic Actor](https://proceedings.mlr.press/v80/haarnoja18b.html)
- **Supporting materials:** R001, R003
- **Concepts covered:** Introduces maximum-entropy stochastic actor–critic learning for robust exploration and off-policy control. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in deep model-free continuous control.
- **Relationship in sequence:** Builds on paper session 6; leads to the next paper in the master sequence (P083). Master lineage note: Alternative to TD3; widely used in robot learning.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Temperature, replay distribution, and reward scaling affect behavior; real-robot sample cost remains high.
- **Resumption context:** The durable takeaway is: Introduces maximum-entropy stochastic actor–critic learning for robust exploration and off-policy control. Continue by comparing its assumptions and evidence with the next lineage stage.

### 8. P083 — Hindsight Experience Replay

- **Central question / objective:** Relabels failed trajectories with achieved goals to learn under sparse rewards.
- **Stage / role:** Paper lineage — Bridge
- **Status:** Required core
- **Prerequisites:** Session 7; L1, F2.
- **Papers:** [P083 — Hindsight Experience Replay](https://arxiv.org/abs/1707.01495)
- **Supporting materials:** R001, R003
- **Concepts covered:** Relabels failed trajectories with achieved goals to learn under sparse rewards. Preparation profile: Bridge · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in deep model-free continuous control.
- **Relationship in sequence:** Builds on paper session 7; leads to the topic reconstruction/comparison session. Master lineage note: Bridge from goal-conditioned RL to data reuse.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Requires meaningful goal representation and relabeling semantics.
- **Resumption context:** The durable takeaway is: Relabels failed trajectories with achieved goals to learn under sparse rewards. Continue by comparing its assumptions and evidence with the next lineage stage.

### 9. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Build a unified objective/update comparison for on-policy and off-policy continuous-control algorithms.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–8
- **Papers:** [P077 — Trust Region Policy Optimization](https://proceedings.mlr.press/v37/schulman15.html), [P078 — High-Dimensional Continuous Control Using Generalized Advantage Estimation](https://arxiv.org/abs/1506.02438), [P079 — Proximal Policy Optimization Algorithms](https://arxiv.org/abs/1707.06347), [P080 — Continuous Control with Deep Reinforcement Learning](https://arxiv.org/abs/1509.02971), [P081 — Addressing Function Approximation Error in Actor-Critic Methods](https://proceedings.mlr.press/v80/fujimoto18a.html), [P082 — Soft Actor-Critic: Off-Policy Maximum Entropy Deep Reinforcement Learning with a Stochastic Actor](https://proceedings.mlr.press/v80/haarnoja18b.html), [P083 — Hindsight Experience Replay](https://arxiv.org/abs/1707.01495)
- **Supporting materials:** R001, R003, R004, R029
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 10. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Run matched-budget PPO, TD3, and SAC experiments with controlled implementations, seeds, normalization, and evaluation; add HER on a sparse goal task.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–9; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R001, R003, R004, R029
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Run matched-budget PPO, TD3, and SAC experiments with controlled implementations, seeds, normalization, and evaluation; add HER on a sparse goal task.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 11. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–10; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R001, R003, R004, R029
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 12. Topic synthesis and original research directions

- **Central question / objective:** Which continuous-control baseline is appropriate for simulation, limited real-robot data, sparse rewards, and safety constraints?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–11
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R001, R003, R004, R029
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: P5, L5, L7–L8, S3.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | L1, F2. |
| Closely related / cross-area | Baseline family for physical control and comparison with imitation/VLA methods. |
| Outgoing capability | P5, L5, L7–L8, S3 |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P077, P078, P079, P080, P081, P082, P083 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**Which continuous-control baseline is appropriate for simulation, limited real-robot data, sparse rewards, and safety constraints?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to P5, L5, L7–L8, S3 is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 7 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** Propose adding the following supporting resources to the master supporting-material index: R029. They fill implementation/reconstruction gaps without changing the paper sequence.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
