# L5 — Goal-conditioned, hierarchical, meta-, and skill learning: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** C. Learning to act  
**Execution status:** **Specialization**

## 1. Topic scope and target depth

### Covers

Temporal abstraction, universal value functions, unsupervised skills, hierarchical control, meta-learning, and task inference.

### Excludes

It excludes generic long-horizon planning and language planners unless they rely directly on learned skills or task inference.

### Target competence

Understand temporal abstraction, goal conditioning, unsupervised skill discovery, hierarchy, and meta-RL; identify when abstractions improve exploration, transfer, or long-horizon control.

### Place in the wider curriculum

Specialized abstraction and transfer branch. Supports long-horizon planning, transfer, and E3.

## 2. Execution status and completion boundary

- **Topic execution status:** Specialization
- **Planned sessions:** 11
- **Classification:** 8 required core · 3 advanced continuation · 0 optional specialization · 0 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 11, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 11

## 3. Dependencies and required foundations

- **Master prerequisites:** L1–L2.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Semi-MDPs, options, termination, universal value functions, mutual-information skill objectives, subgoals, off-policy hierarchy, meta-learning, and latent task inference.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R001 — [Reinforcement Learning: An Introduction, 2nd ed.](http://incompleteideas.net/book/the-book-2nd.html)** (Textbook): Primary mathematical entry point; use selected chapters before original TD/Q/policy-gradient papers.
- **R004 — [CS285: Deep Reinforcement Learning](https://rail.eecs.berkeley.edu/deeprlcourse/)** (Lecture notes and videos): Modern bridge from theory to model-free, model-based, imitation, and offline RL.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: L1–L2.
        │
        ▼
S1 Topic-local foundations: Semi-MDPs, options, termination, universal value functions, mutual-information skill objectives, subgoals, off-policy hierarchy, meta-learning, and latent task inference.
        │
        ▼
Paper lineage: P096 → P097 → P098 → P099 → P100 → P101
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► E3 and long-horizon skill/planning systems
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for goal-conditioned, hierarchical, meta-, and skill learning and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** L1–L2.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R001, R004
- **Concepts covered:** Semi-MDPs, options, termination, universal value functions, mutual-information skill objectives, subgoals, off-policy hierarchy, meta-learning, and latent task inference.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Temporal abstraction, universal value functions, unsupervised skills, hierarchical control, meta-learning, and task inference. Next, enter the ordered paper lineage.

### 2. P096 — Between MDPs and Semi-MDPs: A Framework for Temporal Abstraction in Reinforcement Learning

- **Central question / objective:** Introduces the options framework for temporally extended actions.
- **Stage / role:** Paper lineage — Seminal
- **Status:** Required core
- **Prerequisites:** Session 1; L1–L2.
- **Papers:** [P096 — Between MDPs and Semi-MDPs: A Framework for Temporal Abstraction in Reinforcement Learning](https://doi.org/10.1016/S0004-3702(99)00052-1)
- **Supporting materials:** R001, R004
- **Concepts covered:** Introduces the options framework for temporally extended actions. Preparation profile: Seminal · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in goal-conditioned, hierarchical, meta-, and skill learning.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P097). Master lineage note: Foundation for hierarchical RL and skill composition.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Learning useful options and termination remains difficult.
- **Resumption context:** The durable takeaway is: Introduces the options framework for temporally extended actions. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P097 — Universal Value Function Approximators

- **Central question / objective:** Conditions value functions on goals to enable transfer across tasks.
- **Stage / role:** Paper lineage — Bridge
- **Status:** Required core
- **Prerequisites:** Session 2; L1–L2.
- **Papers:** [P097 — Universal Value Function Approximators](https://proceedings.mlr.press/v37/schaul15.html)
- **Supporting materials:** R001, R004
- **Concepts covered:** Conditions value functions on goals to enable transfer across tasks. Preparation profile: Bridge · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in goal-conditioned, hierarchical, meta-, and skill learning.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P098). Master lineage note: Foundation for goal-conditioned RL and HER.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Goal representation and sampling determine generalization.
- **Resumption context:** The durable takeaway is: Conditions value functions on goals to enable transfer across tasks. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P098 — Diversity Is All You Need: Learning Skills without a Reward Function

- **Central question / objective:** Introduces DIAYN, discovering diverse skills by maximizing mutual information.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 3; L1–L2.
- **Papers:** [P098 — Diversity Is All You Need: Learning Skills without a Reward Function](https://arxiv.org/abs/1802.06070)
- **Supporting materials:** R001, R004
- **Concepts covered:** Introduces DIAYN, discovering diverse skills by maximizing mutual information. Preparation profile: Modern Core · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in goal-conditioned, hierarchical, meta-, and skill learning.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P099). Master lineage note: Key unsupervised skill-learning lineage.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Diversity does not guarantee task usefulness or physical safety.
- **Resumption context:** The durable takeaway is: Introduces DIAYN, discovering diverse skills by maximizing mutual information. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P099 — Data-Efficient Hierarchical Reinforcement Learning

- **Central question / objective:** Introduces HIRO with off-policy correction for hierarchical continuous control.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Advanced continuation
- **Prerequisites:** Session 4; L1–L2.
- **Papers:** [P099 — Data-Efficient Hierarchical Reinforcement Learning](https://arxiv.org/abs/1805.08296)
- **Supporting materials:** R001, R004
- **Concepts covered:** Introduces HIRO with off-policy correction for hierarchical continuous control. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in goal-conditioned, hierarchical, meta-, and skill learning.
- **Relationship in sequence:** Builds on paper session 4; leads to the next paper in the master sequence (P100). Master lineage note: Practical development of options-like temporal abstraction.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Subgoal representation and non-stationarity remain difficult.
- **Resumption context:** The durable takeaway is: Introduces HIRO with off-policy correction for hierarchical continuous control. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. P100 — Model-Agnostic Meta-Learning for Fast Adaptation of Deep Networks

- **Central question / objective:** Learns initial parameters optimized for rapid adaptation.
- **Stage / role:** Paper lineage — Bridge
- **Status:** Advanced continuation
- **Prerequisites:** Session 5; L1–L2.
- **Papers:** [P100 — Model-Agnostic Meta-Learning for Fast Adaptation of Deep Networks](https://proceedings.mlr.press/v70/finn17a.html)
- **Supporting materials:** R001, R004
- **Concepts covered:** Learns initial parameters optimized for rapid adaptation. Preparation profile: Bridge · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in goal-conditioned, hierarchical, meta-, and skill learning.
- **Relationship in sequence:** Builds on paper session 5; leads to the next paper in the master sequence (P101). Master lineage note: Foundation for meta-RL and few-shot robot adaptation.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Bi-level optimization is expensive and sensitive to task distribution.
- **Resumption context:** The durable takeaway is: Learns initial parameters optimized for rapid adaptation. Continue by comparing its assumptions and evidence with the next lineage stage.

### 7. P101 — Efficient Off-Policy Meta-Reinforcement Learning via Probabilistic Context Variables

- **Central question / objective:** Introduces PEARL, inferring latent task context from experience for off-policy meta-RL.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Advanced continuation
- **Prerequisites:** Session 6; L1–L2.
- **Papers:** [P101 — Efficient Off-Policy Meta-Reinforcement Learning via Probabilistic Context Variables](https://proceedings.mlr.press/v97/rakelly19a.html)
- **Supporting materials:** R001, R004
- **Concepts covered:** Introduces PEARL, inferring latent task context from experience for off-policy meta-RL. Preparation profile: Modern Core · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in goal-conditioned, hierarchical, meta-, and skill learning.
- **Relationship in sequence:** Builds on paper session 6; leads to the topic reconstruction/comparison session. Master lineage note: Develops MAML-style adaptation into probabilistic task inference.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Assumes training/test task-family overlap and can fail under ambiguity.
- **Resumption context:** The durable takeaway is: Introduces PEARL, inferring latent task context from experience for off-policy meta-RL. Continue by comparing its assumptions and evidence with the next lineage stage.

### 8. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Connect options, UVFAs, DIAYN, HIRO, MAML, and PEARL through the representation and adaptation of tasks/skills.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–7
- **Papers:** [P096 — Between MDPs and Semi-MDPs: A Framework for Temporal Abstraction in Reinforcement Learning](https://doi.org/10.1016/S0004-3702(99)00052-1), [P097 — Universal Value Function Approximators](https://proceedings.mlr.press/v37/schaul15.html), [P098 — Diversity Is All You Need: Learning Skills without a Reward Function](https://arxiv.org/abs/1802.06070), [P099 — Data-Efficient Hierarchical Reinforcement Learning](https://arxiv.org/abs/1805.08296), [P100 — Model-Agnostic Meta-Learning for Fast Adaptation of Deep Networks](https://proceedings.mlr.press/v70/finn17a.html), [P101 — Efficient Off-Policy Meta-Reinforcement Learning via Probabilistic Context Variables](https://proceedings.mlr.press/v97/rakelly19a.html)
- **Supporting materials:** R001, R004
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 9. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Implement one goal-conditioned/hierarchical or meta-RL experiment and test skill reuse, adaptation speed, and failure under task shift.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–8; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R001, R004
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Implement one goal-conditioned/hierarchical or meta-RL experiment and test skill reuse, adaptation speed, and failure under task shift.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 10. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–9; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R001, R004
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 11. Topic synthesis and original research directions

- **Central question / objective:** Which abstractions are reusable across tasks and embodiments, and which merely compress one benchmark?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–10
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R001, R004
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: E3 and long-horizon skill/planning systems.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | L1–L2. |
| Closely related / cross-area | Supports long-horizon planning, transfer, and E3. |
| Outgoing capability | E3 and long-horizon skill/planning systems |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P096, P097, P098, P099, P100, P101 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**Which abstractions are reusable across tasks and embodiments, and which merely compress one benchmark?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to E3 and long-horizon skill/planning systems is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 6 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** No change to topic boundary or primary-paper inventory is proposed.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
