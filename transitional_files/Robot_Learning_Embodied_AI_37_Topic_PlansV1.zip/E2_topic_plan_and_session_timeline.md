# E2 — Vision-language-action models and generalist robot policies: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** E. Language, multimodality, and embodied reasoning  
**Execution status:** **Active Research Track**

## 1. Topic scope and target depth

### Covers

Cross-embodiment pretraining, VLM-to-action adaptation, discrete versus continuous actions, action experts, heterogeneous co-training, and policy adaptation.

### Excludes

It excludes company demonstrations without inspectable methods from the durable core and treats E3 agentic/self-improving systems separately.

### Target competence

Reconstruct modern generalist policy stacks, compare data mixtures and action representations, adapt an open VLA, and critically evaluate claims of cross-task/embodiment generalization.

### Place in the wider curriculum

Primary generalist-policy track. Major synthesis point, not the sole curriculum organizer.

## 2. Execution status and completion boundary

- **Topic execution status:** Active Research Track
- **Planned sessions:** 13
- **Classification:** 8 required core · 1 advanced continuation · 0 optional specialization · 4 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 13, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 13

## 3. Dependencies and required foundations

- **Master prerequisites:** P1–P4, L3–L6, D1–D4, E1.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** VLM backbones, robot co-training, embodiment/action normalization, discrete tokens versus continuous experts, cross-attention, flow/diffusion heads, adaptation, and evaluation protocols.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R014 — [Stanford CS224n](https://web.stanford.edu/class/cs224n/)** (Lecture notes): Transformer, language-model, and alignment prerequisites.
- **R017 — [LeRobot Documentation](https://huggingface.co/docs/lerobot/)** (Documentation and open framework): Dataset schema, teleoperation, policy training, evaluation, and low-cost hardware integration.
- **R022 — [The Bitter Lesson](http://www.incompleteideas.net/IncIdeas/BitterLesson.html)** (Research essay): Short framing resource for scale-versus-hand-engineering debates; not a primary scientific result.
- **R023 — [A Survey of Vision-Language-Action Models for Robotics: Towards Real-World Applications](https://arxiv.org/abs/2510.07077)** (Survey): Current full-stack map of VLA architectures, data, hardware, and evaluation; use for navigation, not as a replacement for primary papers.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: P1–P4, L3–L6, D1–D4, E1.
        │
        ▼
S1 Topic-local foundations: VLM backbones, robot co-training, embodiment/action normalization, discrete tokens versus continuous experts, cross-attention, flow/diffusion heads, adaptation, and evaluation protocols.
        │
        ▼
Paper lineage: P150 → P151 → P152 → P153 → P154 → P155 → P156 → P157
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► E3, D4, S1–S4
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for vision-language-action models and generalist robot policies and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** P1–P4, L3–L6, D1–D4, E1.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R014, R017, R022, R023
- **Concepts covered:** VLM backbones, robot co-training, embodiment/action normalization, discrete tokens versus continuous experts, cross-attention, flow/diffusion heads, adaptation, and evaluation protocols.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Cross-embodiment pretraining, VLM-to-action adaptation, discrete versus continuous actions, action experts, heterogeneous co-training, and policy adaptation. Next, enter the ordered paper lineage.

### 2. P150 — RT-2: Vision-Language-Action Models Transfer Web Knowledge to Robotic Control

- **Central question / objective:** Co-trains web-scale vision-language tasks and robot actions represented as tokens.
- **Stage / role:** Paper lineage — Seminal; Bridge
- **Status:** Required core
- **Prerequisites:** Session 1; P1–P4, L3–L6, D1–D4, E1.
- **Papers:** [P150 — RT-2: Vision-Language-Action Models Transfer Web Knowledge to Robotic Control](https://arxiv.org/abs/2307.15818)
- **Supporting materials:** R014, R017
- **Concepts covered:** Co-trains web-scale vision-language tasks and robot actions represented as tokens. Preparation profile: Seminal; Bridge · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in vision-language-action models and generalist robot policies.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P151). Master lineage note: Establishes the modern VLA framing after RT-1.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Closed models/data and limited reproducibility; tokenized actions and evaluation scope require scrutiny.
- **Resumption context:** The durable takeaway is: Co-trains web-scale vision-language tasks and robot actions represented as tokens. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P151 — Octo: An Open-Source Generalist Robot Policy

- **Central question / objective:** Trains an open generalist policy on heterogeneous Open X data with adaptable observation/action heads.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 2; P1–P4, L3–L6, D1–D4, E1.
- **Papers:** [P151 — Octo: An Open-Source Generalist Robot Policy](https://arxiv.org/abs/2405.12213)
- **Supporting materials:** R014, R017
- **Concepts covered:** Trains an open generalist policy on heterogeneous Open X data with adaptable observation/action heads. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in vision-language-action models and generalist robot policies.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P152). Master lineage note: Open alternative to RT-X and precursor to later open VLA stacks.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Smaller scale and weaker semantics than VLM-backed VLAs; benchmark sensitivity.
- **Resumption context:** The durable takeaway is: Trains an open generalist policy on heterogeneous Open X data with adaptable observation/action heads. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P152 — OpenVLA: An Open-Source Vision-Language-Action Model

- **Central question / objective:** Adapts a pretrained VLM into an open 7B action-token policy trained on Open X-Embodiment.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 3; P1–P4, L3–L6, D1–D4, E1.
- **Papers:** [P152 — OpenVLA: An Open-Source Vision-Language-Action Model](https://proceedings.mlr.press/v270/kim25c.html)
- **Supporting materials:** R014, R017
- **Concepts covered:** Adapts a pretrained VLM into an open 7B action-token policy trained on Open X-Embodiment. Preparation profile: Modern Core · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in vision-language-action models and generalist robot policies.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P153). Master lineage note: Major reproducible VLA baseline between RT-2 and newer action-expert models.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Large inference cost, discrete actions, and benchmark-specific fine-tuning; data mixture quality matters.
- **Resumption context:** The durable takeaway is: Adapts a pretrained VLM into an open 7B action-token policy trained on Open X-Embodiment. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P153 — π0: A Vision-Language-Action Flow Model for General Robot Control

- **Central question / objective:** Adds a continuous flow-matching action expert to a pretrained VLM and trains across multiple embodiments and dexterous tasks.
- **Stage / role:** Paper lineage — Modern Core; Frontier Bridge
- **Status:** Frontier continuation
- **Prerequisites:** Session 4; P1–P4, L3–L6, D1–D4, E1.
- **Papers:** [P153 — π0: A Vision-Language-Action Flow Model for General Robot Control](https://www.pi.website/download/pi0.pdf)
- **Supporting materials:** R014, R017
- **Concepts covered:** Adds a continuous flow-matching action expert to a pretrained VLM and trains across multiple embodiments and dexterous tasks. Preparation profile: Modern Core; Frontier Bridge · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in vision-language-action models and generalist robot policies.
- **Relationship in sequence:** Builds on paper session 4; leads to the next paper in the master sequence (P154). Master lineage note: Connects F4 flow matching, L6 chunked actions, and cross-embodiment pretraining.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Most data and full training stack are proprietary; comparisons occur on internal tasks.
- **Resumption context:** The durable takeaway is: Adds a continuous flow-matching action expert to a pretrained VLM and trains across multiple embodiments and dexterous tasks. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. P154 — π0.5: A Vision-Language-Action Model with Open-World Generalization

- **Central question / objective:** Uses heterogeneous co-training and high-level semantic prediction for long-horizon manipulation in unseen homes.
- **Stage / role:** Paper lineage — Modern Core; Frontier
- **Status:** Frontier continuation
- **Prerequisites:** Session 5; P1–P4, L3–L6, D1–D4, E1.
- **Papers:** [P154 — π0.5: A Vision-Language-Action Model with Open-World Generalization](https://proceedings.mlr.press/v305/black25a.html)
- **Supporting materials:** R014, R017
- **Concepts covered:** Uses heterogeneous co-training and high-level semantic prediction for long-horizon manipulation in unseen homes. Preparation profile: Modern Core; Frontier · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in vision-language-action models and generalist robot policies.
- **Relationship in sequence:** Builds on paper session 5; leads to the next paper in the master sequence (P155). Master lineage note: Extends π0 from dexterity toward open-world task generalization.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Private data, internal evaluation, and limited independent reproduction remain major caveats.
- **Resumption context:** The durable takeaway is: Uses heterogeneous co-training and high-level semantic prediction for long-horizon manipulation in unseen homes. Continue by comparing its assumptions and evidence with the next lineage stage.

### 7. P155 — GR00T N1: An Open Foundation Model for Generalist Humanoid Robots

- **Central question / objective:** Combines a vision-language module with a diffusion/flow-style action module for cross-embodiment humanoid control.
- **Stage / role:** Paper lineage — Modern Core; Frontier
- **Status:** Frontier continuation
- **Prerequisites:** Session 6; P1–P4, L3–L6, D1–D4, E1.
- **Papers:** [P155 — GR00T N1: An Open Foundation Model for Generalist Humanoid Robots](https://arxiv.org/abs/2503.14734)
- **Supporting materials:** R014, R017
- **Concepts covered:** Combines a vision-language module with a diffusion/flow-style action module for cross-embodiment humanoid control. Preparation profile: Modern Core; Frontier · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in vision-language-action models and generalist robot policies.
- **Relationship in sequence:** Builds on paper session 6; leads to the next paper in the master sequence (P156). Master lineage note: Humanoid-focused counterpart to π0 and OpenVLA.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Evaluation, data mixture, and hardware scope are organization-specific; full training reproduction is expensive.
- **Resumption context:** The durable takeaway is: Combines a vision-language module with a diffusion/flow-style action module for cross-embodiment humanoid control. Continue by comparing its assumptions and evidence with the next lineage stage.

### 8. P156 — Gemini Robotics: Bringing AI into the Physical World

- **Central question / objective:** Presents a Gemini-derived VLA and separate embodied-reasoning model across multiple robot embodiments.
- **Stage / role:** Paper lineage — Frontier; Synthesis
- **Status:** Frontier continuation
- **Prerequisites:** Session 7; P1–P4, L3–L6, D1–D4, E1.
- **Papers:** [P156 — Gemini Robotics: Bringing AI into the Physical World](https://arxiv.org/abs/2503.20020)
- **Supporting materials:** R014, R017
- **Concepts covered:** Presents a Gemini-derived VLA and separate embodied-reasoning model across multiple robot embodiments. Preparation profile: Frontier; Synthesis · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in vision-language-action models and generalist robot policies.
- **Relationship in sequence:** Builds on paper session 7; leads to the next paper in the master sequence (P157). Master lineage note: Strong example of dual-model reasoning-plus-control architecture.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Private preview, proprietary data, and limited independent reproduction.
- **Resumption context:** The durable takeaway is: Presents a Gemini-derived VLA and separate embodied-reasoning model across multiple robot embodiments. Continue by comparing its assumptions and evidence with the next lineage stage.

### 9. P157 — What Matters in Building Vision–Language–Action Models for Generalist Robots

- **Central question / objective:** Systematically studies VLM backbone, policy architecture, and cross-embodiment data across hundreds of experiments.
- **Stage / role:** Paper lineage — Critical; Modern Core
- **Status:** Advanced continuation
- **Prerequisites:** Session 8; P1–P4, L3–L6, D1–D4, E1.
- **Papers:** [P157 — What Matters in Building Vision–Language–Action Models for Generalist Robots](https://www.nature.com/articles/s42256-025-01168-7)
- **Supporting materials:** R014, R017
- **Concepts covered:** Systematically studies VLM backbone, policy architecture, and cross-embodiment data across hundreds of experiments. Preparation profile: Critical; Modern Core · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in vision-language-action models and generalist robot policies.
- **Relationship in sequence:** Builds on paper session 8; leads to the topic reconstruction/comparison session. Master lineage note: Important corrective to single-model showcase papers; directly informs architecture selection.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Results remain tied to selected backbones, tasks, and training recipes.
- **Resumption context:** The durable takeaway is: Systematically studies VLM backbone, policy architecture, and cross-embodiment data across hundreds of experiments. Continue by comparing its assumptions and evidence with the next lineage stage.

### 10. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Compare RT-2, Open X/RT-X, Octo, OpenVLA, π0, π0.5, GR00T N1, and empirical VLA design studies across data, architecture, action, compute, and evidence.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–9
- **Papers:** [P150 — RT-2: Vision-Language-Action Models Transfer Web Knowledge to Robotic Control](https://arxiv.org/abs/2307.15818), [P151 — Octo: An Open-Source Generalist Robot Policy](https://arxiv.org/abs/2405.12213), [P152 — OpenVLA: An Open-Source Vision-Language-Action Model](https://proceedings.mlr.press/v270/kim25c.html), [P153 — π0: A Vision-Language-Action Flow Model for General Robot Control](https://www.pi.website/download/pi0.pdf), [P154 — π0.5: A Vision-Language-Action Model with Open-World Generalization](https://proceedings.mlr.press/v305/black25a.html), [P155 — GR00T N1: An Open Foundation Model for Generalist Humanoid Robots](https://arxiv.org/abs/2503.14734), [P156 — Gemini Robotics: Bringing AI into the Physical World](https://arxiv.org/abs/2503.20020), [P157 — What Matters in Building Vision–Language–Action Models for Generalist Robots](https://www.nature.com/articles/s42256-025-01168-7)
- **Supporting materials:** R014, R017, R022, R023
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 11. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Fine-tune or evaluate an accessible VLA/generalist policy on a small dataset; benchmark against non-VLA baselines and analyze latency, data, and failure slices.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–10; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R014, R017, R022, R023
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Fine-tune or evaluate an accessible VLA/generalist policy on a small dataset; benchmark against non-VLA baselines and analyze latency, data, and failure slices.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 12. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–11; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R014, R017, R022, R023
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 13. Topic synthesis and original research directions

- **Central question / objective:** Which capabilities come from architecture, internet pretraining, robot data scale, embodiment normalization, or evaluation design?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–12
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R014, R017, R022, R023
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: E3, D4, S1–S4.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | P1–P4, L3–L6, D1–D4, E1. |
| Closely related / cross-area | Major synthesis point, not the sole curriculum organizer. |
| Outgoing capability | E3, D4, S1–S4 |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P150, P151, P152, P153, P154, P155, P156, P157 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**Which capabilities come from architecture, internet pretraining, robot data scale, embodiment normalization, or evaluation design?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to E3, D4, S1–S4 is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 8 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** No change to topic boundary or primary-paper inventory is proposed.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
