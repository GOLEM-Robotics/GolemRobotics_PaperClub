# D2 — Robot-learning benchmarks, generalization, and failure analysis: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** D. Data, evaluation, and research systems  
**Execution status:** **Shared Core**

## 1. Topic scope and target depth

### Covers

Simulation and real-robot benchmarks, distribution shifts, task definitions, success measurement, robustness perturbations, and statistical comparison.

### Excludes

It does not teach every benchmark task; it develops benchmark selection, validation, and failure-analysis competence.

### Target competence

Design statistically defensible robot-policy evaluations across simulation and real systems, exposing task ambiguity, leakage, distribution shifts, robustness, and real-to-sim mismatch.

### Place in the wider curriculum

Shared evaluation core. Defines evidence standards for every active track.

## 2. Execution status and completion boundary

- **Topic execution status:** Shared Core
- **Planned sessions:** 13
- **Classification:** 10 required core · 0 advanced continuation · 0 optional specialization · 3 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 13, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 13

## 3. Dependencies and required foundations

- **Master prerequisites:** F1; basic competence in relevant policy topic.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Task contracts, success metrics, episode sampling, train/test splits, perturbation taxonomies, real/sim correspondence, inter-rater reliability, confidence intervals, and benchmark governance.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R017 — [LeRobot Documentation](https://huggingface.co/docs/lerobot/)** (Documentation and open framework): Dataset schema, teleoperation, policy training, evaluation, and low-cost hardware integration.
- **R018 — [robomimic Documentation](https://robomimic.github.io/)** (Documentation and benchmark recipes): Reference implementation for demonstration learning and benchmark audits.
- **R019 — [ManiSkill Documentation](https://maniskill.readthedocs.io/)** (Simulation/benchmark documentation): High-throughput manipulation experiments and standardized evaluation.
- **R032 — [Habitat Lab Documentation](https://aihabitat.org/docs/habitat-lab/)** (Embodied-agent framework documentation): Navigation/embodied-agent task definitions, vectorized environments, datasets, evaluation, and hierarchical-agent experiments.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: F1; basic competence in relevant policy topic.
        │
        ▼
S1 Topic-local foundations: Task contracts, success metrics, episode sampling, train/test splits, perturbation taxonomies, real/sim correspondence, inter-rater reliability, confidence intervals, and benchmark governance.
        │
        ▼
Paper lineage: P123 → P124 → P125 → P126 → P127 → P128 → P129 → P130
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► all active and specialization tracks
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for robot-learning benchmarks, generalization, and failure analysis and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** F1; basic competence in relevant policy topic.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R017, R018, R019, R032
- **Concepts covered:** Task contracts, success metrics, episode sampling, train/test splits, perturbation taxonomies, real/sim correspondence, inter-rater reliability, confidence intervals, and benchmark governance.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Simulation and real-robot benchmarks, distribution shifts, task definitions, success measurement, robustness perturbations, and statistical comparison. Next, enter the ordered paper lineage.

### 2. P123 — RLBench: The Robot Learning Benchmark & Learning Environment

- **Central question / objective:** Provides a vision-rich manipulation benchmark with many tasks, demonstrations, and standardized interfaces.
- **Stage / role:** Paper lineage — Foundation
- **Status:** Required core
- **Prerequisites:** Session 1; F1; basic competence in relevant policy topic.
- **Papers:** [P123 — RLBench: The Robot Learning Benchmark & Learning Environment](https://arxiv.org/abs/1909.12271)
- **Supporting materials:** R017, R018
- **Concepts covered:** Provides a vision-rich manipulation benchmark with many tasks, demonstrations, and standardized interfaces. Preparation profile: Foundation · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in robot-learning benchmarks, generalization, and failure analysis.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P124). Master lineage note: Precursor to language-conditioned and generalist simulation evaluation.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Simulation realism, scripted demonstrations, and benchmark overfitting limit external validity.
- **Resumption context:** The durable takeaway is: Provides a vision-rich manipulation benchmark with many tasks, demonstrations, and standardized interfaces. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P124 — CALVIN: A Benchmark for Language-Conditioned Policy Learning for Long-Horizon Robot Manipulation Tasks

- **Central question / objective:** Evaluates language-conditioned policies on chained long-horizon manipulation tasks.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 2; F1; basic competence in relevant policy topic.
- **Papers:** [P124 — CALVIN: A Benchmark for Language-Conditioned Policy Learning for Long-Horizon Robot Manipulation Tasks](https://arxiv.org/abs/2112.03227)
- **Supporting materials:** R017, R018
- **Concepts covered:** Evaluates language-conditioned policies on chained long-horizon manipulation tasks. Preparation profile: Modern Core · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in robot-learning benchmarks, generalization, and failure analysis.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P125). Master lineage note: Builds on RLBench-style simulation and motivates sequence-level evaluation.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Narrow simulated tabletop domain and fixed task grammar.
- **Resumption context:** The durable takeaway is: Evaluates language-conditioned policies on chained long-horizon manipulation tasks. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P125 — LIBERO: Benchmarking Knowledge Transfer for Lifelong Robot Learning

- **Central question / objective:** Introduces suites for transfer, lifelong learning, and language-conditioned manipulation.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 3; F1; basic competence in relevant policy topic.
- **Papers:** [P125 — LIBERO: Benchmarking Knowledge Transfer for Lifelong Robot Learning](https://arxiv.org/abs/2306.03310)
- **Supporting materials:** R017, R018
- **Concepts covered:** Introduces suites for transfer, lifelong learning, and language-conditioned manipulation. Preparation profile: Modern Core · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in robot-learning benchmarks, generalization, and failure analysis.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P126). Master lineage note: Major current VLA/IL benchmark family.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Simulation-only and susceptible to fixed-view/task-template overfitting.
- **Resumption context:** The durable takeaway is: Introduces suites for transfer, lifelong learning, and language-conditioned manipulation. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P126 — ManiSkill2: A Unified Benchmark for Generalizable Manipulation Skills

- **Central question / objective:** Provides diverse manipulation tasks, demonstrations, visual observations, and scalable simulation.
- **Stage / role:** Paper lineage — Modern Core
- **Status:** Required core
- **Prerequisites:** Session 4; F1; basic competence in relevant policy topic.
- **Papers:** [P126 — ManiSkill2: A Unified Benchmark for Generalizable Manipulation Skills](https://arxiv.org/abs/2302.04659)
- **Supporting materials:** R017, R018
- **Concepts covered:** Provides diverse manipulation tasks, demonstrations, visual observations, and scalable simulation. Preparation profile: Modern Core · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in robot-learning benchmarks, generalization, and failure analysis.
- **Relationship in sequence:** Builds on paper session 4; leads to the next paper in the master sequence (P127). Master lineage note: Supports RL, IL, sim-to-real, and generalization studies.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Benchmark breadth still cannot substitute for physical evaluation.
- **Resumption context:** The durable takeaway is: Provides diverse manipulation tasks, demonstrations, visual observations, and scalable simulation. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. P127 — SimplerEnv: Simulated Manipulation Policy Evaluation Environments with Real-to-Sim Transfer

- **Central question / objective:** Evaluates real-robot policies in simulation designed to preserve policy ranking and behavior.
- **Stage / role:** Paper lineage — Modern Core; Critical
- **Status:** Required core
- **Prerequisites:** Session 5; F1; basic competence in relevant policy topic.
- **Papers:** [P127 — SimplerEnv: Simulated Manipulation Policy Evaluation Environments with Real-to-Sim Transfer](https://arxiv.org/abs/2405.05941)
- **Supporting materials:** R017, R018
- **Concepts covered:** Evaluates real-robot policies in simulation designed to preserve policy ranking and behavior. Preparation profile: Modern Core; Critical · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in robot-learning benchmarks, generalization, and failure analysis.
- **Relationship in sequence:** Builds on paper session 5; leads to the next paper in the master sequence (P128). Master lineage note: Addresses expensive VLA evaluation and sim/real correspondence.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Real-to-sim fidelity and ranking correlation remain embodiment/task dependent.
- **Resumption context:** The durable takeaway is: Evaluates real-robot policies in simulation designed to preserve policy ranking and behavior. Continue by comparing its assumptions and evidence with the next lineage stage.

### 7. P128 — RoboArena: A Community-Driven Real-World Benchmark for Generalist Robot Policies

- **Central question / objective:** Uses decentralized double-blind pairwise real-robot evaluations across diverse tasks and environments.
- **Stage / role:** Paper lineage — Frontier Bridge; Critical
- **Status:** Frontier continuation
- **Prerequisites:** Session 6; F1; basic competence in relevant policy topic.
- **Papers:** [P128 — RoboArena: A Community-Driven Real-World Benchmark for Generalist Robot Policies](https://robo-arena.github.io/)
- **Supporting materials:** R017, R018
- **Concepts covered:** Uses decentralized double-blind pairwise real-robot evaluations across diverse tasks and environments. Preparation profile: Frontier Bridge; Critical · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in robot-learning benchmarks, generalization, and failure analysis.
- **Relationship in sequence:** Builds on paper session 6; leads to the next paper in the master sequence (P129). Master lineage note: Responds to narrow fixed benchmark tasks and scales real-world evaluation diversity.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Community consistency, hardware comparability, and evolving protocols require careful interpretation.
- **Resumption context:** The durable takeaway is: Uses decentralized double-blind pairwise real-robot evaluations across diverse tasks and environments. Continue by comparing its assumptions and evidence with the next lineage stage.

### 8. P129 — LIBERO-Plus: A Progressive Robustness Benchmark for Vision-Language-Action Models

- **Central question / objective:** Stress-tests VLA robustness under controlled perturbations in camera, language, initialization, appearance, and sensing.
- **Stage / role:** Paper lineage — Critical; Frontier
- **Status:** Frontier continuation
- **Prerequisites:** Session 7; F1; basic competence in relevant policy topic.
- **Papers:** [P129 — LIBERO-Plus: A Progressive Robustness Benchmark for Vision-Language-Action Models](https://openaccess.thecvf.com/content/CVPR2026/html/Fei_LIBERO-Plus_A_Progressive_Robustness_Benchmark_for_Visual-Language-Action_Models_CVPR_2026_paper.html)
- **Supporting materials:** R017, R018
- **Concepts covered:** Stress-tests VLA robustness under controlled perturbations in camera, language, initialization, appearance, and sensing. Preparation profile: Critical; Frontier · Advanced · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in robot-learning benchmarks, generalization, and failure analysis.
- **Relationship in sequence:** Builds on paper session 7; leads to the next paper in the master sequence (P130). Master lineage note: Directly challenges high scores on clean LIBERO and belongs after LIBERO.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Simulation-only and very recent; real-world correspondence remains to be established.
- **Resumption context:** The durable takeaway is: Stress-tests VLA robustness under controlled perturbations in camera, language, initialization, appearance, and sensing. Continue by comparing its assumptions and evidence with the next lineage stage.

### 9. P130 — RobotArena∞: Scalable Robot Benchmarking via Real-to-Sim Translation

- **Central question / objective:** Translates real demonstrations into scalable simulated evaluation and combines automated and human judgment.
- **Stage / role:** Paper lineage — Frontier; Critical
- **Status:** Frontier continuation
- **Prerequisites:** Session 8; F1; basic competence in relevant policy topic.
- **Papers:** [P130 — RobotArena∞: Scalable Robot Benchmarking via Real-to-Sim Translation](https://robotarenainf.github.io/)
- **Supporting materials:** R017, R018
- **Concepts covered:** Translates real demonstrations into scalable simulated evaluation and combines automated and human judgment. Preparation profile: Frontier; Critical · Expert · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in robot-learning benchmarks, generalization, and failure analysis.
- **Relationship in sequence:** Builds on paper session 8; leads to the topic reconstruction/comparison session. Master lineage note: Extends real-to-sim evaluation beyond fixed hand-built environments.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Translation fidelity and automated scoring can bias conclusions; new benchmark.
- **Resumption context:** The durable takeaway is: Translates real demonstrations into scalable simulated evaluation and combines automated and human judgment. Continue by comparing its assumptions and evidence with the next lineage stage.

### 10. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Compare RLBench, CALVIN, LIBERO, ManiSkill2, SimplerEnv, RoboArena, LIBERO-Plus, and RobotArena∞ as evaluation claims and infrastructures.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–9
- **Papers:** [P123 — RLBench: The Robot Learning Benchmark & Learning Environment](https://arxiv.org/abs/1909.12271), [P124 — CALVIN: A Benchmark for Language-Conditioned Policy Learning for Long-Horizon Robot Manipulation Tasks](https://arxiv.org/abs/2112.03227), [P125 — LIBERO: Benchmarking Knowledge Transfer for Lifelong Robot Learning](https://arxiv.org/abs/2306.03310), [P126 — ManiSkill2: A Unified Benchmark for Generalizable Manipulation Skills](https://arxiv.org/abs/2302.04659), [P127 — SimplerEnv: Simulated Manipulation Policy Evaluation Environments with Real-to-Sim Transfer](https://arxiv.org/abs/2405.05941), [P128 — RoboArena: A Community-Driven Real-World Benchmark for Generalist Robot Policies](https://robo-arena.github.io/), [P129 — LIBERO-Plus: A Progressive Robustness Benchmark for Vision-Language-Action Models](https://openaccess.thecvf.com/content/CVPR2026/html/Fei_LIBERO-Plus_A_Progressive_Robustness_Benchmark_for_Visual-Language-Action_Models_CVPR_2026_paper.html), [P130 — RobotArena∞: Scalable Robot Benchmarking via Real-to-Sim Translation](https://robotarenainf.github.io/)
- **Supporting materials:** R017, R018, R019, R032
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 11. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Construct a benchmark audit and run a multi-seed policy comparison with uncertainty, robustness slices, failure taxonomy, and protocol sensitivity.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–10; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R017, R018, R019, R032
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Construct a benchmark audit and run a multi-seed policy comparison with uncertainty, robustness slices, failure taxonomy, and protocol sensitivity.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 12. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–11; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R017, R018, R019, R032
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 13. Topic synthesis and original research directions

- **Central question / objective:** What does a benchmark result establish about real robot capability—and what does it leave untested?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–12
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R017, R018, R019, R032
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: all active and specialization tracks.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | F1; basic competence in relevant policy topic. |
| Closely related / cross-area | Defines evidence standards for every active track. |
| Outgoing capability | all active and specialization tracks |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P123, P124, P125, P126, P127, P128, P129, P130 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**What does a benchmark result establish about real robot capability—and what does it leave untested?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to all active and specialization tracks is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 8 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** Propose adding the following supporting resources to the master supporting-material index: R032. They fill implementation/reconstruction gaps without changing the paper sequence.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
