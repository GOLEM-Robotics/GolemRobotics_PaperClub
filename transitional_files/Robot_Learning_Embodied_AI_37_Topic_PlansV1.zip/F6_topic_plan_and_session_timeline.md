# F6 — Robot mechanics, dynamics, and interaction control: Topic Plan and Session Timeline

**Master-curriculum source:** `Robot_Learning_Embodied_AI_Master_Curriculum_2026-07-19.md`  
**Topic-planning guideline:** `4_topic_planning_guideline.md`  
**Master literature cutoff:** 19 July 2026  
**Topic-plan resource verification:** 21 July 2026  
**Area:** A. Shared foundations  
**Execution status:** **Shared Core**

## 1. Topic scope and target depth

### Covers

Kinematics, rigid-body dynamics, operational-space control, force/impedance/admittance control, redundancy, and contact interaction.

### Excludes

It does not replace a complete mechanics/control degree sequence and excludes high-level planning covered in F7.

### Target competence

Model robot kinematics/dynamics and contact interactions sufficiently to derive and evaluate task-space, force, impedance, admittance, redundancy, and safety-filter behavior.

### Place in the wider curriculum

Classical foundation needed to judge learned controllers. Constrains every physical-policy topic; links to S1–S3 and L7–L8.

## 2. Execution status and completion boundary

- **Topic execution status:** Shared Core
- **Planned sessions:** 9
- **Classification:** 9 required core · 0 advanced continuation · 0 optional specialization · 0 frontier continuation
- **Completion boundary:** Operational completion is reached after Session 9, the last session classified as **Required core**. Advanced, optional, and frontier sessions remain valid continuations but are not required for operational completion.
- **Required core endpoint:** Session 9

## 3. Dependencies and required foundations

- **Master prerequisites:** Linear algebra, differential equations, basic control.
- **Shared-core foundations:** Cross-reference the named prerequisite topic timelines; do not duplicate them here.
- **Topic-local foundations:** Frames, twists, Jacobians, mass matrix, Coriolis/gravity terms, task-space dynamics, passivity, contact/friction, and feedback stability.
- **Individual preparation gaps:** Missing algebra, probability, control, software, or framework skills may be repaired during per-session preparation without expanding this topic timeline.

### Supporting materials and their roles

- **R005 — [Modern Robotics: Mechanics, Planning, and Control](https://modernrobotics.northwestern.edu/)** (Open textbook/course): Kinematics, dynamics, Jacobians, control, and planning prerequisites.
- **R006 — [Underactuated Robotics](https://underactuated.csail.mit.edu/)** (Open textbook/lecture notes): Nonlinear dynamics, optimal control, planning, and learning for physical systems.
- **R020 — [MuJoCo Documentation](https://mujoco.readthedocs.io/)** (Physics simulator documentation): Reliable dynamics/control simulation reference.
- **R028 — [MIT Robotic Manipulation: Perception, Planning, and Control](https://manipulation.csail.mit.edu/)** (Open course notes and exercises): Integrated manipulation stack connecting geometry, perception, planning, contact, control, and learning.
- **R030 — [ROS 2 Real-Time Programming Documentation](https://docs.ros.org/en/kilted/Tutorials/Demos/Real-Time-Programming.html)** (Official systems documentation): Deadline, jitter, memory-allocation, scheduling, and execution-path constraints for physical robot deployment.
- **R034 — [Drake Documentation and Tutorials](https://drake.mit.edu/tutorials/)** (Model-based robotics framework and tutorials): Multibody dynamics, contact, mathematical programming, automatic differentiation, systems diagrams, and model-based verification.

## 4. Topic concept and dependency map

```text
External/shared prerequisites: Linear algebra, differential equations, basic control.
        │
        ▼
S1 Topic-local foundations: Frames, twists, Jacobians, mass matrix, Coriolis/gravity terms, task-space dynamics, passivity, contact/friction, and feedback stability.
        │
        ▼
Paper lineage: P028 → P029 → P030 → P031
        │
        ▼
Unified mathematical / architectural reconstruction
        │
        ├──► controlled implementation / reproduction / evidence audit
        │               │
        │               ▼
        └────────► evidence and system-level interpretation
                                │
                                ▼
Topic synthesis ──► F7–F8, L7–L8, S1–S3, S7
```

The dependency map is authoritative. The timeline below is a planning view derived from it and may be interleaved with other topics only when its prerequisite edges remain satisfied.

## 5. Ordered session timeline

### 1. Topic boundary, foundations, and diagnostic map

- **Central question / objective:** Establish the minimum conceptual foundation for robot mechanics, dynamics, and interaction control and locate it within the master dependency graph.
- **Stage / role:** Foundations and boundary confirmation
- **Status:** Required core
- **Prerequisites:** Linear algebra, differential equations, basic control.
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R005, R006, R020, R028, R030, R034
- **Concepts covered:** Frames, twists, Jacobians, mass matrix, Coriolis/gravity terms, task-space dynamics, passivity, contact/friction, and feedback stability.
- **Expected capability:** Identify missing prerequisites, state the topic boundary, and explain the dependency path into the selected paper lineage.
- **Relationship in sequence:** Entry point. It prevents paper sessions from carrying hidden mathematical, robotics, or systems prerequisites.
- **Planned analytical / practical component:** Short prerequisite diagnostic and a concept/dependency diagram; no meeting procedure is prescribed.
- **Resumption context:** Resume from the agreed boundary: Kinematics, rigid-body dynamics, operational-space control, force/impedance/admittance control, redundancy, and contact interaction. Next, enter the ordered paper lineage.

### 2. P028 — Impedance Control: An Approach to Manipulation, Part I—Theory

- **Central question / objective:** Frames manipulation as regulation of the dynamic force–motion relationship rather than pure position tracking.
- **Stage / role:** Paper lineage — Foundation; Seminal
- **Status:** Required core
- **Prerequisites:** Session 1; Linear algebra, differential equations, basic control.
- **Papers:** [P028 — Impedance Control: An Approach to Manipulation, Part I—Theory](https://doi.org/10.1115/1.3140702)
- **Supporting materials:** R005, R006
- **Concepts covered:** Frames manipulation as regulation of the dynamic force–motion relationship rather than pure position tracking. Preparation profile: Foundation; Seminal · Advanced · High; equations and physical interpretation
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in robot mechanics, dynamics, and interaction control.
- **Relationship in sequence:** Builds on the foundation session; leads to the next paper in the master sequence (P029). Master lineage note: Foundation for contact-rich manipulation, safety, and learned high-level policies.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Idealized assumptions; practical implementations require sensing, passivity, and actuator analysis.
- **Resumption context:** The durable takeaway is: Frames manipulation as regulation of the dynamic force–motion relationship rather than pure position tracking. Continue by comparing its assumptions and evidence with the next lineage stage.

### 3. P029 — A Unified Approach for Motion and Force Control of Robot Manipulators: The Operational Space Formulation

- **Central question / objective:** Establishes operational-space dynamics and dynamically consistent task control.
- **Stage / role:** Paper lineage — Seminal
- **Status:** Required core
- **Prerequisites:** Session 2; Linear algebra, differential equations, basic control.
- **Papers:** [P029 — A Unified Approach for Motion and Force Control of Robot Manipulators: The Operational Space Formulation](https://doi.org/10.1109/JRA.1987.1087068)
- **Supporting materials:** R005, R006
- **Concepts covered:** Establishes operational-space dynamics and dynamically consistent task control. Preparation profile: Seminal · Advanced · High; derive task-space dynamics and null-space behavior
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in robot mechanics, dynamics, and interaction control.
- **Relationship in sequence:** Builds on paper session 2; leads to the next paper in the master sequence (P030). Master lineage note: Connects manipulator dynamics to whole-body and contact control.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Model accuracy and torque control are demanding; constraints/contact extensions require later work.
- **Resumption context:** The durable takeaway is: Establishes operational-space dynamics and dynamically consistent task control. Continue by comparing its assumptions and evidence with the next lineage stage.

### 4. P030 — Dynamic Movement Primitives: A Framework for Motor Control in Humans and Humanoid Robotics

- **Central question / objective:** Introduces stable attractor-based motion primitives modulated by learned forcing terms.
- **Stage / role:** Paper lineage — Bridge
- **Status:** Required core
- **Prerequisites:** Session 3; Linear algebra, differential equations, basic control.
- **Papers:** [P030 — Dynamic Movement Primitives: A Framework for Motor Control in Humans and Humanoid Robotics](https://doi.org/10.1007/4-431-31381-8_23)
- **Supporting materials:** R005, R006
- **Concepts covered:** Introduces stable attractor-based motion primitives modulated by learned forcing terms. Preparation profile: Bridge · Intermediate · Medium
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in robot mechanics, dynamics, and interaction control.
- **Relationship in sequence:** Builds on paper session 3; leads to the next paper in the master sequence (P031). Master lineage note: Early bridge between control structure and learnable motion generation.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Limited multimodality and perception coupling; not a general policy architecture.
- **Resumption context:** The durable takeaway is: Introduces stable attractor-based motion primitives modulated by learned forcing terms. Continue by comparing its assumptions and evidence with the next lineage stage.

### 5. P031 — Control Barrier Function Based Quadratic Programs for Safety Critical Systems

- **Central question / objective:** Combines control Lyapunov and barrier functions in online quadratic programs for safety constraints.
- **Stage / role:** Paper lineage — Modern Core; Bridge
- **Status:** Required core
- **Prerequisites:** Session 4; Linear algebra, differential equations, basic control.
- **Papers:** [P031 — Control Barrier Function Based Quadratic Programs for Safety Critical Systems](https://doi.org/10.1109/TAC.2016.2638961)
- **Supporting materials:** R005, R006
- **Concepts covered:** Combines control Lyapunov and barrier functions in online quadratic programs for safety constraints. Preparation profile: Modern Core; Bridge · Advanced · High
- **Expected capability:** Reconstruct the paper’s problem, assumptions, method, objective/training or inference procedure, evidence, and limitations; position it relative to earlier and later work in robot mechanics, dynamics, and interaction control.
- **Relationship in sequence:** Builds on paper session 4; leads to the topic reconstruction/comparison session. Master lineage note: Links classical control to L8 safety filters.
- **Planned analytical / practical component:** Evidence analysis focused on the paper’s strongest claim and the positioning limitation: Requires valid dynamics and barrier construction; feasibility and model mismatch are critical.
- **Resumption context:** The durable takeaway is: Combines control Lyapunov and barrier functions in online quadratic programs for safety constraints. Continue by comparing its assumptions and evidence with the next lineage stage.

### 6. Mathematical / architectural reconstruction and competing-method comparison

- **Central question / objective:** Derive operational-space and impedance-control equations, including null-space and constraint interactions.
- **Stage / role:** Reconstruction and lineage integration
- **Status:** Required core
- **Prerequisites:** Sessions 1–5
- **Papers:** [P028 — Impedance Control: An Approach to Manipulation, Part I—Theory](https://doi.org/10.1115/1.3140702), [P029 — A Unified Approach for Motion and Force Control of Robot Manipulators: The Operational Space Formulation](https://doi.org/10.1109/JRA.1987.1087068), [P030 — Dynamic Movement Primitives: A Framework for Motor Control in Humans and Humanoid Robotics](https://doi.org/10.1007/4-431-31381-8_23), [P031 — Control Barrier Function Based Quadratic Programs for Safety Critical Systems](https://doi.org/10.1109/TAC.2016.2638961)
- **Supporting materials:** R005, R006, R020, R028, R030, R034
- **Concepts covered:** Common notation, assumptions, objectives, model components, data flow, inference/control loop, computational requirements, guarantees, and characteristic failure modes.
- **Expected capability:** Move between the papers using one consistent technical representation; explain which differences are conceptual and which are implementation or scale choices.
- **Relationship in sequence:** Consolidates the full paper sequence before any reproduction or benchmark conclusion is attempted.
- **Planned analytical / practical component:** Produce derivations, architecture/data-flow diagrams, or a method-comparison matrix appropriate to the topic.
- **Resumption context:** Resume from the unified comparison artifact, not from isolated paper summaries. The next step tests the reconstruction against an implementation or evidence base.

### 7. Controlled implementation, reproduction, or evidence audit

- **Central question / objective:** Implement and compare joint-space, operational-space, impedance, and barrier-filtered control in simulation with latency/model-error perturbations.
- **Stage / role:** Implementation / reproduction / controlled evaluation
- **Status:** Required core
- **Prerequisites:** Sessions 1–6; access to the compute, data, simulator, or hardware stated in the feasibility note below
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R005, R006, R020, R028, R030, R034
- **Concepts covered:** Implementation choices, experimental controls, baselines, metrics, resource constraints, uncertainty, failure logging, and reproducibility.
- **Expected capability:** Translate the paper lineage into a controlled empirical question and interpret failures without conflating code defects, data limitations, optimization, and method assumptions.
- **Relationship in sequence:** Tests whether the reconstructed mechanisms and claims survive contact with an inspectable implementation or evidence audit.
- **Planned analytical / practical component:** Implement and compare joint-space, operational-space, impedance, and barrier-filtered control in simulation with latency/model-error perturbations.
- **Resumption context:** Resume from the experiment specification, frozen configuration, artifacts, and failure log. The next session interprets evidence at system level.

### 8. Evidence, limitations, and system-level interpretation

- **Central question / objective:** Determine what the topic’s evidence establishes for intelligent physical systems and where conclusions fail under data, compute, hardware, latency, embodiment, or benchmark changes.
- **Stage / role:** Controlled evaluation and system interpretation
- **Status:** Required core
- **Prerequisites:** Sessions 1–7; F1 and D2 concepts for empirical topics
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R005, R006, R020, R028, R030, R034
- **Concepts covered:** Baseline adequacy, uncertainty, ablations, distribution shift, compute/data/hardware dependencies, real-world validity, negative results, and integration constraints.
- **Expected capability:** Write a defensible topic-level evidence statement and identify the most consequential unresolved failure modes.
- **Relationship in sequence:** Converts method knowledge and practical results into cross-stack research judgment before final synthesis.
- **Planned analytical / practical component:** Audit the strongest positive result, one critical/negative result or plausible falsification, and the transfer of conclusions to the club’s feasible systems.
- **Resumption context:** Resume from the evidence statement and unresolved-failure list. The final core session turns these into research choices and cross-topic interfaces.

### 9. Topic synthesis and original research directions

- **Central question / objective:** What must a learned policy output, and what should remain in a structured low-level controller?
- **Stage / role:** Synthesis and research-direction formation
- **Status:** Required core
- **Prerequisites:** Sessions 1–8
- **Papers:** None; topic-level reconstruction or synthesis session.
- **Supporting materials:** R005, R006, R020, R028, R030, R034
- **Concepts covered:** Durable lineage, competing hypotheses, integration interfaces, feasibility envelope, open problems, and promotion/deprecation criteria.
- **Expected capability:** Formulate technically grounded research questions, specify falsifiable hypotheses and minimum evidence, and connect the topic to adjacent curriculum tracks.
- **Relationship in sequence:** Final integration point. It defines the completed topic state and the handoff to adjacent or frontier work.
- **Planned analytical / practical component:** Create a concise synthesis map and 2–4 original research hypotheses with proposed baselines, measurements, and stop conditions.
- **Resumption context:** The topic is resumable from its synthesis map, experiment artifacts, and open-question register. Outgoing links: F7–F8, L7–L8, S1–S3, S7.
## 6. Cross-topic links

| Direction | Topics / role |
|---|---|
| Incoming foundations | Linear algebra, differential equations, basic control. |
| Closely related / cross-area | Constrains every physical-policy topic; links to S1–S3 and L7–L8. |
| Outgoing capability | F7–F8, L7–L8, S1–S3, S7 |
| Evaluation dependency | F1 for experimental methodology; D2 for benchmark, robustness, and failure-analysis design; D3 for reproducible implementation when practical work is performed. |

## 7. Coverage and progression check

| Check | Result |
|---|---|
| Every selected primary paper assigned | Yes — P028, P029, P030, P031 |
| Every supporting material has a role | Yes — listed in Section 3 and attached to relevant sessions. |
| Prerequisites introduced before use | Yes — shared/external prerequisites precede topic-local foundations; reconstruction follows the paper lineage. |
| Foundations-to-expert progression | Yes — foundation → lineage → reconstruction → implementation/evidence → system interpretation → synthesis. |
| Competing/critical/evaluation perspectives represented | Yes — the comparison and evidence sessions explicitly require competing assumptions, limitations, negative or falsifying evidence, and benchmark validity. |
| Implementation used only when informative | Yes — the practical session permits reproduction, controlled implementation, or evidence audit according to feasibility. |
| Required core ends in integration | Yes — the final required core endpoint is a synthesis/evidence session rather than the final paper alone. |
| Advanced/frontier work separated | Yes — session classifications are explicit. |
| Interleaving resumption context present | Yes — every session records a resumption state and its relationship to adjacent sessions. |

## 8. Planned synthesis, frontier questions, and unresolved gaps

### Synthesis question

**What must a learned policy output, and what should remain in a structured low-level controller?**

### Required synthesis outputs

- One dependency and method-lineage map using common notation.
- One evidence statement separating demonstrated results, assumptions, and unresolved failure modes.
- Two to four falsifiable research hypotheses with baselines, measurements, resource requirements, and stop conditions.
- One cross-topic integration note describing inputs, outputs, timing/data assumptions, and evaluation interfaces.

### Frontier / unresolved questions

- Which assumptions in the durable paper sequence fail under the club's target data, compute, simulator, hardware, or embodiment constraints?
- Which apparent improvements come from architecture or algorithm, and which come from data scale, tuning, infrastructure, or evaluation protocol?
- What negative result or controlled ablation would most strongly change the topic's current ordering or research priority?
- Which interface to F7–F8, L7–L8, S1–S3, S7 is underspecified and should become an integration experiment?

## 9. Revision notes for the master curriculum

- **Primary-paper inventory:** unchanged; all 4 papers remain in the master order.
- **Topic boundary:** no split or merge proposed.
- **Supporting-material revision:** Propose adding the following supporting resources to the master supporting-material index: R028, R030, R034. They fill implementation/reconstruction gaps without changing the paper sequence.
- **Reason:** Topic planning exposed the need for practical reconstruction/system references while preserving the master curriculum's distinction between primary papers and supporting resources.
- **Revision date:** 21 July 2026.
