# Golem Robotics Paper Club Curriculum Viewer

This repository uses **Material for MkDocs** to render the existing Markdown curriculum as a searchable static website. The Markdown files remain the only source of truth; there is no backend, database, API, or duplicated curriculum schema.

## Local preview

From the repository root:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
mkdocs serve
```

Open <http://127.0.0.1:8000>.

For faster rebuilds while editing:

```bash
mkdocs serve --dirtyreload
```

## Validate and build

```bash
mkdocs build --strict
```

The generated static site is written to `site/` and is intentionally excluded from Git.

## GitHub Pages

The workflow at `.github/workflows/deploy_pages.yml` builds and deploys the site on pushes to `main` and can also be started manually.

In the GitHub repository settings, set **Pages → Build and deployment → Source** to **GitHub Actions**. No additional service or secret is required for a standard Pages deployment.

## Viewer files

- `mkdocs.yml` — theme, search, navigation, and Markdown configuration.
- `requirements.txt` — pinned viewer dependency.
- `curriculum_and_progress/index.md` — compact landing page.
- `curriculum_and_progress/reference/` — thin include pages for the five root workflow documents.
- `curriculum_and_progress/stylesheets/extra.css` — dense-table and wide-layout improvements.
- `curriculum_and_progress/javascripts/mathjax.js` — mathematical notation support.
- `.github/workflows/deploy_pages.yml` — automatic GitHub Pages deployment.

Curriculum, paper, resource, frontier, and topic files remain in their original locations.
